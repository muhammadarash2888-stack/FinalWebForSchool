import { ParentAcademics } from "@/components/features/parent-portal";
export default function Page() { return <ParentAcademics />; }
