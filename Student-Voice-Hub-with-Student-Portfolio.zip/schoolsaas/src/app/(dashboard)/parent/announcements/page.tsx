import { ParentAnnouncements } from "@/components/features/parent-portal";
export default function Page() { return <ParentAnnouncements />; }
