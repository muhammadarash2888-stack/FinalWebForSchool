import { ParentAttendance } from "@/components/features/parent-portal";
export default function Page() { return <ParentAttendance />; }
