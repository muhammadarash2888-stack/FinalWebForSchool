import { requireProfile, assertRole } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { DashboardShell } from "@/components/layout/dashboard-shell";

export default async function ParentLayout({ children }: { children: React.ReactNode }) {
  const profile = await requireProfile();
  assertRole(profile, ["parent"]);
  const supabase = createClient();
  const { data: school } = await supabase.from("schools").select("name,logo_url,primary_color").eq("id", profile.school_id!).single();
  return (
    <DashboardShell role="parent" schoolName={school?.name ?? "Your School"} logoUrl={school?.logo_url ?? null}
      brandColor={school?.primary_color ?? null} userName={profile.full_name || profile.email || "Parent/Guardian"} userEmail={profile.email ?? ""}>
      {children}
    </DashboardShell>
  );
}
