import { ParentOverview } from "@/components/features/parent-portal";
export default function Page() { return <ParentOverview />; }
