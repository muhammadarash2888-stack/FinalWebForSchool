import { StaffAnnouncements } from "@/components/features/staff-announcements";
export default function Page() { return <StaffAnnouncements />; }
