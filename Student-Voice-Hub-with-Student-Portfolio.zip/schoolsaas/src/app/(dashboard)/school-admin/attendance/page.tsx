import { AttendanceRegister } from "@/components/features/attendance-register";
export default function Page({ searchParams }: { searchParams?: { [key: string]: string | string[] | undefined; date?: string | string[]; class_name?: string | string[] } }) {
  return <AttendanceRegister basePath="/school-admin/attendance" searchParams={searchParams} />;
}
