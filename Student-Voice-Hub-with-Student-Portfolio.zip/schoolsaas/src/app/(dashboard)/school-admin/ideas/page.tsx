import { StaffIdeas } from "@/components/features/staff-ideas";
export default function Page() { return <StaffIdeas />; }
