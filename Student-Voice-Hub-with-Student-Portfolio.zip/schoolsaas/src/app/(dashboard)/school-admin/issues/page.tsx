import { StaffIssues } from "@/components/features/staff-issues";
export default function Page() { return <StaffIssues />; }
