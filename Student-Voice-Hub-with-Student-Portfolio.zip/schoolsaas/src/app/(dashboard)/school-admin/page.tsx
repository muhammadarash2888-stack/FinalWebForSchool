import { SchoolLeadershipDashboard } from "@/components/features/school-leadership-dashboard";
export default function Page() { return <SchoolLeadershipDashboard />; }
