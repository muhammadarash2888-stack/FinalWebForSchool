import { createClient } from "@/lib/supabase/server";
import { Card, CardHeader, Input, Select, Label, Badge, EmptyState, ErrorState, Table, Thead, Tbody, Td } from "@/components/ui/primitives";
import { ActionForm, ActionButton } from "@/components/ui/action-form";
import { createUserAction, linkParentToStudentAction, setUserActiveAction } from "@/app/actions/admin";

export default async function PeoplePage() {
  const supabase = createClient();
  const [{ data: people, error }, { data: students }] = await Promise.all([
    supabase.from("profiles").select("*").in("role", ["student", "teacher", "parent"]).order("role").order("full_name"),
    supabase.from("profiles").select("id,full_name,class_name").eq("role", "student").order("class_name").order("full_name").limit(2000),
  ]);
  if (error) return <ErrorState message={error.message} />;
  const parents = (people ?? []).filter((person) => person.role === "parent");
  return (
    <div className="space-y-6">
      <div><h1 className="text-2xl font-semibold">People &amp; parent accounts</h1><p className="mt-1 text-sm text-slate-500">Manage school users and explicitly link parent accounts to students.</p></div>
      <Card>
        <CardHeader title="Add a school account" description="Create a student, teacher or parent login. Parent accounts are linked to a student before they can view records." />
        <ActionForm action={createUserAction} submitLabel="Create user" successMessage="User created">
          <div className="grid gap-4 sm:grid-cols-2">
            <div><Label>Full name</Label><Input name="full_name" required /></div>
            <div><Label>Email</Label><Input name="email" type="email" required /></div>
            <div><Label>Temporary password</Label><Input name="password" type="password" minLength={8} required /></div>
            <div><Label>Role</Label><Select name="role" defaultValue="student"><option value="student">Student</option><option value="teacher">Teacher</option><option value="parent">Parent / guardian</option></Select></div>
            <div><Label>Class / grade (student or teacher)</Label><Input name="class_name" placeholder="Grade 9-B" /></div>
            <div className="sm:col-span-2"><Label>Link parent to student (required for parent accounts)</Label><Select name="linked_student_id" defaultValue=""><option value="">Choose a student if creating a parent account</option>{(students ?? []).map((student) => <option key={student.id} value={student.id}>{student.full_name}{student.class_name ? ` · ${student.class_name}` : " · Class not set"}</option>)}</Select><p className="mt-1 text-xs text-slate-500">Parents will only be able to view the linked student's attendance and grades.</p></div>
          </div>
        </ActionForm>
      </Card>
      <Card>
        <CardHeader title="Link a sibling to an existing parent" description="A parent can have more than one child in the school. Links are verified by the school and restrict family data to those students." />
        {!parents.length || !students?.length ? <EmptyState title="Parent or student account needed" description="Create a parent account and at least one student account before linking additional children." /> : <ActionForm action={linkParentToStudentAction} submitLabel="Link student to parent" successMessage="Family link saved">
          <div className="grid gap-4 sm:grid-cols-3">
            <div><Label>Parent account</Label><Select name="parent_id" required defaultValue=""><option value="" disabled>Choose parent</option>{parents.map((parent) => <option key={parent.id} value={parent.id}>{parent.full_name} · {parent.email}</option>)}</Select></div>
            <div><Label>Student account</Label><Select name="student_id" required defaultValue=""><option value="" disabled>Choose student</option>{students.map((student) => <option key={student.id} value={student.id}>{student.full_name}{student.class_name ? ` · ${student.class_name}` : ""}</option>)}</Select></div>
            <div><Label>Relationship</Label><Select name="relationship" defaultValue="Parent/Guardian"><option>Parent/Guardian</option><option>Mother</option><option>Father</option><option>Guardian</option><option>Other authorised guardian</option></Select></div>
          </div>
        </ActionForm>}
      </Card>
      {!people?.length ? <EmptyState title="No users yet" description="Add students, teachers and parent accounts above." /> : (
        <Table>
          <Thead columns={["Name", "Email", "Role", "Class", "Status", ""]} />
          <Tbody>
            {people.map((p) => (
              <tr key={p.id}>
                <Td>{p.full_name}</Td><Td>{p.email}</Td>
                <Td><Badge tone={p.role === "teacher" ? "purple" : p.role === "parent" ? "yellow" : "blue"}>{p.role}</Badge></Td>
                <Td>{p.class_name ?? "—"}</Td>
                <Td><Badge tone={p.is_active ? "green" : "red"}>{p.is_active ? "Active" : "Deactivated"}</Badge></Td>
                <Td><ActionButton variant="ghost" run={setUserActiveAction.bind(null, p.id, !p.is_active)} successMessage="Updated">{p.is_active ? "Deactivate" : "Reactivate"}</ActionButton></Td>
              </tr>
            ))}
          </Tbody>
        </Table>
      )}
    </div>
  );
}
