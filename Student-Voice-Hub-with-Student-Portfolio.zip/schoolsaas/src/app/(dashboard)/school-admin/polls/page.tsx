import { StaffPolls } from "@/components/features/staff-polls";
export default function Page() { return <StaffPolls />; }
