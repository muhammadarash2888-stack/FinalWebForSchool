import { requireProfile, assertRole } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { StudentPortfolio } from "@/components/features/student-portfolio";

export default async function Page() {
  const profile = await requireProfile();
  assertRole(profile, ["teacher", "school_admin"]);
  const supabase = createClient();
  const { data } = await supabase.from("student_portfolio_items")
    .select("id,title,category,issuer,achievement_date,description,file_path,review_status,reviewer_notes,created_at,student:profiles!student_portfolio_items_student_id_fkey(full_name,class_name)")
    .eq("school_id", profile.school_id!).order("created_at", { ascending: false });
  return <StudentPortfolio items={(data || []) as any} staffView />;
}
