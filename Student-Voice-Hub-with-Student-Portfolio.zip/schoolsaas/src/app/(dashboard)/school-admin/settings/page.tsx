import { createClient } from "@/lib/supabase/server";
import { Card, CardHeader, Badge, ErrorState } from "@/components/ui/primitives";
import { requireProfile } from "@/lib/auth";

export default async function SettingsPage() {
  const profile = await requireProfile();
  const supabase = createClient();
  const { data: school, error } = await supabase.from("schools").select("*").eq("id", profile.school_id!).single();
  if (error || !school) return <ErrorState message={error?.message ?? "School not found"} />;
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">School settings</h1>
      <Card>
        <CardHeader title={school.name} description={`Slug: ${school.slug}`} action={<Badge tone={school.status === "active" ? "green" : "yellow"}>{school.status}</Badge>} />
        <p className="text-sm text-slate-500">Plan: {school.subscription_plan ?? "—"}. Branding (name, logo, colour) is managed by the platform administrator — contact support to change it.</p>
      </Card>
    </div>
  );
}
