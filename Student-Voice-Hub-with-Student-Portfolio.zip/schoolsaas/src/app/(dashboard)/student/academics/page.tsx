import { StudentAcademics } from "@/components/features/student-records";
export default function Page() { return <StudentAcademics />; }
