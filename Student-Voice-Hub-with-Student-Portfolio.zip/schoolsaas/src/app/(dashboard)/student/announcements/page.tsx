import { createClient } from "@/lib/supabase/server";
import { Card, Badge, EmptyState, ErrorState } from "@/components/ui/primitives";
import { fmtDate } from "@/components/ui/helpers";

export default async function Page() {
  const supabase = createClient();
  const { data, error } = await supabase.from("announcements").select("*").order("is_pinned", { ascending: false }).order("created_at", { ascending: false });
  if (error) return <ErrorState message={error.message} />;
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">Announcements</h1>
      {!data?.length ? <EmptyState title="No announcements" description="Check back later." /> : data.map((a) => (
        <Card key={a.id}>
          <div className="flex items-center gap-2"><h3 className="font-semibold">{a.title}</h3>{a.is_pinned && <Badge tone="purple">Pinned</Badge>}</div>
          <p className="mt-1 whitespace-pre-wrap text-sm text-slate-600">{a.body}</p>
          <p className="mt-2 text-xs text-slate-400">{fmtDate(a.created_at)}</p>
        </Card>
      ))}
    </div>
  );
}
