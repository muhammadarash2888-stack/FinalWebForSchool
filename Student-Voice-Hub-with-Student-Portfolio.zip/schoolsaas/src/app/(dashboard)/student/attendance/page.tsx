import { StudentAttendance } from "@/components/features/student-records";
export default function Page() { return <StudentAttendance />; }
