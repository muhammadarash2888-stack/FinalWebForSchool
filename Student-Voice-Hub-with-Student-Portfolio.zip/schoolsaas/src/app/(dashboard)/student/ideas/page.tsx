import { createClient } from "@/lib/supabase/server";
import { requireProfile } from "@/lib/auth";
import { Card, CardHeader, Input, Textarea, Label, Badge, EmptyState, ErrorState } from "@/components/ui/primitives";
import { ActionForm } from "@/components/ui/action-form";
import { submitIdeaAction } from "@/app/actions/ideas";
import { fmtDate, toneFor } from "@/components/ui/helpers";

export default async function Page() {
  const profile = await requireProfile();
  const supabase = createClient();
  const { data: ideas, error } = await supabase.from("ideas").select("*").eq("created_by", profile.id).order("created_at", { ascending: false });
  if (error) return <ErrorState message={error.message} />;
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">My ideas</h1>
      <Card>
        <CardHeader title="Share an idea" description="Suggest something that would make school better." />
        <ActionForm action={submitIdeaAction} submitLabel="Submit idea" successMessage="Idea submitted">
          <div><Label>Title</Label><Input name="title" required /></div>
          <div><Label>Category (optional)</Label><Input name="category" placeholder="Sports, Library, Canteen…" /></div>
          <div><Label>Describe your idea</Label><Textarea name="description" rows={4} required /></div>
        </ActionForm>
      </Card>
      {!ideas?.length ? <EmptyState title="No ideas yet" description="Your submitted ideas and their status will appear here." /> : (
        <div className="space-y-3">{ideas.map((i) => (
          <Card key={i.id}>
            <div className="flex items-start justify-between gap-3"><h3 className="font-semibold">{i.title}</h3><Badge tone={toneFor(i.status)}>{i.status.replace("_", " ")}</Badge></div>
            <p className="mt-1 text-sm text-slate-600">{i.description}</p>
            {i.admin_notes && <p className="mt-2 rounded-lg bg-slate-50 p-2 text-sm text-slate-600"><strong>Response:</strong> {i.admin_notes}</p>}
            <p className="mt-2 text-xs text-slate-400">{fmtDate(i.created_at)}</p>
          </Card>
        ))}</div>
      )}
    </div>
  );
}
