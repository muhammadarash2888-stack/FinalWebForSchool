import { createClient } from "@/lib/supabase/server";
import { requireProfile } from "@/lib/auth";
import { Card, CardHeader, Input, Textarea, Select, Label, Badge, EmptyState, ErrorState } from "@/components/ui/primitives";
import { ActionForm } from "@/components/ui/action-form";
import { reportIssueAction } from "@/app/actions/issues";
import { fmtDate, toneFor } from "@/components/ui/helpers";

export default async function Page() {
  const profile = await requireProfile();
  const supabase = createClient();
  const { data: issues, error } = await supabase.from("issues").select("*").eq("created_by", profile.id).order("created_at", { ascending: false });
  if (error) return <ErrorState message={error.message} />;
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">Report an issue</h1>
      <Card>
        <CardHeader title="What's wrong?" description="Broken equipment, safety concerns, cleanliness…" />
        <ActionForm action={reportIssueAction} submitLabel="Submit report" successMessage="Issue reported">
          <div><Label>Title</Label><Input name="title" required /></div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div><Label>Location</Label><Input name="location" placeholder="Room 204, playground…" /></div>
            <div><Label>Severity</Label><Select name="severity" defaultValue="medium"><option value="low">Low</option><option value="medium">Medium</option><option value="high">High</option><option value="urgent">Urgent</option></Select></div>
          </div>
          <div><Label>Details</Label><Textarea name="description" rows={4} required /></div>
        </ActionForm>
      </Card>
      {!issues?.length ? <EmptyState title="No reports yet" /> : (
        <div className="space-y-3">{issues.map((i) => (
          <Card key={i.id}>
            <div className="flex items-start justify-between gap-3"><h3 className="font-semibold">{i.title}</h3><Badge tone={toneFor(i.status)}>{i.status.replace("_", " ")}</Badge></div>
            <p className="mt-1 text-sm text-slate-600">{i.description}</p>
            {i.resolution_notes && <p className="mt-2 rounded-lg bg-slate-50 p-2 text-sm text-slate-600"><strong>Update:</strong> {i.resolution_notes}</p>}
            <p className="mt-2 text-xs text-slate-400">{fmtDate(i.created_at)}</p>
          </Card>
        ))}</div>
      )}
    </div>
  );
}
