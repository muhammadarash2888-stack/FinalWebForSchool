import { requireProfile, assertRole } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { DashboardShell } from "@/components/layout/dashboard-shell";

export default async function StudentLayout({ children }: { children: React.ReactNode }) {
  const profile = await requireProfile();
  assertRole(profile, ["student"]);

  const supabase = createClient();
  const { data: school } = await supabase
    .from("schools")
    .select("name,logo_url,primary_color")
    .eq("id", profile.school_id!)
    .single();

  return (
    <DashboardShell
      role="student"
      schoolName={school?.name ?? "Your School"}
      logoUrl={school?.logo_url ?? null}
      brandColor={school?.primary_color ?? null}
      userName={profile.full_name || profile.email || "Student"}
      userEmail={profile.email ?? ""}
    >
      {children}
    </DashboardShell>
  );
}
