import { createClient } from "@/lib/supabase/server";
import { requireProfile } from "@/lib/auth";
import { Card, CardHeader, StatCard, EmptyState } from "@/components/ui/primitives";
import { fmtDate } from "@/components/ui/helpers";
import Link from "next/link";

export default async function StudentHome() {
  const profile = await requireProfile();
  const supabase = createClient();
  const start = new Date(); start.setDate(start.getDate() - 30);
  const since = new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Dubai", year: "numeric", month: "2-digit", day: "2-digit" }).format(start);
  const [{ data: ann }, { count: polls }, { count: ideas }, { data: attendance }, { data: results }] = await Promise.all([
    supabase.from("announcements").select("id,title,body,created_at").order("created_at", { ascending: false }).limit(3),
    supabase.from("polls").select("*", { count: "exact", head: true }).eq("is_active", true),
    supabase.from("ideas").select("*", { count: "exact", head: true }).eq("created_by", profile.id),
    supabase.from("attendance_records").select("id,status,attendance_date").eq("student_id", profile.id).gte("attendance_date", since).order("attendance_date", { ascending: false }).limit(60),
    supabase.from("academic_results").select("id,assessment_id,score,graded_at").eq("student_id", profile.id).order("graded_at", { ascending: false }).limit(30),
  ]);
  const attendanceRows = attendance ?? [];
  const eligible = attendanceRows.filter((row) => row.status !== "excused").length;
  const attended = attendanceRows.filter((row) => row.status === "present" || row.status === "late").length;
  const attendanceRate = eligible ? (attended / eligible) * 100 : null;
  const ids = Array.from(new Set((results ?? []).map((row) => row.assessment_id)));
  const { data: assessments } = ids.length ? await supabase.from("academic_assessments").select("id,max_score,title,subject").in("id", ids) : { data: [] };
  const assessmentMap = new Map((assessments ?? []).map((assessment: any) => [assessment.id, assessment]));
  const graded = (results ?? []).filter((row) => assessmentMap.has(row.assessment_id));
  const gradeAverage = graded.length ? graded.reduce((sum, row) => sum + Number(row.score) / Number((assessmentMap.get(row.assessment_id) as any).max_score) * 100, 0) / graded.length : null;
  return (
    <div className="space-y-7">
      <section className="relative isolate overflow-hidden rounded-3xl border border-slate-200/80 bg-white px-6 py-7 shadow-sm sm:px-8 sm:py-8">
        <div aria-hidden="true" className="absolute -right-8 -top-12 -z-10 h-52 w-52 rounded-full bg-cyan-100/70 blur-3xl" />
        <p className="mb-3 inline-flex items-center gap-2 rounded-full border border-cyan-100 bg-cyan-50 px-3 py-1.5 text-[11px] font-bold uppercase tracking-[.16em] text-cyan-900"><span className="h-1.5 w-1.5 rounded-full bg-cyan-600" /> Your school community</p>
        <h1 className="text-2xl font-black tracking-tight text-slate-950 sm:text-3xl">Welcome, {profile.full_name || "student"}</h1>
        <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-600">Your school records and student voice tools are together in one place. Follow your attendance and academic progress, share an idea, and take part in school polls.</p>
        <div className="mt-5 flex flex-wrap gap-3"><Link href="/student/ideas" className="rounded-xl bg-brand px-4 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:opacity-90">Share an idea <span aria-hidden="true">→</span></Link><Link href="/student/polls" className="rounded-xl border border-slate-200 bg-white px-4 py-2.5 text-sm font-semibold text-slate-700 transition hover:border-slate-300 hover:bg-slate-50">Vote in a poll</Link></div>
      </section>
      <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4"><StatCard label="Attendance · 30 days" value={attendanceRate === null ? "—" : `${attendanceRate.toFixed(1)}%`} hint="Based on recorded non-excused days" /><StatCard label="Recent grade average" value={gradeAverage === null ? "—" : `${gradeAverage.toFixed(1)}%`} hint={`${graded.length} available assessment results`} /><StatCard label="Open polls" value={polls ?? 0} hint="Active school polls" /><StatCard label="Ideas you submitted" value={ideas ?? 0} hint="Your ideas sent to the school" /></section>
      <section className="grid gap-4 md:grid-cols-2"><Link href="/student/attendance" className="group rounded-2xl border border-slate-200 bg-white p-5 shadow-sm transition hover:border-cyan-200 hover:shadow-md"><div className="flex items-center justify-between"><span className="flex h-11 w-11 items-center justify-center rounded-xl bg-cyan-50 text-xl text-cyan-800">✓</span><span className="text-slate-300 transition group-hover:translate-x-1 group-hover:text-cyan-700">→</span></div><h2 className="mt-4 font-bold text-slate-900">My attendance record</h2><p className="mt-1 text-sm leading-6 text-slate-500">See dates marked present, absent, late or excused.</p></Link><Link href="/student/academics" className="group rounded-2xl border border-slate-200 bg-white p-5 shadow-sm transition hover:border-violet-200 hover:shadow-md"><div className="flex items-center justify-between"><span className="flex h-11 w-11 items-center justify-center rounded-xl bg-violet-50 text-xl text-violet-800">↗</span><span className="text-slate-300 transition group-hover:translate-x-1 group-hover:text-violet-700">→</span></div><h2 className="mt-4 font-bold text-slate-900">My academic progress</h2><p className="mt-1 text-sm leading-6 text-slate-500">Review published assessment marks and teacher feedback.</p></Link></section>
      <Card className="rounded-2xl border-slate-200/80 p-5 sm:p-6"><CardHeader title="Latest announcements" description="The newest updates shared by your school." action={<Link href="/student/announcements" className="text-sm font-semibold text-brand hover:underline">View all</Link>} />{!ann?.length ? <EmptyState title="Nothing new" description="Announcements from your school will show up here." /> : <ul className="space-y-4">{ann.map((a) => <li key={a.id}><p className="font-medium">{a.title}</p><p className="line-clamp-2 text-sm text-slate-600">{a.body}</p><p className="text-xs text-slate-400">{fmtDate(a.created_at)}</p></li>)}</ul>}</Card>
    </div>
  );
}
