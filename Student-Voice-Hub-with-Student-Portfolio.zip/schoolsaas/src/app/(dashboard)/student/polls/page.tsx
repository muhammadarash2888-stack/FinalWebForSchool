import { createClient } from "@/lib/supabase/server";
import { requireProfile } from "@/lib/auth";
import { Card, CardHeader, Badge, EmptyState, ErrorState } from "@/components/ui/primitives";
import { VoteForm } from "./vote-form";

export default async function Page() {
  const profile = await requireProfile();
  const supabase = createClient();
  const { data: polls, error } = await supabase.from("polls").select("*, poll_options(id,label,display_order)").eq("is_active", true).order("created_at", { ascending: false });
  const { data: myVotes } = await supabase.from("votes").select("poll_id,poll_option_id").eq("voter_id", profile.id);
  if (error) return <ErrorState message={error.message} />;
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">Polls</h1>
      {!polls?.length ? <EmptyState title="No open polls" description="When a teacher opens a poll it will appear here." /> : (
        <div className="grid gap-4 md:grid-cols-2">
          {polls.map((p: any) => {
            const mine = myVotes?.find((v) => v.poll_id === p.id);
            const opts = [...p.poll_options].sort((a: any, b: any) => a.display_order - b.display_order);
            return (
              <Card key={p.id}>
                <CardHeader title={p.title} description={p.description ?? undefined} action={mine ? <Badge tone="green">Voted</Badge> : undefined} />
                {mine ? (
                  <p className="text-sm text-slate-600">You voted for <strong>{opts.find((o: any) => o.id === mine.poll_option_id)?.label}</strong>. Thanks for taking part!</p>
                ) : <VoteForm pollId={p.id} options={opts} />}
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
