"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/primitives";
import { useToast } from "@/components/ui/toast";
import { castVoteAction } from "@/app/actions/polls";

export function VoteForm({ pollId, options }: { pollId: string; options: { id: string; label: string }[] }) {
  const [choice, setChoice] = useState("");
  const [loading, setLoading] = useState(false);
  const toast = useToast();
  const router = useRouter();
  return (
    <div className="space-y-2">
      {options.map((o) => (
        <label key={o.id} className="flex cursor-pointer items-center gap-3 rounded-lg border border-slate-200 px-3 py-2 text-sm hover:bg-slate-50">
          <input type="radio" name={`poll-${pollId}`} value={o.id} checked={choice === o.id} onChange={() => setChoice(o.id)} />
          {o.label}
        </label>
      ))}
      <Button loading={loading} disabled={!choice} onClick={async () => {
        setLoading(true);
        const res = await castVoteAction(pollId, choice);
        setLoading(false);
        if (res.error) toast.push(res.error, "error");
        else { toast.push("Vote recorded", "success"); router.refresh(); }
      }}>Submit vote</Button>
    </div>
  );
}
