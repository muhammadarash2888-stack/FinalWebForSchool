import { requireProfile } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { StudentPortfolio } from "@/components/features/student-portfolio";

export default async function Page() {
  const profile = await requireProfile();
  const supabase = createClient();
  const { data } = await supabase.from("student_portfolio_items").select("id,title,category,issuer,achievement_date,description,file_path,review_status,reviewer_notes,created_at").eq("student_id", profile.id).order("created_at", { ascending: false });
  return <StudentPortfolio items={(data || []) as any} />;
}
