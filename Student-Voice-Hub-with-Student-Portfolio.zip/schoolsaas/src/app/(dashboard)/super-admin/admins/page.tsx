import { createClient } from "@/lib/supabase/server";
import { Card, CardHeader, Input, Select, Label, Badge, EmptyState, ErrorState, Table, Thead, Tbody, Td } from "@/components/ui/primitives";
import { ActionForm, ActionButton } from "@/components/ui/action-form";
import { createUserAction, setUserActiveAction } from "@/app/actions/admin";

export default async function Page() {
  const supabase = createClient();
  const { data: schools } = await supabase.from("schools").select("id,name").order("name");
  const { data: admins, error } = await supabase.from("profiles").select("*, school:schools(name)").eq("role", "school_admin").order("full_name");
  if (error) return <ErrorState message={error.message} />;
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">School administrators</h1>
      <Card>
        <CardHeader title="Add an administrator" />
        <ActionForm action={createUserAction} submitLabel="Add administrator" successMessage="Administrator added">
          <input type="hidden" name="role" value="school_admin" />
          <div className="grid gap-4 sm:grid-cols-2">
            <div><Label>School</Label><Select name="school_id" required>{schools?.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}</Select></div>
            <div><Label>Full name</Label><Input name="full_name" required /></div>
            <div><Label>Email</Label><Input name="email" type="email" required /></div>
            <div><Label>Temporary password</Label><Input name="password" type="password" minLength={8} required /></div>
          </div>
        </ActionForm>
      </Card>
      {!admins?.length ? <EmptyState title="No administrators" /> : (
        <Table>
          <Thead columns={["Name", "Email", "School", "Status", ""]} />
          <Tbody>{admins.map((a: any) => (
            <tr key={a.id}><Td>{a.full_name}</Td><Td>{a.email}</Td><Td>{a.school?.name ?? "—"}</Td>
              <Td><Badge tone={a.is_active ? "green" : "red"}>{a.is_active ? "Active" : "Deactivated"}</Badge></Td>
              <Td><ActionButton variant="ghost" run={setUserActiveAction.bind(null, a.id, !a.is_active)}>{a.is_active ? "Deactivate" : "Reactivate"}</ActionButton></Td></tr>
          ))}</Tbody>
        </Table>
      )}
    </div>
  );
}
