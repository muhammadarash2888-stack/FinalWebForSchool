import { requireProfile, assertRole } from "@/lib/auth";
import { DashboardShell } from "@/components/layout/dashboard-shell";

export default async function SuperAdminLayout({ children }: { children: React.ReactNode }) {
  const profile = await requireProfile();
  assertRole(profile, ["super_admin"]);

  return (
    <DashboardShell
      role="super_admin"
      schoolName="Company Admin"
      userName={profile.full_name || profile.email || "Super Admin"}
      userEmail={profile.email ?? ""}
    >
      {children}
    </DashboardShell>
  );
}
