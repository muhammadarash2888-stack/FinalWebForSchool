import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { StatCard, Card, CardHeader, Badge, EmptyState } from "@/components/ui/primitives";
import { fmtDate, toneFor } from "@/components/ui/helpers";

export default async function Page() {
  const supabase = createClient();
  const { data: schools } = await supabase.from("schools").select("id,name,status,created_at").order("created_at", { ascending: false });
  const c = async (t: string, role?: string) => {
    let q: any = supabase.from(t).select("*", { count: "exact", head: true });
    if (role) q = q.eq("role", role);
    return (await q).count ?? 0;
  };
  const [students, teachers, polls, votes, ideas, issues] = await Promise.all([c("profiles", "student"), c("profiles", "teacher"), c("polls"), c("votes"), c("ideas"), c("issues")]);
  const active = schools?.filter((s) => s.status === "active").length ?? 0;

  return (
    <div className="space-y-7">
      <section className="relative isolate overflow-hidden rounded-3xl border border-slate-200/80 bg-white p-6 shadow-sm sm:p-8">
        <div aria-hidden="true" className="absolute -right-8 -top-16 -z-10 h-60 w-60 rounded-full bg-cyan-100/70 blur-3xl" />
        <div className="flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between">
          <div><p className="mb-3 inline-flex items-center gap-2 rounded-full border border-cyan-100 bg-cyan-50 px-3 py-1.5 text-[11px] font-bold uppercase tracking-[.16em] text-cyan-900"><span className="h-1.5 w-1.5 rounded-full bg-cyan-600" /> Platform control center</p><h1 className="text-2xl font-black tracking-tight text-slate-950 sm:text-3xl">Platform overview</h1><p className="mt-2 max-w-2xl text-sm leading-6 text-slate-600">Monitor school workspaces, user participation, and the feedback flowing through Student Voice Hub.</p></div>
          <Link href="/super-admin/schools" className="inline-flex items-center justify-center rounded-xl bg-brand px-4 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:opacity-90">Manage schools <span className="ml-2" aria-hidden="true">→</span></Link>
        </div>
      </section>

      <section aria-label="Platform metrics" className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Schools" value={schools?.length ?? 0} hint={`${active} active`} />
        <StatCard label="Students" value={students} hint="Student profiles" />
        <StatCard label="Teachers" value={teachers} hint="Teacher profiles" />
        <StatCard label="Polls" value={polls} hint="Created across the platform" />
        <StatCard label="Votes" value={votes} hint="Recorded responses" />
        <StatCard label="Ideas" value={ideas} hint="Submitted suggestions" />
        <StatCard label="Issues" value={issues} hint="Reported school issues" />
      </section>

      <Card className="rounded-2xl border-slate-200/80 p-5 sm:p-6">
        <CardHeader title="Newest schools" description="Recently added school workspaces." action={<Link href="/super-admin/schools" className="text-sm font-semibold text-brand hover:underline">View all schools</Link>} />
        {!schools?.length ? <EmptyState title="No schools yet" description="Add your first school from the Schools page." action={<Link href="/super-admin/schools" className="text-sm font-semibold text-brand hover:underline">Open school management</Link>} /> : (
          <ul className="divide-y divide-slate-100/90">{schools.slice(0, 6).map((s) => (
            <li key={s.id} className="flex flex-col gap-2 py-3.5 sm:flex-row sm:items-center sm:justify-between"><span className="font-medium text-slate-800">{s.name}</span><span className="flex items-center justify-between gap-3 sm:justify-end"><Badge tone={toneFor(s.status)}>{s.status}</Badge><time className="text-xs text-slate-400">{fmtDate(s.created_at)}</time></span></li>
          ))}</ul>
        )}
      </Card>
      <p className="text-xs leading-5 text-slate-400">Counts reflect records visible to the signed-in administrator under the current Supabase policies.</p>
    </div>
  );
}
