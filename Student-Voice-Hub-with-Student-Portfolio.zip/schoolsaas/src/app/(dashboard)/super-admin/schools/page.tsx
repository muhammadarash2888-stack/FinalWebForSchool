import { createClient } from "@/lib/supabase/server";
import { Card, CardHeader, Input, Label, Badge, EmptyState, ErrorState, Table, Thead, Tbody, Td } from "@/components/ui/primitives";
import { ActionForm } from "@/components/ui/action-form";
import { createSchoolAction, updateSchoolAction } from "@/app/actions/admin";
import { StatusSelect } from "@/components/ui/action-form";
import { fmtDate } from "@/components/ui/helpers";

const STATUSES = ["active", "trial", "suspended", "cancelled"].map((v) => ({ value: v, label: v }));

export default async function Page() {
  const supabase = createClient();
  const { data: schools, error } = await supabase.from("schools").select("*").order("created_at", { ascending: false });
  if (error) return <ErrorState message={error.message} />;
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">Schools</h1>
      <Card>
        <CardHeader title="Add a school" description="Creates the school and its first administrator login." />
        <ActionForm action={createSchoolAction} submitLabel="Create school" successMessage="School created">
          <div className="grid gap-4 sm:grid-cols-2">
            <div><Label>School name</Label><Input name="name" required placeholder="Shining Star School" /></div>
            <div><Label>Slug</Label><Input name="slug" required placeholder="shining-star" pattern="[a-z0-9-]+" /></div>
            <div><Label>Logo URL (optional)</Label><Input name="logo_url" type="url" placeholder="https://…" /></div>
            <div><Label>Brand colour</Label><Input name="primary_color" type="color" defaultValue="#4f46e5" className="h-10 p-1" /></div>
            <div><Label>Administrator name</Label><Input name="admin_name" required /></div>
            <div><Label>Administrator email</Label><Input name="admin_email" type="email" required /></div>
            <div><Label>Administrator temporary password</Label><Input name="admin_password" type="password" minLength={8} required /></div>
          </div>
        </ActionForm>
      </Card>
      {!schools?.length ? <EmptyState title="No schools yet" /> : (
        <Table>
          <Thead columns={["School", "Slug", "Plan", "Created", "Status"]} />
          <Tbody>
            {schools.map((s) => (
              <tr key={s.id}>
                <Td><span className="flex items-center gap-2">{s.logo_url && /* eslint-disable-next-line @next/next/no-img-element */ <img src={s.logo_url} alt="" className="h-6 w-6 rounded object-cover" />}<span className="font-medium">{s.name}</span></span></Td>
                <Td>{s.slug}</Td><Td>{s.subscription_plan ?? "—"}</Td><Td>{fmtDate(s.created_at)}</Td>
                <Td><StatusSelect value={s.status} options={STATUSES} onChange={updateStatus.bind(null, s.id)} /></Td>
              </tr>
            ))}
          </Tbody>
        </Table>
      )}
    </div>
  );
}

async function updateStatus(id: string, status: string) {
  "use server";
  return updateSchoolAction(id, { status: status as any });
}
