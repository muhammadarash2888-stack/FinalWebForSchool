import { AcademicsManager } from "@/components/features/academics-manager";
export default function Page({ searchParams }: { searchParams?: { [key: string]: string | string[] | undefined; assessment?: string | string[]; error?: string | string[]; saved?: string | string[] } }) {
  return <AcademicsManager basePath="/teacher/academics" searchParams={searchParams} />;
}
