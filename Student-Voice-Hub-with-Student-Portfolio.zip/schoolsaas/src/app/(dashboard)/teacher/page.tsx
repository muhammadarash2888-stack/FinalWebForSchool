import { TeacherDashboard } from "@/components/features/teacher-dashboard";
export default function Page() { return <TeacherDashboard />; }
