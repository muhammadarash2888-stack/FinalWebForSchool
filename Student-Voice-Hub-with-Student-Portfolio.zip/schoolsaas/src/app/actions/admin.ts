"use server";

import { revalidatePath } from "next/cache";
import { createClient, createAdminClient } from "@/lib/supabase/server";
import { requireProfile } from "@/lib/auth";
import type { SchoolStatus, UserRole } from "@/types/database";

async function requireSuper() {
  const p = await requireProfile();
  if (p.role !== "super_admin") throw new Error("Forbidden");
  return p;
}

/** Super admin: create school + its first school administrator. */
export async function createSchoolAction(formData: FormData) {
  try { await requireSuper(); } catch { return { error: "Forbidden" }; }

  const name = String(formData.get("name") || "").trim();
  const slug = String(formData.get("slug") || "").trim().toLowerCase().replace(/[^a-z0-9-]/g, "-");
  const logo_url = String(formData.get("logo_url") || "").trim() || null;
  const primary_color = String(formData.get("primary_color") || "#4f46e5");
  const adminName = String(formData.get("admin_name") || "").trim();
  const adminEmail = String(formData.get("admin_email") || "").trim();
  const adminPassword = String(formData.get("admin_password") || "");

  if (!name || !slug) return { error: "School name and slug are required." };
  if (!adminEmail || adminPassword.length < 8) return { error: "Admin email and a password of 8+ characters are required." };

  const supabase = createClient(); // RLS: only super_admin may insert
  const { data: school, error } = await supabase
    .from("schools")
    .insert({ name, slug, logo_url, primary_color, status: "active" })
    .select("id")
    .single();
  if (error || !school) return { error: error?.message ?? "Could not create school." };

  // Privileged step: create auth user. Service key is server-only.
  const admin = createAdminClient();
  const { error: userErr } = await admin.auth.admin.createUser({
    email: adminEmail,
    password: adminPassword,
    email_confirm: true,
    user_metadata: { full_name: adminName, role: "school_admin", school_id: school.id },
  });
  if (userErr) {
    await supabase.from("schools").delete().eq("id", school.id); // roll back
    return { error: userErr.message };
  }

  revalidatePath("/super-admin/schools");
  revalidatePath("/super-admin");
  return { success: true };
}

export async function updateSchoolAction(id: string, patch: { name?: string; logo_url?: string | null; primary_color?: string; status?: SchoolStatus }) {
  try { await requireSuper(); } catch { return { error: "Forbidden" }; }
  const supabase = createClient();
  const { error } = await supabase.from("schools").update(patch).eq("id", id);
  if (error) return { error: error.message };
  revalidatePath("/super-admin/schools");
  return { success: true };
}

/** School admin (or super admin): create a student/teacher account in the caller's school. */
export async function createUserAction(formData: FormData) {
  const caller = await requireProfile();
  if (!["school_admin", "super_admin"].includes(caller.role)) return { error: "Forbidden" };

  const role = String(formData.get("role")) as UserRole;
  if (!["student", "teacher", "parent", "school_admin"].includes(role)) return { error: "Invalid role." };
  if (caller.role === "school_admin" && role === "school_admin") return { error: "Only the company can add school administrators." };

  const school_id = caller.role === "school_admin" ? caller.school_id! : String(formData.get("school_id") || "");
  if (!school_id) return { error: "School is required." };

  const full_name = String(formData.get("full_name") || "").trim();
  const email = String(formData.get("email") || "").trim();
  const password = String(formData.get("password") || "");
  const class_name = String(formData.get("class_name") || "").trim();
  const linked_student_id = String(formData.get("linked_student_id") || "").trim();
  if (!full_name || !email || password.length < 8) return { error: "Name, email and 8+ character password required." };

  const admin = createAdminClient();
  if (role === "parent") {
    if (!linked_student_id) return { error: "Choose the student linked to this parent account." };
    const { data: linkedStudent, error: linkedStudentError } = await admin.from("profiles")
      .select("id,school_id,role").eq("id", linked_student_id).single();
    if (linkedStudentError || !linkedStudent || linkedStudent.role !== "student" || linkedStudent.school_id !== school_id) {
      return { error: "The linked student must be an active student in the selected school." };
    }
  }
  const { data, error } = await admin.auth.admin.createUser({
    email, password, email_confirm: true,
    user_metadata: { full_name, role, school_id },
  });
  if (error || !data.user) return { error: error?.message ?? "Failed to create user." };

  if (class_name && role !== "parent") await admin.from("profiles").update({ class_name }).eq("id", data.user.id);
  if (role === "parent") {
    const { error: linkError } = await admin.from("parent_student_links").insert({
      school_id, parent_id: data.user.id, student_id: linked_student_id, relationship: "Parent/Guardian",
      is_verified: true, created_by: caller.id,
    });
    if (linkError) {
      await admin.auth.admin.deleteUser(data.user.id);
      return { error: `Parent account could not be linked to the student: ${linkError.message}` };
    }
  }

  for (const p of ["/school-admin/people", "/super-admin/admins", "/parent"]) revalidatePath(p);
  return { success: true };
}

export async function setUserActiveAction(userId: string, is_active: boolean) {
  const caller = await requireProfile();
  if (!["school_admin", "super_admin"].includes(caller.role)) return { error: "Forbidden" };
  const supabase = createClient(); // RLS restricts school_admin to own school
  const { error } = await supabase.from("profiles").update({ is_active }).eq("id", userId);
  if (error) return { error: error.message };
  revalidatePath("/school-admin/people");
  revalidatePath("/super-admin/admins");
  return { success: true };
}

/** Link another child to an existing parent account (for siblings at the same school). */
export async function linkParentToStudentAction(formData: FormData) {
  const caller = await requireProfile();
  if (caller.role !== "school_admin" || !caller.school_id) return { error: "Only your school's administrator can link family accounts." };
  const parentId = String(formData.get("parent_id") || "");
  const studentId = String(formData.get("student_id") || "");
  const relationship = String(formData.get("relationship") || "Parent/Guardian").trim().slice(0, 60);
  if (!parentId || !studentId) return { error: "Choose both a parent account and a student." };
  const admin = createAdminClient();
  const [{ data: parent }, { data: student }] = await Promise.all([
    admin.from("profiles").select("id,school_id,role").eq("id", parentId).single(),
    admin.from("profiles").select("id,school_id,role").eq("id", studentId).single(),
  ]);
  if (!parent || parent.role !== "parent" || parent.school_id !== caller.school_id
    || !student || student.role !== "student" || student.school_id !== caller.school_id) {
    return { error: "The parent and student must both belong to your school." };
  }
  const { error } = await admin.from("parent_student_links").upsert({
    school_id: caller.school_id, parent_id: parentId, student_id: studentId,
    relationship: relationship || "Parent/Guardian", is_verified: true, created_by: caller.id,
  }, { onConflict: "parent_id,student_id" });
  if (error) return { error: error.message };
  revalidatePath("/school-admin/people");
  revalidatePath("/parent");
  revalidatePath("/parent/attendance");
  revalidatePath("/parent/academics");
  return { success: true };
}
