"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { requireProfile } from "@/lib/auth";

export async function createAnnouncementAction(formData: FormData) {
  const profile = await requireProfile();
  if (!["school_admin", "teacher"].includes(profile.role)) return { error: "Not permitted." };

  const title = String(formData.get("title") || "").trim();
  const body = String(formData.get("body") || "").trim();
  const audienceRaw = String(formData.get("audience") || "all");
  const audience = (["all", "students", "teachers", "parents"].includes(audienceRaw) ? audienceRaw : "all") as "all" | "students" | "teachers" | "parents";
  const is_pinned = formData.get("is_pinned") === "on";
  if (!title || !body) return { error: "Title and message are required." };

  const supabase = createClient();
  const { error } = await supabase.from("announcements").insert({
    title, body, audience, is_pinned,
    school_id: profile.school_id!, created_by: profile.id,
  });
  if (error) return { error: error.message };

  for (const p of ["/school-admin/announcements", "/teacher/announcements", "/student/announcements", "/student", "/parent/announcements", "/parent"]) revalidatePath(p);
  return { success: true };
}

export async function deleteAnnouncementAction(id: string) {
  await requireProfile();
  const supabase = createClient();
  const { error } = await supabase.from("announcements").delete().eq("id", id);
  if (error) return { error: error.message };
  for (const p of ["/school-admin/announcements", "/teacher/announcements", "/student/announcements", "/parent/announcements", "/parent"]) revalidatePath(p);
  return { success: true };
}
