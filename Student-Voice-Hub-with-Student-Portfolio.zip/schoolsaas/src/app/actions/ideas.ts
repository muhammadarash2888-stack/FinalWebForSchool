"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { requireProfile } from "@/lib/auth";
import type { IdeaStatus } from "@/types/database";

export async function submitIdeaAction(formData: FormData) {
  const profile = await requireProfile();
  const title = String(formData.get("title") || "").trim();
  const description = String(formData.get("description") || "").trim();
  const category = String(formData.get("category") || "").trim();

  if (!title || !description) return { error: "Title and description are required." };

  const supabase = createClient();
  const { error } = await supabase.from("ideas").insert({
    title,
    description,
    category: category || null,
    school_id: profile.school_id!,
    created_by: profile.id,
  });

  if (error) return { error: error.message };

  revalidatePath("/student/ideas");
  revalidatePath("/school-admin/ideas");
  revalidatePath("/teacher/ideas");
  return { success: true };
}

export async function updateIdeaStatusAction(ideaId: string, status: IdeaStatus, adminNotes?: string) {
  const profile = await requireProfile();
  if (!["school_admin", "teacher"].includes(profile.role)) {
    return { error: "Not permitted." };
  }

  const supabase = createClient();
  const { error } = await supabase
    .from("ideas")
    .update({ status, admin_notes: adminNotes ?? undefined })
    .eq("id", ideaId);

  if (error) return { error: error.message };

  revalidatePath("/school-admin/ideas");
  revalidatePath("/teacher/ideas");
  revalidatePath("/student/ideas");
  return { success: true };
}
