"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { requireProfile } from "@/lib/auth";
import type { IssueSeverity, IssueStatus } from "@/types/database";

export async function reportIssueAction(formData: FormData) {
  const profile = await requireProfile();
  const title = String(formData.get("title") || "").trim();
  const description = String(formData.get("description") || "").trim();
  const location = String(formData.get("location") || "").trim();
  const severity = (String(formData.get("severity") || "medium") as IssueSeverity);

  if (!title || !description) return { error: "Title and description are required." };

  const supabase = createClient();
  const { error } = await supabase.from("issues").insert({
    title,
    description,
    location: location || null,
    severity,
    school_id: profile.school_id!,
    created_by: profile.id,
  });
  if (error) return { error: error.message };

  revalidatePath("/student/issues");
  revalidatePath("/school-admin/issues");
  revalidatePath("/teacher/issues");
  return { success: true };
}

export async function updateIssueStatusAction(issueId: string, status: IssueStatus, notes?: string) {
  const profile = await requireProfile();
  if (!["school_admin", "teacher"].includes(profile.role)) return { error: "Not permitted." };

  const supabase = createClient();
  const { error } = await supabase
    .from("issues")
    .update({ status, resolution_notes: notes ?? undefined })
    .eq("id", issueId);
  if (error) return { error: error.message };

  revalidatePath("/school-admin/issues");
  revalidatePath("/teacher/issues");
  revalidatePath("/student/issues");
  return { success: true };
}
