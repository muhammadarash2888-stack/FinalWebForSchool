"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { requireProfile } from "@/lib/auth";

export async function createPollAction(formData: FormData) {
  const profile = await requireProfile();
  if (!["school_admin", "teacher"].includes(profile.role)) {
    return { error: "You are not permitted to create polls." };
  }

  const title = String(formData.get("title") || "").trim();
  const description = String(formData.get("description") || "").trim();
  const optionsRaw = String(formData.get("options") || "");
  const options = optionsRaw
    .split("\n")
    .map((o) => o.trim())
    .filter(Boolean);

  if (!title) return { error: "Title is required." };
  if (options.length < 2) return { error: "Add at least two options, one per line." };

  const supabase = createClient();

  const { data: poll, error: pollError } = await supabase
    .from("polls")
    .insert({
      title,
      description: description || null,
      school_id: profile.school_id!,
      created_by: profile.id,
    })
    .select("id")
    .single();

  if (pollError || !poll) {
    return { error: pollError?.message ?? "Failed to create poll." };
  }

  const { error: optionsError } = await supabase.from("poll_options").insert(
    options.map((label, i) => ({
      poll_id: poll.id,
      school_id: profile.school_id!,
      label,
      display_order: i,
    }))
  );

  if (optionsError) {
    return { error: optionsError.message };
  }

  revalidatePath("/school-admin/polls");
  revalidatePath("/teacher/polls");
  revalidatePath("/student/polls");
  return { success: true };
}

export async function togglePollActiveAction(pollId: string, isActive: boolean) {
  const profile = await requireProfile();
  if (!["school_admin", "teacher"].includes(profile.role)) {
    return { error: "Not permitted." };
  }
  const supabase = createClient();
  const { error } = await supabase.from("polls").update({ is_active: isActive }).eq("id", pollId);
  if (error) return { error: error.message };

  revalidatePath("/school-admin/polls");
  revalidatePath("/teacher/polls");
  revalidatePath("/student/polls");
  return { success: true };
}

export async function castVoteAction(pollId: string, pollOptionId: string) {
  const profile = await requireProfile();
  if (profile.role !== "student") {
    return { error: "Only students can vote in this version of the platform." };
  }

  const supabase = createClient();

  // The database's `votes_one_per_student_per_poll` unique constraint is the
  // real enforcement layer — this insert will fail with a 23505 (unique
  // violation) if the student already voted, even if this check were bypassed.
  const { error } = await supabase.from("votes").insert({
    poll_id: pollId,
    poll_option_id: pollOptionId,
    school_id: profile.school_id!,
    voter_id: profile.id,
  });

  if (error) {
    if (error.code === "23505") {
      return { error: "You've already voted in this poll." };
    }
    return { error: error.message };
  }

  revalidatePath("/student/polls");
  return { success: true };
}
