"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { requireProfile } from "@/lib/auth";

const BUCKET = "student-portfolio";
const MAX_FILE_SIZE = 10 * 1024 * 1024;
const ALLOWED_TYPES = ["application/pdf", "image/jpeg", "image/png", "image/webp"];

export async function submitPortfolioItemAction(formData: FormData) {
  const profile = await requireProfile();
  if (profile.role !== "student" || !profile.school_id) return { error: "Only student accounts can submit portfolio items." };

  const title = String(formData.get("title") || "").trim();
  const category = String(formData.get("category") || "Other");
  const issuer = String(formData.get("issuer") || "").trim();
  const achievementDate = String(formData.get("achievement_date") || "");
  const description = String(formData.get("description") || "").trim();
  const file = formData.get("evidence");
  const categories = ["Certificate", "Award", "Competition", "Project", "Volunteering", "Leadership", "Other"];

  if (title.length < 2 || title.length > 140) return { error: "Enter a title between 2 and 140 characters." };
  if (!categories.includes(category)) return { error: "Choose a valid category." };
  if (!(file instanceof File) || file.size === 0) return { error: "Please attach a certificate or evidence file." };
  if (file.size > MAX_FILE_SIZE) return { error: "Files must be 10 MB or smaller." };
  if (!ALLOWED_TYPES.includes(file.type)) return { error: "Upload a PDF, JPG, PNG or WEBP file." };

  const supabase = createClient();
  const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, "_").slice(-100) || "evidence";
  const filePath = `${profile.school_id}/${profile.id}/${crypto.randomUUID()}-${safeName}`;
  const { error: uploadError } = await supabase.storage.from(BUCKET).upload(filePath, file, {
    contentType: file.type,
    upsert: false,
  });
  if (uploadError) return { error: `File upload failed: ${uploadError.message}` };

  const { error } = await supabase.from("student_portfolio_items").insert({
    school_id: profile.school_id,
    student_id: profile.id,
    title,
    category,
    issuer: issuer || null,
    achievement_date: achievementDate || null,
    description: description || null,
    file_path: filePath,
  });
  if (error) {
    await supabase.storage.from(BUCKET).remove([filePath]);
    return { error: error.message };
  }

  revalidatePath("/student/portfolio");
  revalidatePath("/teacher/portfolio");
  revalidatePath("/school-admin/portfolio");
  return { success: true };
}

export async function reviewPortfolioItemAction(itemId: string, status: "verified" | "needs_changes", notes: string) {
  const profile = await requireProfile();
  if (!["teacher", "school_admin"].includes(profile.role) || !profile.school_id) return { error: "Only school staff can review portfolio items." };
  const supabase = createClient();
  const { error } = await supabase.from("student_portfolio_items").update({
    review_status: status,
    reviewer_notes: notes.trim() || null,
  }).eq("id", itemId).eq("school_id", profile.school_id);
  if (error) return { error: error.message };
  revalidatePath("/teacher/portfolio");
  revalidatePath("/school-admin/portfolio");
  revalidatePath("/student/portfolio");
  return { success: true };
}

export async function getPortfolioFileUrlAction(filePath: string) {
  const profile = await requireProfile();
  if (!profile.school_id || !filePath.startsWith(`${profile.school_id}/`)) return { error: "Not permitted." };
  const supabase = createClient();
  const { data: item } = await supabase.from("student_portfolio_items").select("id").eq("file_path", filePath).maybeSingle();
  if (!item) return { error: "Evidence file not found or access denied." };
  const { data, error } = await supabase.storage.from(BUCKET).createSignedUrl(filePath, 60);
  if (error || !data?.signedUrl) return { error: error?.message || "Could not open evidence." };
  return { url: data.signedUrl };
}
