"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { requireProfile } from "@/lib/auth";

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
const ALLOWED_ATTENDANCE = new Set(["present", "absent", "late", "excused"]);

function dashboardBases(role: string) {
  return role === "school_admin"
    ? { attendance: "/school-admin/attendance", academics: "/school-admin/academics" }
    : { attendance: "/teacher/attendance", academics: "/teacher/academics" };
}

async function requireSchoolStaff() {
  const profile = await requireProfile();
  if (!profile.school_id || !["school_admin", "teacher"].includes(profile.role)) {
    throw new Error("Only school staff can manage attendance and grades.");
  }
  return profile;
}

export async function saveAttendanceAction(formData: FormData) {
  let profile;
  try { profile = await requireSchoolStaff(); }
  catch { return { error: "You do not have permission to manage attendance." }; }

  const date = String(formData.get("attendance_date") || "");
  const className = String(formData.get("class_name") || "").trim();
  if (!DATE_RE.test(date) || !className) return { error: "Choose a valid date and class before saving." };

  const statuses: Array<{ id: string; status: string }> = [];
  for (const [key, value] of formData.entries()) {
    if (!key.startsWith("status_")) continue;
    const id = key.slice("status_".length);
    const status = String(value);
    if (/^[0-9a-f-]{36}$/i.test(id) && ALLOWED_ATTENDANCE.has(status)) statuses.push({ id, status });
  }
  if (!statuses.length) return { error: "No attendance statuses were submitted." };
  if (statuses.length > 150) return { error: "Save one class register at a time (maximum 150 students per submission)." };

  const supabase = createClient();
  const studentIds = statuses.map((row) => row.id);
  const { data: students, error: studentsError } = await supabase
    .from("profiles").select("id")
    .eq("school_id", profile.school_id).eq("role", "student").eq("class_name", className)
    .in("id", studentIds);
  if (studentsError) return { error: "Could not validate the selected class. Please try again." };
  const validIds = new Set((students ?? []).map((student) => student.id));
  const records = statuses.filter((row) => validIds.has(row.id)).map((row) => ({
    school_id: profile.school_id!, student_id: row.id, attendance_date: date,
    status: row.status as "present" | "absent" | "late" | "excused", marked_by: profile.id,
  }));
  if (!records.length) return { error: "The submitted students do not match this class." };

  const { error } = await supabase.from("attendance_records").upsert(records, { onConflict: "school_id,student_id,attendance_date" });
  if (error) return { error: error.message };
  revalidatePath("/school-admin"); revalidatePath("/teacher"); revalidatePath("/parent"); revalidatePath("/student");
  revalidatePath("/school-admin/attendance"); revalidatePath("/teacher/attendance");
  return { success: true, message: `Saved attendance for ${records.length} students.` };
}

export async function createAssessmentAction(formData: FormData) {
  let profile;
  try { profile = await requireSchoolStaff(); }
  catch { redirect("/login?error=forbidden"); }
  const className = String(formData.get("class_name") || "").trim();
  const subject = String(formData.get("subject") || "").trim();
  const title = String(formData.get("title") || "").trim();
  const term = String(formData.get("term") || "Term 1").trim();
  const assessmentDate = String(formData.get("assessment_date") || "");
  const maxScore = Number(formData.get("max_score"));
  if (!className || !subject || !title || !DATE_RE.test(assessmentDate) || !Number.isFinite(maxScore) || maxScore <= 0 || maxScore > 100000) {
    redirect(`${dashboardBases(profile.role).academics}?error=invalid_assessment`);
  }
  const supabase = createClient();
  const { data, error } = await supabase.from("academic_assessments").insert({
    school_id: profile.school_id!, class_name: className, subject, title, term,
    assessment_date: assessmentDate, max_score: maxScore, created_by: profile.id,
  }).select("id").single();
  if (error || !data) redirect(`${dashboardBases(profile.role).academics}?error=create_failed`);
  revalidatePath("/school-admin"); revalidatePath("/teacher");
  redirect(`${dashboardBases(profile.role).academics}?assessment=${data.id}`);
}

export async function saveAssessmentResultsAction(formData: FormData) {
  let profile;
  try { profile = await requireSchoolStaff(); }
  catch { return { error: "You do not have permission to manage grades." }; }
  const assessmentId = String(formData.get("assessment_id") || "");
  if (!/^[0-9a-f-]{36}$/i.test(assessmentId)) return { error: "Choose a valid assessment." };
  const supabase = createClient();
  const { data: assessment, error: assessmentError } = await supabase.from("academic_assessments")
    .select("id,school_id,class_name,max_score").eq("id", assessmentId).eq("school_id", profile.school_id!).single();
  if (assessmentError || !assessment) return { error: "Assessment not found in your school." };

  const entries: Array<{ student_id: string; score: number; feedback: string | null }> = [];
  for (const [key, value] of formData.entries()) {
    if (!key.startsWith("score_")) continue;
    const studentId = key.slice("score_".length);
    const raw = String(value).trim();
    if (!raw) continue; // blank means not graded yet; it never overwrites an existing result
    const score = Number(raw);
    if (!/^[0-9a-f-]{36}$/i.test(studentId) || !Number.isFinite(score) || score < 0 || score > Number(assessment.max_score)) {
      return { error: `Each score must be between 0 and ${assessment.max_score}.` };
    }
    const feedbackRaw = String(formData.get(`feedback_${studentId}`) || "").trim();
    if (feedbackRaw.length > 1000) return { error: "Feedback must be 1,000 characters or fewer." };
    entries.push({ student_id: studentId, score, feedback: feedbackRaw || null });
  }
  if (!entries.length) return { error: "Enter at least one score before saving." };
  if (entries.length > 150) return { error: "Save one class gradebook at a time (maximum 150 students)." };

  const ids = entries.map((entry) => entry.student_id);
  const { data: validStudents, error: rosterError } = await supabase.from("profiles").select("id")
    .eq("school_id", profile.school_id!).eq("role", "student").eq("class_name", assessment.class_name).in("id", ids);
  if (rosterError) return { error: "Could not validate the class roster." };
  const valid = new Set((validStudents ?? []).map((student) => student.id));
  const rows = entries.filter((entry) => valid.has(entry.student_id)).map((entry) => ({
    school_id: profile.school_id!, assessment_id: assessment.id, student_id: entry.student_id,
    score: entry.score, feedback: entry.feedback, graded_by: profile.id,
  }));
  if (!rows.length) return { error: "The submitted students do not belong to this assessment's class." };
  const { error } = await supabase.from("academic_results").upsert(rows, { onConflict: "assessment_id,student_id" });
  if (error) return { error: error.message };
  revalidatePath("/school-admin"); revalidatePath("/teacher"); revalidatePath("/parent"); revalidatePath("/student");
  revalidatePath("/school-admin/academics"); revalidatePath("/teacher/academics");
  return { success: true, message: `Saved ${rows.length} result${rows.length === 1 ? "" : "s"}.` };
}
