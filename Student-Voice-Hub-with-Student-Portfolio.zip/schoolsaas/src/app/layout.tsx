import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Student Voice Hub | Your Ideas, Our School",
  description: "A student-powered platform to report school problems, share ideas, suggest improvements, and take part in polls.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen antialiased">{children}</body>
    </html>
  );
}
