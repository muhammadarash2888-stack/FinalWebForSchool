"use client";

import { useState, Suspense, type FormEvent } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { Button, Input, Label, InlineNotice } from "@/components/ui/primitives";

function getFriendlyAuthError(message: string) {
  const normalized = message.toLowerCase();
  if (normalized.includes("invalid login credentials") || normalized.includes("invalid email or password")) {
    return "The email or password does not match an account. Check both details and try again. If this is a new account, ask your school administrator to confirm that it has been created and activated.";
  }
  if (normalized.includes("email not confirmed")) {
    return "This email has not been confirmed yet. Check your inbox or contact your school administrator.";
  }
  if (normalized.includes("fetch") || normalized.includes("network") || normalized.includes("failed to") || normalized.includes("timeout")) {
    return "We could not reach the sign-in service. Check your internet connection and the Supabase settings in .env.local, then try again.";
  }
  if (normalized.includes("too many requests")) {
    return "There have been too many sign-in attempts. Please wait a few minutes before trying again.";
  }
  return "We could not sign you in. Check your details and try again. If the problem continues, contact your school administrator.";
}

function safeRedirectPath(value: string | null) {
  if (!value || !value.startsWith("/") || value.startsWith("//") || value.includes("\\") || value.startsWith("/login")) {
    return "/";
  }
  return value;
}

function LoginForm() {
  const router = useRouter();
  const params = useSearchParams();
  const redirectTo = safeRedirectPath(params.get("redirectTo"));
  const urlError = params.get("error");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(
    urlError === "inactive"
      ? "Your account has been deactivated. Contact your school administrator."
      : urlError === "no_profile"
      ? "Your sign-in exists, but its school profile is missing. Ask your school administrator to check your account setup."
      : null
  );

  async function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const supabase = createClient();
      const { error: signInError } = await supabase.auth.signInWithPassword({
        email: email.trim(),
        password,
      });
      if (signInError) {
        setError(getFriendlyAuthError(signInError.message));
        return;
      }
      router.replace(redirectTo);
      router.refresh();
    } catch {
      setError("The sign-in service could not be reached. Check your connection and make sure NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY are set correctly in .env.local.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="min-h-screen bg-[#f6f8fb] text-slate-900 lg:grid lg:grid-cols-[minmax(0,1fr)_minmax(420px,.9fr)]">
      <section className="relative hidden overflow-hidden bg-[#101d35] px-10 py-12 text-white lg:flex lg:flex-col lg:justify-between xl:px-16 xl:py-14">
        <div aria-hidden="true" className="absolute -right-32 top-20 h-96 w-96 rounded-full border border-white/10" />
        <div aria-hidden="true" className="absolute -right-12 top-40 h-72 w-72 rounded-full border border-white/10" />
        <div aria-hidden="true" className="absolute -bottom-28 -left-24 h-80 w-80 rounded-full bg-cyan-500/15 blur-3xl" />
        <div className="relative flex items-center gap-4">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/iis-shield.png" alt="International Indian School shield" className="h-16 w-16 rounded-2xl bg-white p-1.5 object-contain" />
          <div><p className="font-semibold tracking-tight">International Indian School</p><p className="mt-1 text-sm text-slate-300">Abu Dhabi</p></div>
        </div>
        <div className="relative max-w-xl py-16">
          <p className="mb-5 inline-flex items-center gap-2 rounded-full border border-cyan-200/20 bg-cyan-200/10 px-3 py-1.5 text-xs font-semibold uppercase tracking-[.16em] text-cyan-100"><span className="h-1.5 w-1.5 rounded-full bg-cyan-300" /> Student Voice Hub</p>
          <h1 className="text-4xl font-black leading-[1.08] tracking-tight xl:text-5xl">Good ideas start when every voice is heard.</h1>
          <p className="mt-6 max-w-lg text-base leading-8 text-slate-300">Sign in to share thoughtful feedback, take part in school polls, and stay connected with updates from your school community.</p>
          <div className="mt-9 grid max-w-lg grid-cols-3 gap-3">
            {[{ value: "Ideas", label: "Suggest improvements" }, { value: "Polls", label: "Share your view" }, { value: "Updates", label: "Stay informed" }].map((item) => <div key={item.value} className="rounded-2xl border border-white/10 bg-white/[.06] p-4"><p className="font-bold text-cyan-100">{item.value}</p><p className="mt-1 text-xs leading-5 text-slate-300">{item.label}</p></div>)}
          </div>
        </div>
        <p className="relative text-xs text-slate-400">Made by Muhammad Arsh</p>
      </section>

      <section className="flex min-h-screen items-center justify-center px-5 py-10 sm:px-8 lg:px-10">
        <div className="w-full max-w-md">
          <div className="mb-8 text-center lg:text-left">
            <Link href="/" className="mb-8 inline-flex items-center gap-3 lg:hidden">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src="/iis-shield.png" alt="International Indian School logo" className="h-12 w-12 rounded-xl border border-slate-200 bg-white object-contain p-1" />
              <span className="text-left"><span className="block text-sm font-bold">Student Voice Hub</span><span className="block text-xs text-slate-500">International Indian School, Abu Dhabi</span></span>
            </Link>
            <p className="text-xs font-bold uppercase tracking-[.18em] text-cyan-800">Welcome back</p>
            <h2 className="mt-2 text-3xl font-black tracking-tight text-slate-950">Sign in to your school</h2>
            <p className="mt-3 text-sm leading-6 text-slate-500">Use the email and password provided by your school administrator.</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5 rounded-3xl border border-slate-200/80 bg-white p-6 shadow-[0_18px_60px_-32px_rgba(15,23,42,.25)] sm:p-8">
            {error && <InlineNotice tone="error">{error}</InlineNotice>}
            <div>
              <Label>Email address</Label>
              <Input type="email" required autoComplete="username" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@school.edu" className="h-12 rounded-xl" />
            </div>
            <div>
              <div className="mb-1 flex items-center justify-between gap-3"><Label>Password</Label><span className="text-xs text-slate-400">Case-sensitive</span></div>
              <div className="relative">
                <Input type={showPassword ? "text" : "password"} required autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Enter your password" className="h-12 rounded-xl pr-20" />
                <button type="button" onClick={() => setShowPassword((value) => !value)} className="absolute inset-y-0 right-3 my-auto rounded-md px-2 text-xs font-semibold text-slate-500 hover:bg-slate-100 hover:text-slate-800" aria-label={showPassword ? "Hide password" : "Show password"}>{showPassword ? "Hide" : "Show"}</button>
              </div>
            </div>
            <Button type="submit" className="h-12 w-full rounded-xl text-sm font-semibold" loading={loading}>{loading ? "Signing you in…" : "Sign in securely"}<span aria-hidden="true">→</span></Button>
            <p className="text-center text-xs leading-5 text-slate-500">Having trouble signing in? Contact your school administrator to verify your account and access.</p>
          </form>
          <div className="mt-6 flex flex-col items-center justify-between gap-3 text-xs text-slate-400 sm:flex-row"><Link href="/" className="font-medium text-slate-600 hover:text-slate-950">← Back to home</Link><span>Made by Muhammad Arsh</span></div>
        </div>
      </section>
    </main>
  );
}

export default function LoginPage() {
  return (
    <Suspense fallback={<main className="flex min-h-screen items-center justify-center bg-slate-50 text-sm text-slate-500">Loading sign-in…</main>}>
      <LoginForm />
    </Suspense>
  );
}
