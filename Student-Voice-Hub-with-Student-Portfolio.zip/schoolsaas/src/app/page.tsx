import Link from "next/link";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { dashboardPathForRole } from "@/lib/auth";

export const dynamic = "force-dynamic";

const features = [
  { number: "01", title: "Report a problem", text: "Give the school a clear way to hear about issues that affect students." },
  { number: "02", title: "Share an idea", text: "Suggest practical improvements to school life, spaces, and activities." },
  { number: "03", title: "Suggest an improvement", text: "Turn everyday observations into ideas the school can review." },
  { number: "04", title: "Vote in polls", text: "Share your opinion on school topics through simple polls." },
  { number: "05", title: "Follow attendance", text: "Students and linked parents can review attendance records without searching huge school-wide lists." },
  { number: "06", title: "Review academic progress", text: "Keep assessment marks, percentages and teacher feedback in one secure school workspace." },
];

export default async function HomePage() {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();

  if (user) {
    const { data: profile } = await supabase
      .from("profiles")
      .select("role,is_active")
      .eq("id", user.id)
      .maybeSingle();

    if (profile?.is_active) redirect(dashboardPathForRole(profile.role));
  }

  return (
    <main className="min-h-screen overflow-hidden bg-[#f8f8f5] text-[#101d35]">
      <header className="mx-auto flex max-w-7xl items-center justify-between px-5 py-5 sm:px-8">
        <Link href="/" className="flex min-w-0 items-center gap-3" aria-label="Student Voice Hub home">
          <span className="flex h-12 w-28 shrink-0 items-center justify-center sm:h-14 sm:w-36">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src="/iis-abu-dhabi-logo.png" alt="International Indian School Abu Dhabi" className="max-h-full max-w-full object-contain" />
          </span>
          <span className="min-w-0 border-l border-slate-200 pl-3"><span className="block text-sm font-bold tracking-tight sm:text-base">Student Voice Hub</span><span className="hidden text-xs text-slate-500 sm:block">Ideas that move schools forward</span></span>
        </Link>
        <Link href="/login" className="rounded-full border border-slate-300 px-5 py-2.5 text-sm font-semibold transition hover:border-[#101d35] hover:bg-white">Sign in <span aria-hidden="true">↗</span></Link>
      </header>

      <section className="mx-auto grid max-w-7xl items-center gap-12 px-5 pb-16 pt-10 sm:px-8 sm:pb-24 sm:pt-16 lg:grid-cols-[1.05fr_.95fr] lg:gap-16">
        <div>
          <p className="mb-6 inline-flex items-center gap-2 rounded-full border border-[#b8eaf0] bg-[#e9fbfd] px-4 py-2 text-xs font-bold uppercase tracking-[.16em] text-[#126c7a]"><span className="h-2 w-2 rounded-full bg-[#17a9bf]" /> A platform for student ideas</p>
          <h1 className="max-w-3xl text-5xl font-black leading-[1.02] tracking-[-.055em] sm:text-6xl lg:text-7xl">Your voice can help shape <span className="relative inline-block text-[#087e91]">what comes next.<span className="absolute -bottom-1 left-0 -z-0 h-2 w-full bg-[#9cebf3]" /></span></h1>
          <p className="mt-7 max-w-xl text-base leading-8 text-slate-600 sm:text-lg">Student Voice Hub brings student feedback, school attendance, academic records and a secure family portal together in one school workspace.</p>
          <div className="mt-9 flex flex-wrap gap-3">
            <Link href="/login" className="rounded-full bg-[#101d35] px-6 py-3.5 text-sm font-bold text-white shadow-lg shadow-slate-900/10 transition hover:-translate-y-0.5 hover:bg-[#203653]">Enter the hub <span aria-hidden="true">→</span></Link>
            <a href="#how-it-works" className="rounded-full border border-slate-300 bg-white px-6 py-3.5 text-sm font-bold transition hover:border-[#101d35]">See how it works</a>
          </div>
          <p className="mt-5 text-xs leading-5 text-slate-500">A student-led concept designed for school review. Wider use should begin only with school approval.</p>
        </div>

        <div className="relative mx-auto w-full max-w-xl">
          <div className="absolute -right-6 -top-8 h-36 w-36 rounded-full bg-[#b9f1f5] blur-2xl" />
          <div className="absolute -bottom-8 -left-6 h-40 w-40 rounded-full bg-[#ffd9c9] blur-2xl" />
          <div className="relative rounded-[2rem] bg-[#101d35] p-5 text-white shadow-2xl shadow-slate-900/15 sm:p-7">
            <div className="flex items-center justify-between border-b border-white/15 pb-5"><div><p className="text-xs font-bold uppercase tracking-[.18em] text-[#73e2f2]">The student voice</p><h2 className="mt-1 text-xl font-bold">One place to be heard</h2></div><span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white/10 text-2xl">✳</span></div>
            <div className="mt-5 space-y-3">
              <div className="flex items-center gap-4 rounded-2xl bg-white/[.08] p-4"><span className="flex h-11 w-11 items-center justify-center rounded-xl bg-[#d9f8fb] text-xl text-[#126c7a]">↗</span><div className="flex-1"><p className="font-semibold">Report a problem</p><p className="mt-1 text-sm text-slate-300">Help identify an issue that needs attention.</p></div><span className="text-xl text-[#73e2f2]">→</span></div>
              <div className="flex items-center gap-4 rounded-2xl bg-white/[.08] p-4"><span className="flex h-11 w-11 items-center justify-center rounded-xl bg-[#ffeadf] text-xl text-[#9d4a2b]">✦</span><div className="flex-1"><p className="font-semibold">Share an idea</p><p className="mt-1 text-sm text-slate-300">Suggest a positive change for school life.</p></div><span className="text-xl text-[#73e2f2]">→</span></div>
              <div className="flex items-center gap-4 rounded-2xl bg-white/[.08] p-4"><span className="flex h-11 w-11 items-center justify-center rounded-xl bg-[#e8e2ff] text-xl text-[#5d48a5]">◉</span><div className="flex-1"><p className="font-semibold">Vote in a poll</p><p className="mt-1 text-sm text-slate-300">Make your opinion part of the conversation.</p></div><span className="text-xl text-[#73e2f2]">→</span></div>
            </div>
            <div className="mt-5 flex items-center justify-between rounded-xl border border-[#73e2f2]/30 bg-[#73e2f2]/10 px-4 py-3"><span className="text-sm text-slate-200">Listen carefully. Review fairly.</span><span className="text-xs font-bold uppercase tracking-wider text-[#73e2f2]">Student first</span></div>
          </div>
        </div>
      </section>

      <section id="how-it-works" className="border-y border-slate-200 bg-white py-16 sm:py-20">
        <div className="mx-auto max-w-7xl px-5 sm:px-8">
          <div className="max-w-2xl"><p className="text-xs font-bold uppercase tracking-[.18em] text-[#087e91]">How students can contribute</p><h2 className="mt-3 text-3xl font-black tracking-tight sm:text-4xl">Small observations can lead to better conversations.</h2><p className="mt-4 leading-7 text-slate-600">The hub brings different ways of sharing feedback together, so authorised school reviewers can look for themes and consider next steps.</p></div>
          <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {features.map((feature) => <article key={feature.number} className="rounded-2xl border border-slate-200 bg-[#fbfbf8] p-6 transition hover:-translate-y-1 hover:border-[#8bdce6]"><p className="text-sm font-black text-[#087e91]">{feature.number}</p><h3 className="mt-5 text-lg font-bold">{feature.title}</h3><p className="mt-2 text-sm leading-6 text-slate-600">{feature.text}</p></article>)}
          </div>
        </div>
      </section>

      <section className="mx-auto grid max-w-7xl gap-10 px-5 py-16 sm:px-8 sm:py-20 md:grid-cols-2 md:items-center">
        <div><p className="text-xs font-bold uppercase tracking-[.18em] text-[#087e91]">A thoughtful feedback loop</p><h2 className="mt-3 text-3xl font-black tracking-tight sm:text-4xl">Listening is the first step. Reviewing is the next.</h2></div>
        <ol className="space-y-4">
          {["A student shares feedback or votes in a poll.","The platform organises submissions for authorised reviewers.","School staff review themes and decide what can be acted on.","Where appropriate, updates can be shared with students."].map((step, index) => <li key={step} className="flex items-start gap-4"><span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-[#d9f8fb] text-sm font-black text-[#126c7a]">{index + 1}</span><p className="pt-1 text-sm leading-6 text-slate-700">{step}</p></li>)}
        </ol>
      </section>

      <footer className="bg-[#101d35] px-5 py-8 text-white sm:px-8"><div className="mx-auto flex max-w-7xl flex-col gap-4 sm:flex-row sm:items-center sm:justify-between"><div><p className="font-bold">Student Voice Hub</p><p className="mt-1 text-xs text-slate-300">A student-powered school improvement concept.</p><p className="mt-2 text-xs font-semibold text-slate-100">Made by Muhammad Arsh</p></div><p className="max-w-lg text-xs leading-5 text-slate-300">Feedback should be reviewed respectfully. Attendance and academic records are visible only to authorised school users, students, and guardians linked by the school. Feedback submissions are not a guarantee that every suggestion will be adopted.</p></div></footer>
    </main>
  );
}
