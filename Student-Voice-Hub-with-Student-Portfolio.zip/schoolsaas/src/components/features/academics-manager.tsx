import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { requireProfile } from "@/lib/auth";
import { createAssessmentAction, saveAssessmentResultsAction } from "@/app/actions/school-records";
import { ActionForm } from "@/components/ui/action-form";
import { Badge, Card, CardHeader, EmptyState, ErrorState, Input, Label, Select, StatCard } from "@/components/ui/primitives";

function dubaiToday() {
  return new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Dubai", year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date());
}

export async function AcademicsManager({ basePath, searchParams }: {
  basePath: "/school-admin/academics" | "/teacher/academics";
  searchParams?: { assessment?: string | string[]; error?: string | string[]; saved?: string | string[] };
}) {
  const profile = await requireProfile();
  const supabase = createClient();
  const [{ data: classRows }, { data: assessments, error: assessmentsError }, { count: resultCount }] = await Promise.all([
    supabase.from("school_class_summaries").select("class_name,student_count").eq("school_id", profile.school_id!).order("class_name"),
    supabase.from("academic_assessments").select("*").eq("school_id", profile.school_id!).order("assessment_date", { ascending: false }).limit(40),
    supabase.from("academic_results").select("id", { count: "exact", head: true }).eq("school_id", profile.school_id!),
  ]);
  const classes = Array.from(new Set((classRows ?? []).map((row) => row.class_name).filter((value): value is string => !!value))).sort((a, b) => a.localeCompare(b));
  const allAssessments = assessments ?? [];
  const assessmentParam = Array.isArray(searchParams?.assessment) ? searchParams.assessment[0] : searchParams?.assessment;
  const errorParam = Array.isArray(searchParams?.error) ? searchParams.error[0] : searchParams?.error;
  const selectedId = assessmentParam || allAssessments[0]?.id || "";
  const selectedAssessment = allAssessments.find((assessment) => assessment.id === selectedId) ?? null;
  let students: Array<{ id: string; full_name: string; class_name: string | null; email: string | null }> = [];
  let results: Array<{ student_id: string; score: number; feedback: string | null }> = [];
  let rosterCount = 0;
  let loadError: string | null = assessmentsError?.message ?? null;
  if (selectedAssessment) {
    const [{ data: roster, count, error: rosterError }, { data: scores, error: scoresError }] = await Promise.all([
      supabase.from("profiles").select("id,full_name,class_name,email", { count: "exact" }).eq("school_id", profile.school_id!)
        .eq("role", "student").eq("class_name", selectedAssessment.class_name).order("full_name").limit(150),
      supabase.from("academic_results").select("student_id,score,feedback").eq("school_id", profile.school_id!).eq("assessment_id", selectedAssessment.id),
    ]);
    students = roster ?? [];
    rosterCount = count ?? students.length;
    results = scores ?? [];
    if (rosterError || scoresError) loadError = rosterError?.message ?? scoresError?.message ?? null;
  }
  const scoreMap = new Map(results.map((row) => [row.student_id, row]));
  const average = results.length && selectedAssessment ? results.reduce((sum, row) => sum + (Number(row.score) / Number(selectedAssessment.max_score)) * 100, 0) / results.length : null;

  return (
    <div className="space-y-6">
      <section className="relative overflow-hidden rounded-3xl border border-slate-200 bg-white p-6 shadow-sm sm:p-8">
        <div aria-hidden="true" className="absolute -right-12 -top-14 h-56 w-56 rounded-full bg-violet-100/70 blur-3xl" />
        <p className="text-xs font-bold uppercase tracking-[.18em] text-violet-800">Academic records</p>
        <h1 className="mt-2 text-2xl font-black tracking-tight text-slate-950 sm:text-3xl">Academics &amp; gradebook</h1>
        <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-600">Create assessments, enter marks by class, and keep a consistent record for students and their linked parents. Scores are validated against the assessment maximum.</p>
      </section>

      <section className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
        <StatCard label="Assessments" value={allAssessments.length} hint="Most recent 40 assessments in this workspace" />
        <StatCard label="Grades recorded" value={resultCount ?? 0} hint="Saved student assessment results" />
        <StatCard label="Selected class average" value={average === null ? "—" : `${average.toFixed(1)}%`} hint="Average among graded students for this assessment" />
      </section>

      {errorParam === "invalid_assessment" && <ErrorState message="Please check the assessment details and maximum score." />}
      {errorParam === "create_failed" && <ErrorState message="The assessment could not be created. Check the class, subject and database migration." />}
      {loadError && <ErrorState message={`Some academic data could not be loaded: ${loadError}`} />}

      <Card>
        <CardHeader title="Create an assessment" description="Set the class, subject, date and maximum score before recording marks." />
        <form action={createAssessmentAction} className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          <div><Label>Class / grade</Label>{classes.length ? <Select name="class_name" required defaultValue=""><option value="" disabled>Select a class</option>{classes.map((name) => <option key={name} value={name}>{name}</option>)}</Select> : <Input name="class_name" required placeholder="Grade 7D" />}</div>
          <div><Label>Subject</Label><Input name="subject" required placeholder="Mathematics" maxLength={80} /></div>
          <div><Label>Assessment title</Label><Input name="title" required placeholder="Unit 2 quiz" maxLength={120} /></div>
          <div><Label>Term / reporting period</Label><Select name="term" defaultValue="Term 1"><option>Term 1</option><option>Term 2</option><option>Term 3</option><option>Mid-year</option><option>Final</option><option>Unit assessment</option></Select></div>
          <div><Label>Assessment date</Label><Input type="date" name="assessment_date" required defaultValue={dubaiToday()} /></div>
          <div><Label>Maximum score</Label><Input type="number" name="max_score" required min="0.01" max="100000" step="0.01" defaultValue="100" /></div>
          <div className="sm:col-span-2 xl:col-span-3"><button type="submit" className="rounded-lg bg-brand px-4 py-2.5 text-sm font-semibold text-white hover:opacity-90">Create assessment and open gradebook →</button></div>
        </form>
      </Card>

      <div className="grid gap-5 xl:grid-cols-[320px_minmax(0,1fr)]">
        <Card>
          <CardHeader title="Recent assessments" description="Choose a gradebook to view or update marks." />
          {!allAssessments.length ? <EmptyState title="No assessments yet" description="Create the first assessment above to start recording grades." /> : <div className="space-y-2">{allAssessments.map((assessment) => <Link key={assessment.id} href={`${basePath}?assessment=${assessment.id}`} className={`block rounded-xl border p-3 transition hover:border-violet-300 hover:bg-violet-50/40 ${assessment.id === selectedId ? "border-violet-200 bg-violet-50/70" : "border-slate-200"}`}><div className="flex items-start justify-between gap-2"><p className="font-semibold text-slate-900">{assessment.title}</p><Badge tone="purple">{assessment.term}</Badge></div><p className="mt-1 text-sm text-slate-500">{assessment.subject} · {assessment.class_name}</p><p className="mt-1 text-xs text-slate-400">{assessment.assessment_date} · out of {assessment.max_score}</p></Link>)}</div>}
        </Card>

        <Card className="p-0 sm:p-0">
          {!selectedAssessment ? <div className="p-5"><EmptyState title="Your gradebook will appear here" description="Create or select an assessment to enter student scores." /></div> : <>
            <div className="border-b border-slate-100 px-5 py-4 sm:px-6"><div className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between"><div><h2 className="font-bold text-slate-900">{selectedAssessment.title}</h2><p className="mt-1 text-sm text-slate-500">{selectedAssessment.subject} · {selectedAssessment.class_name} · {selectedAssessment.assessment_date}</p></div><Badge tone="blue">Max {selectedAssessment.max_score}</Badge></div><p className="mt-2 text-xs text-slate-400">{results.length} of {rosterCount} students graded · blank scores remain ungraded</p></div>
            {rosterCount > 150 && <p className="border-b border-amber-100 bg-amber-50 px-5 py-3 text-xs text-amber-800">This class has more than 150 students. The screen shows the first 150; use sections or smaller class groups for very large cohorts.</p>}
            {!students.length ? <div className="p-5"><EmptyState title="No students found" description="This assessment's class has no student profiles. Check the class name on student accounts." /></div> : <ActionForm action={saveAssessmentResultsAction} submitLabel="Save entered grades" successMessage="Grades saved" resetOnSuccess={false} className="space-y-0"><input type="hidden" name="assessment_id" value={selectedAssessment.id} /><div className="overflow-x-auto"><table className="min-w-full divide-y divide-slate-200 text-sm"><thead className="bg-slate-50"><tr><th className="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wide text-slate-500">Student</th><th className="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wide text-slate-500">Score / {selectedAssessment.max_score}</th><th className="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wide text-slate-500">Percentage</th><th className="min-w-60 px-5 py-3 text-left text-xs font-semibold uppercase tracking-wide text-slate-500">Feedback for family</th></tr></thead><tbody className="divide-y divide-slate-100">{students.map((student) => { const result = scoreMap.get(student.id); const pct = result ? Number(result.score) / Number(selectedAssessment.max_score) * 100 : null; return <tr key={student.id} className="hover:bg-slate-50/70"><td className="px-5 py-3"><p className="font-semibold text-slate-800">{student.full_name || "Unnamed student"}</p><p className="mt-0.5 text-xs text-slate-400">{student.email ?? student.class_name}</p></td><td className="w-44 px-5 py-3"><Input type="number" name={`score_${student.id}`} min="0" max={selectedAssessment.max_score} step="0.01" defaultValue={result?.score ?? ""} placeholder="Not graded" /></td><td className="px-5 py-3">{pct === null ? <span className="text-slate-400">—</span> : <span className={`font-bold ${pct >= 80 ? "text-emerald-700" : pct >= 50 ? "text-amber-700" : "text-rose-700"}`}>{pct.toFixed(1)}%</span>}</td><td className="px-5 py-3"><Input name={`feedback_${student.id}`} defaultValue={result?.feedback ?? ""} placeholder="Optional feedback" maxLength={1000} /></td></tr>; })}</tbody></table></div></ActionForm>}
          </>}
        </Card>
      </div>
      <p className="text-xs leading-5 text-slate-400">Only teachers and school administrators can enter or change marks. Students and linked parents see published results through their own secure portal. Confirm your school's marking and reporting rules before using grades for formal reporting.</p>
    </div>
  );
}
