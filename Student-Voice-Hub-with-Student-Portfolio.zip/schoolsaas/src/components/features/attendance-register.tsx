import { createClient } from "@/lib/supabase/server";
import { requireProfile } from "@/lib/auth";
import { ActionForm } from "@/components/ui/action-form";
import { saveAttendanceAction } from "@/app/actions/school-records";
import { Card, CardHeader, EmptyState, ErrorState, StatCard } from "@/components/ui/primitives";

function dubaiToday() {
  return new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Dubai", year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date());
}

export async function AttendanceRegister({ basePath, searchParams }: { basePath: "/school-admin/attendance" | "/teacher/attendance"; searchParams?: { date?: string | string[]; class_name?: string | string[] } }) {
  const profile = await requireProfile();
  const supabase = createClient();
  const date = dubaiToday();
  const [{ data: classRows }, { data: todaySummary }] = await Promise.all([
    supabase.from("school_class_summaries").select("class_name,student_count").eq("school_id", profile.school_id!).order("class_name"),
    supabase.from("attendance_daily_summaries").select("*").eq("attendance_date", date).maybeSingle(),
  ]);
  const classNames = Array.from(new Set((classRows ?? []).map((row) => row.class_name).filter((v): v is string => !!v))).sort((a, b) => a.localeCompare(b));
  const dateParam = Array.isArray(searchParams?.date) ? searchParams?.date[0] : searchParams?.date;
  const classParam = Array.isArray(searchParams?.class_name) ? searchParams?.class_name[0] : searchParams?.class_name;
  const selectedDate = dateParam && /^\d{4}-\d{2}-\d{2}$/.test(dateParam) ? dateParam : date;
  const selectedClass = classParam || "";
  return <AttendanceRegisterBody basePath={basePath} classes={classNames} today={date} selectedDate={selectedDate} selectedClass={selectedClass} recordedToday={todaySummary?.recorded_count ?? 0} presentToday={(todaySummary?.present_count ?? 0) + (todaySummary?.late_count ?? 0)} />;
}

async function AttendanceRegisterBody({
  basePath, classes, today, selectedDate, selectedClass, recordedToday, presentToday,
}: { basePath: string; classes: string[]; today: string; selectedDate: string; selectedClass: string; recordedToday: number; presentToday: number }) {
  const supabase = createClient();
  const profile = await requireProfile();
  let students: Array<{ id: string; full_name: string; class_name: string | null; email: string | null }> = [];
  let attendanceError: string | null = null;
  let rosterCount = 0;
  if (selectedClass) {
    const { data, count, error } = await supabase.from("profiles")
      .select("id,full_name,class_name,email", { count: "exact" })
      .eq("school_id", profile.school_id!).eq("role", "student").eq("class_name", selectedClass)
      .order("full_name").limit(150);
    if (error) attendanceError = error.message;
    students = data ?? [];
    rosterCount = count ?? students.length;
  }
  const ids = students.map((student) => student.id);
  const existing = ids.length ? await supabase.from("attendance_records").select("student_id,status")
    .eq("school_id", profile.school_id!).eq("attendance_date", selectedDate).in("student_id", ids) : { data: [], error: null };
  const current = new Map((existing.data ?? []).map((record) => [record.student_id, record.status]));
  const attendanceRows = existing.data ?? [];
  const marked = attendanceRows.length;
  const present = attendanceRows.filter((r) => r.status === "present").length;
  const absent = attendanceRows.filter((r) => r.status === "absent").length;
  const late = attendanceRows.filter((r) => r.status === "late").length;

  return (
    <div className="space-y-6">
      <section className="relative overflow-hidden rounded-3xl border border-slate-200 bg-white p-6 shadow-sm sm:p-8">
        <div aria-hidden="true" className="absolute -right-10 -top-14 h-56 w-56 rounded-full bg-cyan-100/70 blur-3xl" />
        <p className="text-xs font-bold uppercase tracking-[.18em] text-cyan-800">School operations</p>
        <h1 className="mt-2 text-2xl font-black tracking-tight text-slate-950 sm:text-3xl">Attendance register</h1>
        <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-600">Take attendance by class and date. Student records are stored individually, so a school of 2,000 students can be managed without loading one giant register.</p>
      </section>

      <section className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Records today" value={recordedToday} hint="Students with a saved attendance status" />
        <StatCard label="Present / late today" value={presentToday} hint="Across saved records for the school" />
        <StatCard label="Selected class" value={selectedClass || "Not selected"} hint="Choose a class to open its register" />
        <StatCard label="Marked for selected date" value={`${marked}/${students.length || 0}`} hint="Records saved for this class and date" />
      </section>

      <Card>
        <CardHeader title="Find a register" description="Choose a class and date. Only that class roster is loaded." />
        <form method="get" action={basePath} className="grid gap-3 md:grid-cols-[1fr_220px_auto] md:items-end">
          <div><label htmlFor="class_name" className="mb-1 block text-sm font-medium text-slate-700">Class / grade</label><select id="class_name" name="class_name" defaultValue={selectedClass} required className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm"><option value="">Choose class</option>{classes.map((name) => <option key={name} value={name}>{name}</option>)}</select></div>
          <div><label htmlFor="date" className="mb-1 block text-sm font-medium text-slate-700">Attendance date</label><input id="date" type="date" name="date" defaultValue={selectedDate} required className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm" /></div>
          <button type="submit" className="rounded-lg bg-brand px-4 py-2.5 text-sm font-semibold text-white hover:opacity-90">Open register</button>
        </form>
      </Card>

      {attendanceError && <ErrorState message={attendanceError} />}
      {!selectedClass ? <EmptyState title="Choose a class to begin" description="The register is class-filtered to keep attendance management fast and practical for large schools." /> : !students.length ? <EmptyState title="No students found in this class" description="Check the class names on student profiles, then try again." /> : (
        <Card className="p-0 sm:p-0">
          <div className="flex flex-col gap-2 border-b border-slate-100 px-5 py-4 sm:flex-row sm:items-center sm:justify-between sm:px-6">
            <div><h2 className="font-bold text-slate-900">{selectedClass} register</h2><p className="text-sm text-slate-500">{selectedDate} · {rosterCount} students in class</p></div>
            <div className="flex gap-2 text-xs"><span className="rounded-full bg-emerald-50 px-3 py-1 font-semibold text-emerald-700">Present {present}</span><span className="rounded-full bg-rose-50 px-3 py-1 font-semibold text-rose-700">Absent {absent}</span><span className="rounded-full bg-amber-50 px-3 py-1 font-semibold text-amber-700">Late {late}</span></div>
          </div>
          {rosterCount > 150 && <p className="border-b border-amber-100 bg-amber-50 px-5 py-3 text-xs text-amber-800">This class has more than 150 students. The current register shows the first 150. Split unusually large classes into smaller sections for attendance-taking.</p>}
          <ActionForm action={saveAttendanceAction} submitLabel={`Save attendance for ${students.length} students`} successMessage="Attendance saved successfully" resetOnSuccess={false} className="space-y-0">
            <input type="hidden" name="attendance_date" value={selectedDate} />
            <input type="hidden" name="class_name" value={selectedClass} />
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-slate-200 text-sm">
                <thead className="bg-slate-50"><tr><th className="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wide text-slate-500">Student</th><th className="px-5 py-3 text-left text-xs font-semibold uppercase tracking-wide text-slate-500">Class</th><th className="min-w-44 px-5 py-3 text-left text-xs font-semibold uppercase tracking-wide text-slate-500">Status</th></tr></thead>
                <tbody className="divide-y divide-slate-100 bg-white">{students.map((student) => <tr key={student.id} className="hover:bg-slate-50/70"><td className="px-5 py-3"><p className="font-semibold text-slate-800">{student.full_name || "Unnamed student"}</p><p className="mt-0.5 text-xs text-slate-400">{student.email ?? "Student account"}</p></td><td className="px-5 py-3 text-slate-500">{student.class_name}</td><td className="px-5 py-3"><select name={`status_${student.id}`} defaultValue={current.get(student.id) ?? ""} required className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm"><option value="" disabled>Select status</option><option value="present">Present</option><option value="absent">Absent</option><option value="late">Late</option><option value="excused">Excused</option></select></td></tr>)}</tbody>
              </table>
            </div>
          </ActionForm>
        </Card>
      )}
      <p className="text-xs leading-5 text-slate-400">Records are unique per student and date. Saving again updates the same daily record instead of creating duplicates. An attendance percentage is calculated only from records that staff have actually marked.</p>
    </div>
  );
}
