import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { requireProfile } from "@/lib/auth";
import { Badge, Card, CardHeader, EmptyState, StatCard } from "@/components/ui/primitives";

function dateLabel(value: string) {
  return new Intl.DateTimeFormat("en-AE", { day: "numeric", month: "short", year: "numeric", timeZone: "Asia/Dubai" }).format(new Date(`${value}T12:00:00+04:00`));
}
function percent(numerator: number, denominator: number) {
  return denominator ? (numerator / denominator) * 100 : null;
}
function statusTone(status: string): "green" | "red" | "yellow" | "blue" | "slate" {
  if (status === "present" || status === "completed") return "green";
  if (status === "absent" || status === "urgent") return "red";
  if (status === "late" || status === "excused") return "yellow";
  return "blue";
}

async function getFamilyData() {
  const profile = await requireProfile();
  const supabase = createClient();
  const { data: links, error: linkError } = await supabase.from("parent_student_links")
    .select("id,student_id,relationship").eq("parent_id", profile.id).eq("is_verified", true);
  const studentIds = (links ?? []).map((row) => row.student_id);
  if (!studentIds.length) return { profile, supabase, students: [] as any[], attendance: [] as any[], results: [] as any[], assessments: [] as any[], announcements: [] as any[], linkError: linkError?.message ?? null };
  const since = new Date(); since.setDate(since.getDate() - 30);
  const sinceDate = new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Dubai", year: "numeric", month: "2-digit", day: "2-digit" }).format(since);
  const [studentQuery, attendanceQuery, resultsQuery, announcementQuery] = await Promise.all([
    supabase.from("profiles").select("id,full_name,class_name").in("id", studentIds),
    supabase.from("attendance_records").select("id,student_id,attendance_date,status,note").in("student_id", studentIds).gte("attendance_date", sinceDate).order("attendance_date", { ascending: false }).limit(500),
    supabase.from("academic_results").select("id,student_id,assessment_id,score,feedback,graded_at").in("student_id", studentIds).order("graded_at", { ascending: false }).limit(100),
    supabase.from("announcements").select("id,title,body,published_at,is_pinned").order("published_at", { ascending: false }).limit(5),
  ]);
  const assessmentIds = Array.from(new Set((resultsQuery.data ?? []).map((row) => row.assessment_id)));
  const { data: assessments } = assessmentIds.length ? await supabase.from("academic_assessments").select("id,subject,title,term,assessment_date,max_score").in("id", assessmentIds) : { data: [] };
  return {
    profile, supabase, students: studentQuery.data ?? [], attendance: attendanceQuery.data ?? [],
    results: resultsQuery.data ?? [], assessments: assessments ?? [], announcements: announcementQuery.data ?? [],
    linkError: linkError?.message ?? studentQuery.error?.message ?? attendanceQuery.error?.message ?? resultsQuery.error?.message ?? null,
  };
}

export async function ParentOverview() {
  const data = await getFamilyData();
  const assessmentMap = new Map(data.assessments.map((row: any) => [row.id, row]));
  const totalRecorded = data.attendance.filter((row: any) => row.status !== "excused").length;
  const totalAttended = data.attendance.filter((row: any) => row.status === "present" || row.status === "late").length;
  const attendancePct = percent(totalAttended, totalRecorded);


  return <div className="space-y-6">
    <section className="relative isolate overflow-hidden rounded-3xl border border-slate-200 bg-white p-6 shadow-sm sm:p-8">
      <div aria-hidden="true" className="absolute -right-10 -top-14 -z-10 h-56 w-56 rounded-full bg-cyan-100/70 blur-3xl" />
      <p className="text-xs font-bold uppercase tracking-[.18em] text-cyan-800">Family portal · UAE school workspace</p>
      <h1 className="mt-2 text-2xl font-black tracking-tight text-slate-950 sm:text-3xl">Welcome, {data.profile.full_name || "Parent / Guardian"}</h1>
      <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-600">One secure place to follow your linked child’s attendance, academic progress and school announcements—alongside the school’s student voice platform.</p>
      <div className="mt-5 flex flex-wrap gap-3"><Link href="/parent/attendance" className="rounded-xl bg-brand px-4 py-2.5 text-sm font-semibold text-white shadow-sm hover:opacity-90">View attendance</Link><Link href="/parent/academics" className="rounded-xl border border-slate-200 px-4 py-2.5 text-sm font-semibold text-slate-700 hover:bg-slate-50">Academic progress</Link></div>
    </section>
    {data.linkError && <div className="rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-800">Some information could not be loaded: {data.linkError}. Confirm that the latest Supabase migrations have been applied.</div>}
    {!data.students.length ? <Card><EmptyState title="No student linked to this account yet" description="Ask the school administrator to create or connect your parent account to the correct student. For student privacy, parents cannot search the school directory themselves." /></Card> : <>
      <section className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard label="Linked students" value={data.students.length} hint="Student accounts linked by the school" />
        <StatCard label="30-day attendance" value={attendancePct === null ? "—" : `${attendancePct.toFixed(1)}%`} hint={`${totalAttended} attended or late records among non-excused records`} />
        <StatCard label="Recent grade records" value={data.results.length} hint="Most recent academic results available to this family" />
        <StatCard label="School updates" value={data.announcements.length} hint="Latest announcements visible to parents" />
      </section>
      <section><div className="mb-3"><h2 className="text-lg font-bold text-slate-950">Your children</h2><p className="mt-1 text-sm text-slate-500">Each card uses attendance and marks actually recorded by school staff.</p></div><div className="grid gap-4 lg:grid-cols-2">{data.students.map((student: any) => {
        const rows = data.attendance.filter((row: any) => row.student_id === student.id);
        const recorded = rows.filter((row: any) => row.status !== "excused").length;
        const attended = rows.filter((row: any) => row.status === "present" || row.status === "late").length;
        const childAttendance = percent(attended, recorded);
        const childResults = data.results.filter((row: any) => row.student_id === student.id && assessmentMap.has(row.assessment_id));
        const childAverage = childResults.length ? childResults.reduce((sum: number, row: any) => sum + Number(row.score) / Number((assessmentMap.get(row.assessment_id) as any).max_score) * 100, 0) / childResults.length : null;
        const absences = rows.filter((row: any) => row.status === "absent").length;
        return <Card key={student.id} className="overflow-hidden p-0"><div className="flex items-start justify-between gap-3 border-b border-slate-100 bg-slate-50/70 px-5 py-4"><div><h3 className="font-bold text-slate-900">{student.full_name || "Student"}</h3><p className="mt-1 text-sm text-slate-500">{student.class_name || "Class not assigned"}</p></div><Badge tone="blue">Linked student</Badge></div><div className="grid grid-cols-2 gap-3 p-5"><div className="rounded-xl border border-slate-200 p-3"><p className="text-xs font-medium text-slate-500">Attendance · 30 days</p><p className="mt-1 text-2xl font-black text-slate-950">{childAttendance === null ? "—" : `${childAttendance.toFixed(1)}%`}</p><p className="mt-1 text-xs text-slate-400">{recorded} non-excused records</p></div><div className="rounded-xl border border-slate-200 p-3"><p className="text-xs font-medium text-slate-500">Recent grade average</p><p className="mt-1 text-2xl font-black text-slate-950">{childAverage === null ? "—" : `${childAverage.toFixed(1)}%`}</p><p className="mt-1 text-xs text-slate-400">{childResults.length} graded assessments</p></div></div><div className="px-5 pb-5"><p className="mb-3 text-sm text-slate-600">{absences ? `${absences} recorded absence${absences === 1 ? "" : "s"} in the last 30 days.` : "No absences recorded in the last 30 days."}</p><div className="flex flex-wrap gap-2"><Link href="/parent/attendance" className="rounded-lg border border-slate-200 px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50">Attendance history</Link><Link href="/parent/academics" className="rounded-lg border border-slate-200 px-3 py-2 text-xs font-semibold text-slate-700 hover:bg-slate-50">View marks</Link></div></div></Card>;
      })}</div></section>
      <Card><CardHeader title="Latest academic results" description="Recent assessment marks published by your school." action={<Link href="/parent/academics" className="text-sm font-semibold text-brand hover:underline">View all available</Link>} />{!data.results.length ? <EmptyState title="No grades published yet" description="Results will appear once your child's teachers enter marks for an assessment." /> : <div className="space-y-3">{data.results.slice(0, 5).map((row: any) => { const a: any = assessmentMap.get(row.assessment_id); const pct = a?.max_score ? Number(row.score) / Number(a.max_score) * 100 : null; const student = data.students.find((s: any) => s.id === row.student_id); return <div key={row.id} className="flex flex-col gap-2 rounded-xl border border-slate-100 p-3 sm:flex-row sm:items-center sm:justify-between"><div><p className="font-semibold text-slate-800">{a?.title ?? "Assessment"}</p><p className="text-sm text-slate-500">{student?.full_name} · {a?.subject ?? "Subject"} · {a?.term ?? ""}</p></div><div className="sm:text-right"><p className="font-bold text-slate-900">{row.score} / {a?.max_score ?? "—"}</p><p className="text-xs text-slate-500">{pct === null ? "Percentage unavailable" : `${pct.toFixed(1)}%`}</p>{pct !== null && <div className="mt-2 h-2 overflow-hidden rounded-full bg-slate-100" role="img" aria-label={`Score ${pct.toFixed(1)} percent`}><div className={`h-full rounded-full ${pct >= 80 ? "bg-emerald-500" : pct >= 50 ? "bg-amber-500" : "bg-rose-500"}`} style={{ width: `${Math.min(100, Math.max(0, pct))}%` }} /></div>}</div></div>; })}</div>}</Card>
    </>}
    <Card><CardHeader title="School announcements" description="Important updates shared with families." action={<Link href="/parent/announcements" className="text-sm font-semibold text-brand hover:underline">All announcements</Link>} />{!data.announcements.length ? <EmptyState title="No announcements yet" description="Parent-visible school announcements will appear here." /> : <div className="divide-y divide-slate-100">{data.announcements.slice(0, 4).map((item: any) => <article key={item.id} className="py-3 first:pt-0 last:pb-0"><div className="flex flex-wrap items-center gap-2"><h3 className="font-semibold text-slate-800">{item.title}</h3>{item.is_pinned && <Badge tone="yellow">Pinned</Badge>}</div><p className="mt-1 line-clamp-2 text-sm text-slate-600">{item.body}</p><p className="mt-1 text-xs text-slate-400">{dateLabel(item.published_at.slice(0, 10))}</p></article>)}</div>}</Card>
  </div>;
}

export async function ParentAttendance() {
  const data = await getFamilyData();
  return <div className="space-y-6"><div><p className="text-xs font-bold uppercase tracking-[.16em] text-cyan-800">Family records</p><h1 className="mt-2 text-2xl font-black tracking-tight text-slate-950">Attendance history</h1><p className="mt-1 text-sm text-slate-500">Attendance records entered by school staff during the last 30 days.</p></div>{!data.students.length ? <Card><EmptyState title="No linked student" description="Ask the school administrator to link this parent account to a student." /></Card> : data.students.map((student: any) => { const records = data.attendance.filter((row: any) => row.student_id === student.id); const eligible = records.filter((r: any) => r.status !== "excused").length; const attended = records.filter((r: any) => r.status === "present" || r.status === "late").length; return <Card key={student.id}><CardHeader title={student.full_name} description={`${student.class_name || "Class not assigned"} · ${records.length} attendance records`} action={<Badge tone="blue">{percent(attended, eligible) === null ? "No data" : `${percent(attended, eligible)!.toFixed(1)}% attendance`}</Badge>} />{!records.length ? <EmptyState title="No records for the last 30 days" description="This does not necessarily mean the student was absent; the register may not yet have been marked." /> : <div className="overflow-x-auto"><table className="min-w-full divide-y divide-slate-200 text-sm"><thead className="bg-slate-50"><tr><th className="px-3 py-2 text-left text-xs font-semibold uppercase text-slate-500">Date</th><th className="px-3 py-2 text-left text-xs font-semibold uppercase text-slate-500">Status</th><th className="px-3 py-2 text-left text-xs font-semibold uppercase text-slate-500">Note</th></tr></thead><tbody className="divide-y divide-slate-100">{records.map((r: any) => <tr key={r.id}><td className="px-3 py-3 text-slate-700">{dateLabel(r.attendance_date)}</td><td className="px-3 py-3"><Badge tone={statusTone(r.status)}>{r.status}</Badge></td><td className="px-3 py-3 text-slate-500">{r.note || "—"}</td></tr>)}</tbody></table></div>}</Card>; })}</div>;
}

export async function ParentAcademics() {
  const data = await getFamilyData();
  const assessmentMap = new Map(data.assessments.map((row: any) => [row.id, row]));
  return <div className="space-y-6"><div><p className="text-xs font-bold uppercase tracking-[.16em] text-violet-800">Family records</p><h1 className="mt-2 text-2xl font-black tracking-tight text-slate-950">Academic progress</h1><p className="mt-1 text-sm text-slate-500">Assessment scores and percentages published by the school.</p></div>{!data.students.length ? <Card><EmptyState title="No linked student" description="Ask the school administrator to link this parent account to a student." /></Card> : data.students.map((student: any) => { const rows = data.results.filter((row: any) => row.student_id === student.id && assessmentMap.has(row.assessment_id)); return <Card key={student.id}><CardHeader title={student.full_name} description={student.class_name || "Class not assigned"} />{!rows.length ? <EmptyState title="No grades published yet" description="The student's academic records will appear once a teacher saves assessment results." /> : <div className="overflow-x-auto"><table className="min-w-full divide-y divide-slate-200 text-sm"><thead className="bg-slate-50"><tr><th className="px-3 py-2 text-left text-xs font-semibold uppercase text-slate-500">Assessment</th><th className="px-3 py-2 text-left text-xs font-semibold uppercase text-slate-500">Subject / term</th><th className="px-3 py-2 text-left text-xs font-semibold uppercase text-slate-500">Score</th><th className="px-3 py-2 text-left text-xs font-semibold uppercase text-slate-500">Percentage</th><th className="px-3 py-2 text-left text-xs font-semibold uppercase text-slate-500">Feedback</th></tr></thead><tbody className="divide-y divide-slate-100">{rows.map((row: any) => { const a: any = assessmentMap.get(row.assessment_id); const pct = Number(row.score) / Number(a.max_score) * 100; return <tr key={row.id}><td className="px-3 py-3 font-semibold text-slate-800">{a.title}</td><td className="px-3 py-3 text-slate-500">{a.subject}<br /><span className="text-xs text-slate-400">{a.term} · {a.assessment_date}</span></td><td className="px-3 py-3 font-semibold">{row.score} / {a.max_score}</td><td className="min-w-36 px-3 py-3"><span className={`font-bold ${pct >= 80 ? "text-emerald-700" : pct >= 50 ? "text-amber-700" : "text-rose-700"}`}>{pct.toFixed(1)}%</span><div className="mt-2 h-2 overflow-hidden rounded-full bg-slate-100" role="img" aria-label={`Score ${pct.toFixed(1)} percent`}><div className={`h-full rounded-full ${pct >= 80 ? "bg-emerald-500" : pct >= 50 ? "bg-amber-500" : "bg-rose-500"}`} style={{ width: `${Math.min(100, Math.max(0, pct))}%` }} /></div></td><td className="px-3 py-3 text-slate-500">{row.feedback || "—"}</td></tr>; })}</tbody></table></div>}</Card>; })}</div>;
}

export async function ParentAnnouncements() {
  await requireProfile();
  const supabase = createClient();
  const { data, error } = await supabase.from("announcements").select("id,title,body,audience,is_pinned,published_at").order("is_pinned", { ascending: false }).order("published_at", { ascending: false }).limit(100);
  return <div className="space-y-6"><div><p className="text-xs font-bold uppercase tracking-[.16em] text-cyan-800">Family communications</p><h1 className="mt-2 text-2xl font-black tracking-tight text-slate-950">School announcements</h1><p className="mt-1 text-sm text-slate-500">Updates published for all families or specifically for parents.</p></div>{error && <p className="rounded-xl bg-rose-50 p-3 text-sm text-rose-700">Announcements could not be loaded: {error.message}</p>}{!data?.length ? <Card><EmptyState title="No announcements yet" description="Your school's parent-visible announcements will appear here." /></Card> : <div className="space-y-3">{data.map((item) => <Card key={item.id}><div className="flex flex-wrap items-center gap-2"><h2 className="font-bold text-slate-900">{item.title}</h2>{item.is_pinned && <Badge tone="yellow">Pinned</Badge>}<Badge tone="blue">{item.audience === "parents" ? "Parents" : "School community"}</Badge></div><p className="mt-2 whitespace-pre-wrap text-sm leading-6 text-slate-600">{item.body}</p><p className="mt-3 text-xs text-slate-400">{dateLabel(item.published_at.slice(0, 10))}</p></Card>)}</div>}</div>;
}
