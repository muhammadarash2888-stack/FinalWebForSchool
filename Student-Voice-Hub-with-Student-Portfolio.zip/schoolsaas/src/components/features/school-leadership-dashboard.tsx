import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { requireProfile } from "@/lib/auth";
import { Badge, Card, CardHeader, EmptyState, StatCard } from "@/components/ui/primitives";

function dubaiToday() {
  return new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Dubai", year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date());
}
function last7Days(today: string) {
  const [year, month, day] = today.split("-").map(Number);
  const anchor = new Date(Date.UTC(year, month - 1, day, 12));
  return Array.from({ length: 7 }, (_, index) => {
    const date = new Date(anchor); date.setUTCDate(anchor.getUTCDate() - (6 - index));
    return date.toISOString().slice(0, 10);
  });
}
function shortDate(date: string) {
  return new Intl.DateTimeFormat("en-AE", { weekday: "short", day: "numeric", timeZone: "UTC" }).format(new Date(`${date}T12:00:00Z`));
}

const quickActions = [
  { href: "/school-admin/attendance", title: "Take attendance", detail: "Open a class register for any date.", icon: "✓", tint: "bg-cyan-50 text-cyan-800" },
  { href: "/school-admin/academics", title: "Manage grades", detail: "Create an assessment and record marks.", icon: "↗", tint: "bg-violet-50 text-violet-800" },
  { href: "/school-admin/people", title: "People & parents", detail: "Manage accounts and securely link families.", icon: "♙", tint: "bg-amber-50 text-amber-800" },
  { href: "/school-admin/announcements", title: "Family updates", detail: "Publish a school-wide or parent update.", icon: "✦", tint: "bg-rose-50 text-rose-800" },
];

export async function SchoolLeadershipDashboard() {
  const profile = await requireProfile();
  const supabase = createClient();
  const today = dubaiToday();
  const trendDates = last7Days(today);
  const [studentsCount, teachersCount, parentsCount, attendanceTrendQuery, subjectQuery, attendanceTodayQuery, absentQuery, ideasQuery, issuesQuery, announcementQuery, resultCountQuery] = await Promise.all([
    supabase.from("profiles").select("id", { count: "exact", head: true }).eq("school_id", profile.school_id!).eq("role", "student"),
    supabase.from("profiles").select("id", { count: "exact", head: true }).eq("school_id", profile.school_id!).eq("role", "teacher"),
    supabase.from("profiles").select("id", { count: "exact", head: true }).eq("school_id", profile.school_id!).eq("role", "parent"),
    supabase.from("attendance_daily_summaries").select("*").in("attendance_date", trendDates).order("attendance_date", { ascending: true }),
    supabase.from("academic_subject_summaries").select("subject,term,graded_count,average_percentage").order("graded_count", { ascending: false }).limit(8),
    supabase.from("attendance_daily_summaries").select("*").eq("attendance_date", today).maybeSingle(),
    supabase.from("attendance_records").select("student_id,status,attendance_date").eq("attendance_date", today).in("status", ["absent", "late"]).order("status").limit(8),
    supabase.from("ideas").select("id", { count: "exact", head: true }).in("status", ["submitted", "under_review"]),
    supabase.from("issues").select("id", { count: "exact", head: true }).in("status", ["open", "acknowledged", "in_progress"]),
    supabase.from("announcements").select("id,title,body,published_at").order("published_at", { ascending: false }).limit(4),
    supabase.from("academic_results").select("id", { count: "exact", head: true }).eq("school_id", profile.school_id!),
  ]);
  const students = studentsCount.count ?? 0;
  const trendMap = new Map((attendanceTrendQuery.data ?? []).map((row) => [row.attendance_date, row]));
  const trend = trendDates.map((date) => ({ date, row: trendMap.get(date) }));
  const summary = attendanceTodayQuery.data;
  const recorded = summary?.recorded_count ?? 0;
  const eligible = Math.max(0, recorded - (summary?.excused_count ?? 0));
  const attendanceRate = eligible ? (((summary?.present_count ?? 0) + (summary?.late_count ?? 0)) / eligible) * 100 : null;
  const captureRate = students ? (recorded / students) * 100 : null;
  const subjectRows = subjectQuery.data ?? [];
  const validSubjectRows = subjectRows.filter((row) => row.average_percentage !== null);
  const weightedCount = validSubjectRows.reduce((sum, row) => sum + row.graded_count, 0);
  const schoolAverage = weightedCount ? validSubjectRows.reduce((sum, row) => sum + Number(row.average_percentage) * row.graded_count, 0) / weightedCount : null;
  const maxRecorded = Math.max(1, ...trend.map(({ row }) => row?.recorded_count ?? 0));
  const troubleIds = Array.from(new Set((absentQuery.data ?? []).map((row) => row.student_id)));
  const { data: troubleProfiles } = troubleIds.length ? await supabase.from("profiles").select("id,full_name,class_name").in("id", troubleIds) : { data: [] };
  const profileMap = new Map((troubleProfiles ?? []).map((row) => [row.id, row]));
  const [votesCount, pollsCount] = await Promise.all([
    supabase.from("votes").select("id", { count: "exact", head: true }),
    supabase.from("polls").select("id", { count: "exact", head: true }).eq("is_active", true),
  ]);

  return <div className="space-y-6">
    <section className="relative isolate overflow-hidden rounded-3xl border border-slate-200 bg-white p-6 shadow-sm sm:p-8">
      <div aria-hidden="true" className="absolute -right-12 -top-16 -z-10 h-64 w-64 rounded-full bg-cyan-100/75 blur-3xl" /><div aria-hidden="true" className="absolute bottom-[-5rem] right-48 -z-10 h-40 w-40 rounded-full bg-violet-100/70 blur-3xl" />
      <div className="flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between"><div><p className="inline-flex items-center gap-2 rounded-full border border-cyan-100 bg-cyan-50 px-3 py-1.5 text-[11px] font-bold uppercase tracking-[.16em] text-cyan-900"><span className="h-1.5 w-1.5 rounded-full bg-cyan-600" /> School operations overview</p><h1 className="mt-3 text-2xl font-black tracking-tight text-slate-950 sm:text-3xl">Good to see you, {profile.full_name?.split(" ")[0] || "school leader"}</h1><p className="mt-2 max-w-2xl text-sm leading-6 text-slate-600">A leadership view across attendance, academic progress, family engagement and student voice. Metrics reflect records entered in this workspace.</p></div><div className="rounded-2xl border border-slate-200 bg-white/90 px-4 py-3 shadow-sm"><p className="text-xs font-medium text-slate-500">Today · UAE time</p><p className="mt-1 font-bold text-slate-900">{new Intl.DateTimeFormat("en-AE", { weekday: "long", day: "numeric", month: "long", timeZone: "Asia/Dubai" }).format(new Date())}</p></div></div>
    </section>

    <section className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
      <StatCard label="Students" value={students} hint="Student profiles in this school" />
      <StatCard label="Attendance today" value={attendanceRate === null ? "—" : `${attendanceRate.toFixed(1)}%`} hint={`${recorded} of ${students} student records marked`} />
      <StatCard label="Academic average" value={schoolAverage === null ? "—" : `${schoolAverage.toFixed(1)}%`} hint={`${resultCountQuery.count ?? 0} marks saved across subjects`} />
      <StatCard label="Parent accounts" value={parentsCount.count ?? 0} hint="Guardian accounts linked by the school" />
    </section>
    <section className="grid gap-4 xl:grid-cols-[1.35fr_1fr]">
      <Card className="min-w-0"><CardHeader title="Attendance trend" description="Daily register completion and attendance over the last seven days." action={<Link href="/school-admin/attendance" className="text-sm font-semibold text-brand hover:underline">Open registers →</Link>} />
        {!trend.some(({ row }) => !!row?.recorded_count) ? <EmptyState title="No attendance trend yet" description="Once teachers start saving registers, the chart will show real daily records." /> : <div className="pt-2"><div className="flex h-48 items-end gap-2 border-b border-slate-100 pb-2 sm:gap-3">{trend.map(({ date, row }) => { const total = row?.recorded_count ?? 0; const percentHere = total ? (((row?.present_count ?? 0) + (row?.late_count ?? 0)) / Math.max(1, total - (row?.excused_count ?? 0))) * 100 : 0; return <div key={date} className="flex h-full min-w-0 flex-1 flex-col items-center justify-end gap-2"><div className="flex h-full w-full max-w-12 items-end overflow-hidden rounded-t-lg bg-slate-100"><div title={`${total} records · ${percentHere.toFixed(1)}% present/late`} className="w-full rounded-t-lg bg-gradient-to-t from-cyan-700 to-cyan-400 transition-all" style={{ height: `${total ? Math.max(8, (total / maxRecorded) * 100) : 0}%` }} /></div><span className="text-[10px] font-medium text-slate-500 sm:text-xs">{shortDate(date)}</span></div>; })}</div><div className="mt-4 grid grid-cols-2 gap-3"><div className="rounded-xl bg-slate-50 p-3"><p className="text-xs text-slate-500">Today's register completion</p><p className="mt-1 text-xl font-black text-slate-900">{captureRate === null ? "—" : `${Math.min(100, captureRate).toFixed(1)}%`}</p></div><div className="rounded-xl bg-slate-50 p-3"><p className="text-xs text-slate-500">Students absent today</p><p className="mt-1 text-xl font-black text-slate-900">{summary?.absent_count ?? 0}</p></div></div></div>}
      </Card>
      <Card className="min-w-0"><CardHeader title="Academic performance" description="Average percentage by subject across recorded assessment marks." action={<Link href="/school-admin/academics" className="text-sm font-semibold text-brand hover:underline">Gradebook →</Link>} />
        {!validSubjectRows.length ? <EmptyState title="No grades to chart yet" description="Create an assessment and enter marks to populate this chart." /> : <div className="space-y-4 pt-1">{validSubjectRows.map((row) => { const value = Math.max(0, Math.min(100, Number(row.average_percentage))); return <div key={`${row.subject}-${row.term}`}><div className="mb-1.5 flex items-center justify-between gap-3"><div className="min-w-0"><p className="truncate text-sm font-semibold text-slate-800">{row.subject}</p><p className="text-xs text-slate-400">{row.term} · {row.graded_count} marks</p></div><span className="text-sm font-bold tabular-nums text-slate-900">{value.toFixed(1)}%</span></div><div className="h-2.5 overflow-hidden rounded-full bg-slate-100"><div className={`h-full rounded-full ${value >= 80 ? "bg-emerald-500" : value >= 60 ? "bg-cyan-600" : "bg-amber-500"}`} style={{ width: `${value}%` }} /></div></div>; })}</div>}
      </Card>
    </section>
    <section className="grid gap-4 xl:grid-cols-[1fr_1fr]">
      <Card><CardHeader title="Needs attention today" description="Recent attendance records marked absent or late." action={<Link href="/school-admin/attendance" className="text-sm font-semibold text-brand hover:underline">Review register →</Link>} />{!absentQuery.data?.length ? <EmptyState title="No absence or late records surfaced" description="This means none are currently listed in today's recent records. Check register completion before concluding there were no absences." /> : <div className="space-y-2">{absentQuery.data.map((row, index) => { const person: any = profileMap.get(row.student_id); return <div key={`${row.student_id}-${index}`} className="flex items-center justify-between gap-3 rounded-xl border border-slate-100 p-3"><div className="min-w-0"><p className="truncate font-semibold text-slate-800">{person?.full_name ?? "Student record"}</p><p className="text-xs text-slate-500">{person?.class_name ?? "Class not assigned"}</p></div><Badge tone={row.status === "absent" ? "red" : "yellow"}>{row.status}</Badge></div>; })}</div>}</Card>
      <Card><CardHeader title="Student voice & school pulse" description="Keep culture and student participation visible alongside academic outcomes." />
        <div className="grid grid-cols-2 gap-3"><div className="rounded-xl bg-violet-50 p-4"><p className="text-xs font-semibold text-violet-700">Active polls</p><p className="mt-1 text-2xl font-black text-violet-950">{pollsCount.count ?? 0}</p></div><div className="rounded-xl bg-cyan-50 p-4"><p className="text-xs font-semibold text-cyan-700">Votes recorded</p><p className="mt-1 text-2xl font-black text-cyan-950">{votesCount.count ?? 0}</p></div><div className="rounded-xl bg-amber-50 p-4"><p className="text-xs font-semibold text-amber-700">Ideas awaiting review</p><p className="mt-1 text-2xl font-black text-amber-950">{ideasQuery.count ?? 0}</p></div><div className="rounded-xl bg-rose-50 p-4"><p className="text-xs font-semibold text-rose-700">Open school issues</p><p className="mt-1 text-2xl font-black text-rose-950">{issuesQuery.count ?? 0}</p></div></div>
      </Card>
    </section>
    <section><div className="mb-3"><h2 className="text-lg font-bold text-slate-950">Quick actions</h2><p className="mt-1 text-sm text-slate-500">The most-used workflows for school leadership.</p></div><div className="grid gap-3 sm:grid-cols-2">{quickActions.map((action) => <Link key={action.href} href={action.href} className="group flex min-h-28 items-start gap-4 rounded-2xl border border-slate-200/80 bg-white p-5 shadow-sm transition hover:-translate-y-0.5 hover:border-cyan-200 hover:shadow-md"><span className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl text-xl ${action.tint}`}>{action.icon}</span><span className="min-w-0 flex-1"><span className="flex items-center justify-between gap-2 font-semibold text-slate-900">{action.title}<span aria-hidden="true" className="text-slate-300 transition group-hover:translate-x-0.5 group-hover:text-cyan-700">→</span></span><span className="mt-1 block text-sm leading-5 text-slate-500">{action.detail}</span></span></Link>)}</div></section>
    <Card><CardHeader title="Latest announcements" description="Recent communications in your school workspace." action={<Link href="/school-admin/announcements" className="text-sm font-semibold text-brand hover:underline">Manage announcements →</Link>} />{!announcementQuery.data?.length ? <EmptyState title="No announcements yet" description="Publish a school update to keep families and staff informed." /> : <div className="divide-y divide-slate-100">{announcementQuery.data.map((announcement) => <article key={announcement.id} className="py-3 first:pt-0 last:pb-0"><h3 className="font-semibold text-slate-800">{announcement.title}</h3><p className="mt-1 line-clamp-2 text-sm text-slate-500">{announcement.body}</p><p className="mt-1 text-xs text-slate-400">{new Intl.DateTimeFormat("en-AE", { day: "numeric", month: "short", timeZone: "Asia/Dubai" }).format(new Date(announcement.published_at))}</p></article>)}</div>}</Card>
  </div>;
}
