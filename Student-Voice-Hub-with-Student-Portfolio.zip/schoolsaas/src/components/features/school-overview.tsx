import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { StatCard, Card, CardHeader, EmptyState, Badge } from "@/components/ui/primitives";
import { fmtDate } from "@/components/ui/helpers";

async function count(table: string, filter?: (q: any) => any) {
  const supabase = createClient();
  let q: any = supabase.from(table).select("*", { count: "exact", head: true });
  if (filter) q = filter(q);
  const { count } = await q;
  return count ?? 0;
}

const teacherActions = [
  { href: "/teacher/attendance", title: "Attendance register", detail: "Mark daily attendance by class and date.", icon: "✓", tint: "bg-cyan-50 text-cyan-800" },
  { href: "/teacher/academics", title: "Gradebook", detail: "Create assessments and enter student marks.", icon: "↗", tint: "bg-violet-50 text-violet-800" },
  { href: "/teacher/announcements", title: "Announcements", detail: "Share verified updates with your school community.", icon: "↗", tint: "bg-cyan-50 text-cyan-800" },
  { href: "/teacher/ideas", title: "Student ideas", detail: "Review suggestions and spot recurring themes.", icon: "✦", tint: "bg-violet-50 text-violet-800" },
  { href: "/teacher/polls", title: "Polls", detail: "See school polls and student participation.", icon: "◉", tint: "bg-amber-50 text-amber-800" },
  { href: "/teacher/issues", title: "Reported issues", detail: "Follow up on reports that need attention.", icon: "⚑", tint: "bg-rose-50 text-rose-800" },
];

const adminActions = [
  { href: "/school-admin/people", title: "People", detail: "Manage the student and teacher community.", icon: "♙", tint: "bg-cyan-50 text-cyan-800" },
  { href: "/school-admin/polls", title: "Polls", detail: "Manage polls and understand participation.", icon: "◉", tint: "bg-violet-50 text-violet-800" },
  { href: "/school-admin/issues", title: "Reported issues", detail: "Review reports and track their status.", icon: "⚑", tint: "bg-rose-50 text-rose-800" },
  { href: "/school-admin/settings", title: "School settings", detail: "Review your school's workspace settings.", icon: "⚙", tint: "bg-amber-50 text-amber-800" },
];

export async function SchoolOverview({ title, showPeople }: { title: string; showPeople?: boolean }) {
  const supabase = createClient();
  const [students, teachers, polls, votes, openIssues, pendingIdeas] = await Promise.all([
    showPeople ? count("profiles", (q) => q.eq("role", "student")) : Promise.resolve(0),
    showPeople ? count("profiles", (q) => q.eq("role", "teacher")) : Promise.resolve(0),
    count("polls"),
    count("votes"),
    count("issues", (q) => q.in("status", ["open", "acknowledged", "in_progress"])),
    count("ideas", (q) => q.in("status", ["submitted", "under_review"])),
  ]);
  const { data: recent } = await supabase.from("announcements").select("id,title,created_at").order("created_at", { ascending: false }).limit(5);
  const actions = showPeople ? adminActions : teacherActions;

  return (
    <div className="space-y-7">
      <section className="relative isolate overflow-hidden rounded-3xl border border-slate-200/80 bg-white p-6 shadow-sm sm:p-8">
        <div aria-hidden="true" className="absolute -right-10 -top-16 -z-10 h-60 w-60 rounded-full bg-cyan-100/70 blur-3xl" />
        <div aria-hidden="true" className="absolute bottom-[-5rem] right-32 -z-10 h-40 w-40 rounded-full bg-amber-100/70 blur-3xl" />
        <div className="flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between">
          <div className="max-w-2xl">
            <div className="mb-3 inline-flex items-center gap-2 rounded-full border border-cyan-100 bg-cyan-50 px-3 py-1.5 text-[11px] font-bold uppercase tracking-[.16em] text-cyan-900">
              <span className="h-1.5 w-1.5 rounded-full bg-cyan-600" /> Student Voice Hub
            </div>
            <h1 className="text-2xl font-black tracking-tight text-slate-950 sm:text-3xl">{title}</h1>
            <p className="mt-2 max-w-xl text-sm leading-6 text-slate-600">A focused overview of student participation, school feedback, and the updates that need your attention.</p>
          </div>
          <div className="rounded-2xl border border-slate-200/80 bg-white/90 px-4 py-3 shadow-sm">
            <p className="text-xs font-medium text-slate-500">Workspace status</p>
            <p className="mt-1 flex items-center gap-2 text-sm font-semibold text-slate-800"><span className="h-2 w-2 rounded-full bg-emerald-500" /> Ready for review</p>
          </div>
        </div>
      </section>

      <section aria-label="School activity metrics" className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {showPeople && <StatCard label="Students" value={students} hint="Student accounts in your school" />}
        {showPeople && <StatCard label="Teachers" value={teachers} hint="Teacher accounts in your school" />}
        <StatCard label="Polls" value={polls} hint="Polls visible to this workspace" />
        <StatCard label="Votes cast" value={votes} hint="Recorded participation" />
        <StatCard label="Open issues" value={openIssues} hint="Open, acknowledged, or in progress" />
        <StatCard label="Ideas awaiting review" value={pendingIdeas} hint="Submitted or under review" />
      </section>

      <section>
        <div className="mb-4 flex items-end justify-between gap-4">
          <div><h2 className="text-lg font-bold tracking-tight text-slate-950">Quick actions</h2><p className="mt-1 text-sm text-slate-500">Jump straight to the tools you use most.</p></div>
          <Badge tone="blue">{showPeople ? "School admin" : "Teacher"}</Badge>
        </div>
        <div className="grid gap-3 sm:grid-cols-2">
          {actions.map((action) => (
            <Link key={action.href} href={action.href} className="group flex min-h-28 items-start gap-4 rounded-2xl border border-slate-200/80 bg-white p-5 shadow-sm transition hover:-translate-y-0.5 hover:border-cyan-200 hover:shadow-md focus:outline-none focus:ring-2 focus:ring-cyan-500 focus:ring-offset-2">
              <span className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl text-xl ${action.tint}`}>{action.icon}</span>
              <span className="min-w-0 flex-1"><span className="flex items-center justify-between gap-2 font-semibold text-slate-900">{action.title}<span aria-hidden="true" className="text-slate-300 transition group-hover:translate-x-0.5 group-hover:text-cyan-700">→</span></span><span className="mt-1 block text-sm leading-5 text-slate-500">{action.detail}</span></span>
            </Link>
          ))}
        </div>
      </section>

      <Card className="rounded-2xl border-slate-200/80 p-5 sm:p-6">
        <CardHeader title="Recent announcements" description="The latest updates shared with your school community." action={<Link href={showPeople ? "/school-admin/announcements" : "/teacher/announcements"} className="text-sm font-semibold text-brand hover:underline">View all</Link>} />
        {!recent?.length ? <EmptyState title="No announcements yet" description="When your school shares an update, it will appear here." /> : (
          <ul className="divide-y divide-slate-100/90">
            {recent.map((a) => <li key={a.id} className="flex items-start justify-between gap-4 py-3.5"><div className="min-w-0"><p className="font-medium text-slate-800">{a.title}</p><p className="mt-1 text-xs text-slate-400">School update</p></div><time className="shrink-0 pt-0.5 text-xs text-slate-400">{fmtDate(a.created_at)}</time></li>)}
          </ul>
        )}
      </Card>
    </div>
  );
}
