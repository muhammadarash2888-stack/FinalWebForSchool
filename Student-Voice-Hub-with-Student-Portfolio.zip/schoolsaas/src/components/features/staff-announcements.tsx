import { createClient } from "@/lib/supabase/server";
import { Card, CardHeader, Input, Textarea, Select, Label, EmptyState, Badge, ErrorState } from "@/components/ui/primitives";
import { ActionForm, ActionButton } from "@/components/ui/action-form";
import { createAnnouncementAction, deleteAnnouncementAction } from "@/app/actions/announcements";
import { fmtDate } from "@/components/ui/helpers";

export async function StaffAnnouncements() {
  const supabase = createClient();
  const { data, error } = await supabase.from("announcements").select("*").order("is_pinned", { ascending: false }).order("created_at", { ascending: false });
  if (error) return <ErrorState message={error.message} />;
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">Announcements</h1>
      <Card>
        <CardHeader title="New announcement" />
        <ActionForm action={createAnnouncementAction} submitLabel="Publish" successMessage="Announcement published">
          <div><Label>Title</Label><Input name="title" required /></div>
          <div><Label>Message</Label><Textarea name="body" rows={4} required /></div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div><Label>Audience</Label>
              <Select name="audience" defaultValue="all">
                <option value="all">Everyone</option><option value="students">Students</option><option value="teachers">Teachers</option><option value="parents">Parents / guardians</option>
              </Select></div>
            <label className="flex items-end gap-2 pb-2 text-sm"><input type="checkbox" name="is_pinned" /> Pin to top</label>
          </div>
        </ActionForm>
      </Card>
      {!data?.length ? <EmptyState title="No announcements" description="Publish one above." /> : (
        <div className="space-y-3">
          {data.map((a) => (
            <Card key={a.id}>
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2"><h3 className="font-semibold">{a.title}</h3>{a.is_pinned && <Badge tone="purple">Pinned</Badge>}<Badge>{a.audience}</Badge></div>
                  <p className="mt-1 whitespace-pre-wrap text-sm text-slate-600">{a.body}</p>
                  <p className="mt-2 text-xs text-slate-400">{fmtDate(a.created_at)}</p>
                </div>
                <ActionButton variant="ghost" confirmText="Delete this announcement?" run={deleteAnnouncementAction.bind(null, a.id)} successMessage="Deleted">Delete</ActionButton>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
