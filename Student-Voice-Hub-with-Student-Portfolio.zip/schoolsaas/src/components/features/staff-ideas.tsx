import { createClient } from "@/lib/supabase/server";
import { Badge, EmptyState, ErrorState, Table, Thead, Tbody, Td } from "@/components/ui/primitives";
import { StatusSelect } from "@/components/ui/action-form";
import { updateIdeaStatusAction } from "@/app/actions/ideas";
import { fmtDate, IDEA_STATUSES, toneFor } from "@/components/ui/helpers";

export async function StaffIdeas() {
  const supabase = createClient();
  const { data: ideas, error } = await supabase
    .from("ideas").select("*, author:profiles!ideas_created_by_fkey(full_name)").order("created_at", { ascending: false });
  if (error) return <ErrorState message={error.message} />;

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">Student ideas</h1>
      {!ideas?.length ? <EmptyState title="No ideas yet" description="Ideas submitted by students appear here." /> : (
        <Table>
          <Thead columns={["Idea", "Category", "By", "Date", "Status"]} />
          <Tbody>
            {ideas.map((i: any) => (
              <tr key={i.id}>
                <Td className="max-w-md whitespace-normal"><p className="font-medium text-slate-900">{i.title}</p><p className="text-slate-500">{i.description}</p></Td>
                <Td>{i.category ?? "—"}</Td>
                <Td>{i.author?.full_name ?? "—"}</Td>
                <Td>{fmtDate(i.created_at)}</Td>
                <Td>
                  <StatusSelect value={i.status} options={IDEA_STATUSES}
                    onChange={updateIdeaStatusAction.bind(null, i.id) as (v: string) => Promise<{ error?: string; success?: boolean }>} />
                  <div className="mt-1"><Badge tone={toneFor(i.status)}>{i.status.replace("_", " ")}</Badge></div>
                </Td>
              </tr>
            ))}
          </Tbody>
        </Table>
      )}
    </div>
  );
}
