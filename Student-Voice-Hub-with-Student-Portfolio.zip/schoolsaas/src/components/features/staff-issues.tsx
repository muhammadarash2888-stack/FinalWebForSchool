import { createClient } from "@/lib/supabase/server";
import { Badge, EmptyState, ErrorState, Table, Thead, Tbody, Td } from "@/components/ui/primitives";
import { StatusSelect } from "@/components/ui/action-form";
import { updateIssueStatusAction } from "@/app/actions/issues";
import { fmtDate, ISSUE_STATUSES, toneFor } from "@/components/ui/helpers";

export async function StaffIssues() {
  const supabase = createClient();
  const { data: issues, error } = await supabase
    .from("issues").select("*, author:profiles!issues_created_by_fkey(full_name)").order("created_at", { ascending: false });
  if (error) return <ErrorState message={error.message} />;

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">Reported issues</h1>
      {!issues?.length ? <EmptyState title="No issues reported" description="Everything looks good." /> : (
        <Table>
          <Thead columns={["Issue", "Location", "Severity", "Reported by", "Date", "Status"]} />
          <Tbody>
            {issues.map((i: any) => (
              <tr key={i.id}>
                <Td className="max-w-md whitespace-normal"><p className="font-medium text-slate-900">{i.title}</p><p className="text-slate-500">{i.description}</p></Td>
                <Td>{i.location ?? "—"}</Td>
                <Td><Badge tone={toneFor(i.severity)}>{i.severity}</Badge></Td>
                <Td>{i.author?.full_name ?? "—"}</Td>
                <Td>{fmtDate(i.created_at)}</Td>
                <Td><StatusSelect value={i.status} options={ISSUE_STATUSES} onChange={updateIssueStatusAction.bind(null, i.id) as (v: string) => Promise<{ error?: string; success?: boolean }>} /></Td>
              </tr>
            ))}
          </Tbody>
        </Table>
      )}
    </div>
  );
}
