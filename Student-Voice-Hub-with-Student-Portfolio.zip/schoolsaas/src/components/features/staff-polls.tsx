import { createClient } from "@/lib/supabase/server";
import { Card, CardHeader, Input, Textarea, Label, EmptyState, Badge, ErrorState } from "@/components/ui/primitives";
import { ActionForm, ActionButton } from "@/components/ui/action-form";
import { createPollAction, togglePollActiveAction } from "@/app/actions/polls";
import { fmtDate } from "@/components/ui/helpers";

export async function StaffPolls() {
  const supabase = createClient();
  const { data: polls, error } = await supabase.from("polls").select("*").order("created_at", { ascending: false });
  const { data: results } = await supabase.from("poll_results").select("*");
  const { data: votes } = await supabase.from("votes").select("poll_id");
  if (error) return <ErrorState message={error.message} />;

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold">Polls</h1>
      <Card>
        <CardHeader title="Create a poll" description="One option per line (minimum two)." />
        <ActionForm action={createPollAction} submitLabel="Create poll" successMessage="Poll created">
          <div><Label>Question</Label><Input name="title" required placeholder="What should we do for sports day?" /></div>
          <div><Label>Description (optional)</Label><Input name="description" /></div>
          <div><Label>Options</Label><Textarea name="options" rows={4} required placeholder={"Option A\nOption B"} /></div>
        </ActionForm>
      </Card>

      {!polls?.length ? (
        <EmptyState title="No polls yet" description="Create your first poll above." />
      ) : (
        <div className="grid gap-4 md:grid-cols-2">
          {polls.map((p) => {
            const rs = (results ?? []).filter((r) => r.poll_id === p.id);
            const total = (votes ?? []).filter((v) => v.poll_id === p.id).length;
            return (
              <Card key={p.id}>
                <CardHeader
                  title={p.title}
                  description={`${fmtDate(p.created_at)} · ${total} vote${total === 1 ? "" : "s"}`}
                  action={<Badge tone={p.is_active ? "green" : "slate"}>{p.is_active ? "Open" : "Closed"}</Badge>}
                />
                <div className="space-y-3">
                  {rs.map((r) => {
                    const pct = total ? Math.round((r.vote_count / total) * 100) : 0;
                    return (
                      <div key={r.poll_option_id}>
                        <div className="mb-1 flex justify-between text-sm"><span>{r.label}</span><span className="text-slate-500">{r.vote_count} ({pct}%)</span></div>
                        <div className="h-2 rounded-full bg-slate-100"><div className="h-2 rounded-full bg-brand" style={{ width: `${pct}%` }} /></div>
                      </div>
                    );
                  })}
                </div>
                <div className="mt-4">
                  <ActionButton run={togglePollActiveAction.bind(null, p.id, !p.is_active)} successMessage="Poll updated">
                    {p.is_active ? "Close poll" : "Reopen poll"}
                  </ActionButton>
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
