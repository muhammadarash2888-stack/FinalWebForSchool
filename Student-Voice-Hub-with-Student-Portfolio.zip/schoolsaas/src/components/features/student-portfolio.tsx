"use client";

import { useState, useTransition } from "react";
import { getPortfolioFileUrlAction, reviewPortfolioItemAction, submitPortfolioItemAction } from "@/app/actions/portfolio";

type PortfolioItem = {
  id: string;
  title: string;
  category: string;
  issuer: string | null;
  achievement_date: string | null;
  description: string | null;
  file_path: string | null;
  review_status: "pending" | "verified" | "needs_changes";
  reviewer_notes: string | null;
  created_at: string;
  student?: { full_name: string; class_name: string | null } | null;
};

const statusStyles: Record<PortfolioItem["review_status"], string> = {
  pending: "bg-amber-50 text-amber-700 ring-amber-200",
  verified: "bg-emerald-50 text-emerald-700 ring-emerald-200",
  needs_changes: "bg-rose-50 text-rose-700 ring-rose-200",
};

export function StudentPortfolio({ items, staffView = false }: { items: PortfolioItem[]; staffView?: boolean }) {
  const [message, setMessage] = useState("");
  const [pending, startTransition] = useTransition();
  const [busyId, setBusyId] = useState<string | null>(null);

  function submit(formData: FormData) {
    setMessage("");
    startTransition(async () => {
      const result = await submitPortfolioItemAction(formData);
      setMessage(result.error || "Your achievement was submitted for school review.");
      if (result.success) (document.getElementById("portfolio-form") as HTMLFormElement | null)?.reset();
    });
  }

  async function openEvidence(path: string) {
    setBusyId(path);
    const result = await getPortfolioFileUrlAction(path);
    setBusyId(null);
    if (result.url) window.open(result.url, "_blank", "noopener,noreferrer");
    else setMessage(result.error || "Unable to open file.");
  }

  function review(item: PortfolioItem, status: "verified" | "needs_changes") {
    const notes = window.prompt(status === "verified" ? "Optional verification note:" : "What should the student improve or upload?") || "";
    startTransition(async () => {
      const result = await reviewPortfolioItemAction(item.id, status, notes);
      setMessage(result.error || "Review saved.");
    });
  }

  return (
    <div className="space-y-6">
      <div className="rounded-2xl border border-slate-200 bg-gradient-to-br from-white to-slate-50 p-6 shadow-sm">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <p className="text-xs font-bold uppercase tracking-[.16em] text-brand">Student achievements</p>
            <h1 className="mt-2 text-2xl font-bold tracking-tight text-slate-950">{staffView ? "Student Portfolio Review" : "My Portfolio"}</h1>
            <p className="mt-2 max-w-2xl text-sm leading-6 text-slate-600">{staffView ? "Review certificates, awards, projects and activities submitted by students in your school." : "Build a record of your certificates, awards, competitions, projects, volunteering and leadership activities."}</p>
          </div>
          <div className="rounded-xl border border-slate-200 bg-white px-4 py-3 text-right"><p className="text-2xl font-bold text-slate-900">{items.length}</p><p className="text-xs text-slate-500">{staffView ? "Submissions" : "My entries"}</p></div>
        </div>
      </div>

      {!staffView && <form id="portfolio-form" action={submit} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
        <h2 className="text-base font-semibold text-slate-900">Add an achievement</h2>
        <p className="mt-1 text-sm text-slate-500">Upload one supporting PDF or image (maximum 10 MB).</p>
        <div className="mt-4 grid gap-4 sm:grid-cols-2">
          <label className="text-sm font-medium text-slate-700">Achievement title *<input name="title" required maxLength={140} placeholder="e.g. Robotics Regional Champion" className="mt-1.5 w-full rounded-xl border border-slate-200 px-3 py-2.5 font-normal outline-none focus:border-brand" /></label>
          <label className="text-sm font-medium text-slate-700">Category *<select name="category" className="mt-1.5 w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 font-normal"><option>Certificate</option><option>Award</option><option>Competition</option><option>Project</option><option>Volunteering</option><option>Leadership</option><option>Other</option></select></label>
          <label className="text-sm font-medium text-slate-700">Issued by / organiser<input name="issuer" maxLength={140} placeholder="School, organisation or event" className="mt-1.5 w-full rounded-xl border border-slate-200 px-3 py-2.5 font-normal outline-none focus:border-brand" /></label>
          <label className="text-sm font-medium text-slate-700">Date achieved<input name="achievement_date" type="date" className="mt-1.5 w-full rounded-xl border border-slate-200 px-3 py-2.5 font-normal" /></label>
          <label className="text-sm font-medium text-slate-700 sm:col-span-2">Description<textarea name="description" rows={3} maxLength={1200} placeholder="Briefly explain what you achieved..." className="mt-1.5 w-full rounded-xl border border-slate-200 px-3 py-2.5 font-normal outline-none focus:border-brand" /></label>
          <label className="text-sm font-medium text-slate-700 sm:col-span-2">Evidence file *<input name="evidence" type="file" required accept=".pdf,.jpg,.jpeg,.png,.webp,application/pdf,image/jpeg,image/png,image/webp" className="mt-1.5 block w-full rounded-xl border border-dashed border-slate-300 bg-slate-50 p-3 text-sm font-normal file:mr-3 file:rounded-lg file:border-0 file:bg-slate-900 file:px-3 file:py-2 file:text-white" /><span className="mt-1 block text-xs font-normal text-slate-400">PDF, JPG, PNG or WEBP · up to 10 MB · stored privately</span></label>
        </div>
        <button disabled={pending} className="mt-5 rounded-xl bg-slate-900 px-5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-slate-700 disabled:opacity-50">{pending ? "Submitting..." : "Submit for review"}</button>
      </form>}

      {message && <p role="status" className="rounded-xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-700">{message}</p>}

      <section className="space-y-3">
        <div className="flex items-center justify-between"><h2 className="text-lg font-semibold text-slate-900">{staffView ? "Submitted achievements" : "My achievements"}</h2><span className="text-xs text-slate-400">Newest first</span></div>
        {items.length === 0 ? <div className="rounded-2xl border border-dashed border-slate-300 bg-white px-6 py-12 text-center"><div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-slate-100 text-xl">✦</div><h3 className="mt-3 font-semibold text-slate-900">No portfolio entries yet</h3><p className="mt-1 text-sm text-slate-500">{staffView ? "Student submissions will appear here when they upload evidence." : "Add your first certificate or achievement using the form above."}</p></div> : items.map((item) => <article key={item.id} className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm">
          <div className="flex flex-wrap items-start justify-between gap-3"><div><div className="flex flex-wrap items-center gap-2"><span className="rounded-lg bg-slate-100 px-2.5 py-1 text-xs font-semibold text-slate-600">{item.category}</span><span className={`rounded-lg px-2.5 py-1 text-xs font-semibold ring-1 ${statusStyles[item.review_status]}`}>{item.review_status === "needs_changes" ? "Needs changes" : item.review_status === "verified" ? "Verified" : "Pending review"}</span></div><h3 className="mt-3 font-semibold text-slate-900">{item.title}</h3><p className="mt-1 text-sm text-slate-500">{staffView && item.student ? `${item.student.full_name}${item.student.class_name ? ` · ${item.student.class_name}` : ""} · ` : ""}{[item.issuer, item.achievement_date].filter(Boolean).join(" · ") || "Achievement details"}</p></div>
            {item.file_path && <button type="button" disabled={busyId === item.file_path} onClick={() => openEvidence(item.file_path!)} className="rounded-xl border border-slate-200 px-3 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-50 disabled:opacity-50">{busyId === item.file_path ? "Opening..." : "View evidence ↗"}</button>}
          </div>
          {item.description && <p className="mt-3 whitespace-pre-wrap text-sm leading-6 text-slate-600">{item.description}</p>}
          {item.reviewer_notes && <p className="mt-3 rounded-xl bg-slate-50 px-3 py-2 text-sm text-slate-600"><strong>Reviewer note:</strong> {item.reviewer_notes}</p>}
          {staffView && <div className="mt-4 flex flex-wrap gap-2 border-t border-slate-100 pt-4"><button disabled={pending || item.review_status === "verified"} onClick={() => review(item, "verified")} className="rounded-lg bg-emerald-600 px-3 py-2 text-xs font-semibold text-white disabled:opacity-40">Verify achievement</button><button disabled={pending} onClick={() => review(item, "needs_changes")} className="rounded-lg border border-rose-200 px-3 py-2 text-xs font-semibold text-rose-700 hover:bg-rose-50 disabled:opacity-40">Request changes</button></div>}
        </article>)}
      </section>
    </div>
  );
}
