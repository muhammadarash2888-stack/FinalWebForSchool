import { createClient } from "@/lib/supabase/server";
import { requireProfile } from "@/lib/auth";
import { Badge, Card, CardHeader, EmptyState, StatCard } from "@/components/ui/primitives";

function dateLabel(value: string) {
  return new Intl.DateTimeFormat("en-AE", { day: "numeric", month: "short", year: "numeric", timeZone: "Asia/Dubai" }).format(new Date(`${value}T12:00:00+04:00`));
}
function tone(status: string): "green" | "red" | "yellow" | "blue" | "slate" {
  if (status === "present") return "green";
  if (status === "absent") return "red";
  if (status === "late" || status === "excused") return "yellow";
  return "blue";
}

export async function StudentAttendance() {
  const profile = await requireProfile();
  const supabase = createClient();
  const from = new Date(); from.setDate(from.getDate() - 30);
  const since = new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Dubai", year: "numeric", month: "2-digit", day: "2-digit" }).format(from);
  const { data: records, error } = await supabase.from("attendance_records").select("id,attendance_date,status,note").eq("student_id", profile.id).gte("attendance_date", since).order("attendance_date", { ascending: false }).limit(60);
  const rows = records ?? [];
  const eligible = rows.filter((row) => row.status !== "excused").length;
  const attended = rows.filter((row) => row.status === "present" || row.status === "late").length;
  const rate = eligible ? (attended / eligible) * 100 : null;
  return <div className="space-y-6"><div><p className="text-xs font-bold uppercase tracking-[.16em] text-cyan-800">My school records</p><h1 className="mt-2 text-2xl font-black tracking-tight text-slate-950">My attendance</h1><p className="mt-1 text-sm text-slate-500">Attendance recorded by school staff over the last 30 days.</p></div>{error && <p className="rounded-xl bg-rose-50 p-3 text-sm text-rose-700">Attendance could not be loaded: {error.message}</p>}<div className="grid gap-3 sm:grid-cols-3"><StatCard label="Attendance rate" value={rate === null ? "—" : `${rate.toFixed(1)}%`} hint="Present or late among non-excused marked days" /><StatCard label="Days marked" value={rows.length} hint="Saved records in the last 30 days" /><StatCard label="Absences" value={rows.filter((row) => row.status === "absent").length} hint="Recorded absent status" /></div><Card><CardHeader title="Recent attendance" description="An excused record is not counted in the percentage shown above." />{!rows.length ? <EmptyState title="No recent attendance records" description="This does not necessarily mean you were absent. Ask your teacher if the register has not been marked." /> : <div className="overflow-x-auto"><table className="min-w-full divide-y divide-slate-200 text-sm"><thead className="bg-slate-50"><tr><th className="px-3 py-2 text-left text-xs font-semibold uppercase text-slate-500">Date</th><th className="px-3 py-2 text-left text-xs font-semibold uppercase text-slate-500">Status</th><th className="px-3 py-2 text-left text-xs font-semibold uppercase text-slate-500">Note</th></tr></thead><tbody className="divide-y divide-slate-100">{rows.map((row) => <tr key={row.id}><td className="px-3 py-3 text-slate-700">{dateLabel(row.attendance_date)}</td><td className="px-3 py-3"><Badge tone={tone(row.status)}>{row.status}</Badge></td><td className="px-3 py-3 text-slate-500">{row.note || "—"}</td></tr>)}</tbody></table></div>}</Card></div>;
}

export async function StudentAcademics() {
  const profile = await requireProfile();
  const supabase = createClient();
  const { data: results, error } = await supabase.from("academic_results").select("id,assessment_id,score,feedback,graded_at").eq("student_id", profile.id).order("graded_at", { ascending: false }).limit(100);
  const assessmentIds = Array.from(new Set((results ?? []).map((row) => row.assessment_id)));
  const { data: assessments } = assessmentIds.length ? await supabase.from("academic_assessments").select("id,title,subject,term,assessment_date,max_score").in("id", assessmentIds) : { data: [] };
  const assessmentMap = new Map((assessments ?? []).map((assessment: any) => [assessment.id, assessment]));
  const validRows = (results ?? []).filter((row) => assessmentMap.has(row.assessment_id));
  const average = validRows.length ? validRows.reduce((sum, row) => sum + Number(row.score) / Number((assessmentMap.get(row.assessment_id) as any).max_score) * 100, 0) / validRows.length : null;
  return <div className="space-y-6"><div><p className="text-xs font-bold uppercase tracking-[.16em] text-violet-800">My school records</p><h1 className="mt-2 text-2xl font-black tracking-tight text-slate-950">My grades</h1><p className="mt-1 text-sm text-slate-500">Assessment scores and feedback published by your teachers.</p></div>{error && <p className="rounded-xl bg-rose-50 p-3 text-sm text-rose-700">Academic records could not be loaded: {error.message}</p>}<div className="grid gap-3 sm:grid-cols-2"><StatCard label="Published results" value={validRows.length} hint="Assessments with saved marks" /><StatCard label="Average percentage" value={average === null ? "—" : `${average.toFixed(1)}%`} hint="Simple average across available results; not an official term grade" /></div><Card><CardHeader title="Assessment history" description="Use your school's formal report card for official grading and promotion decisions." />{!validRows.length ? <EmptyState title="No grades published yet" description="Your teachers' saved assessment results will appear here." /> : <div className="overflow-x-auto"><table className="min-w-full divide-y divide-slate-200 text-sm"><thead className="bg-slate-50"><tr><th className="px-3 py-2 text-left text-xs font-semibold uppercase text-slate-500">Assessment</th><th className="px-3 py-2 text-left text-xs font-semibold uppercase text-slate-500">Subject / term</th><th className="px-3 py-2 text-left text-xs font-semibold uppercase text-slate-500">Score</th><th className="px-3 py-2 text-left text-xs font-semibold uppercase text-slate-500">Percentage</th><th className="px-3 py-2 text-left text-xs font-semibold uppercase text-slate-500">Feedback</th></tr></thead><tbody className="divide-y divide-slate-100">{validRows.map((row) => { const a: any = assessmentMap.get(row.assessment_id); const pct = Number(row.score) / Number(a.max_score) * 100; return <tr key={row.id}><td className="px-3 py-3 font-semibold text-slate-800">{a.title}</td><td className="px-3 py-3 text-slate-500">{a.subject}<br /><span className="text-xs text-slate-400">{a.term} · {a.assessment_date}</span></td><td className="px-3 py-3 font-semibold">{row.score} / {a.max_score}</td><td className="px-3 py-3"><span className={`font-bold ${pct >= 80 ? "text-emerald-700" : pct >= 50 ? "text-amber-700" : "text-rose-700"}`}>{pct.toFixed(1)}%</span></td><td className="px-3 py-3 text-slate-500">{row.feedback || "—"}</td></tr>; })}</tbody></table></div>}</Card></div>;
}
