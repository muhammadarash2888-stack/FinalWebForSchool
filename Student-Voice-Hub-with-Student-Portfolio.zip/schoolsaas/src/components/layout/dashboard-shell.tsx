"use client";

import { useState } from "react";
import { Sidebar, MobileTopbar } from "./sidebar";
import { ToastProvider } from "@/components/ui/toast";
import type { UserRole } from "@/types/database";

export function DashboardShell({
  role,
  schoolName,
  logoUrl,
  brandColor,
  userName,
  userEmail,
  children,
}: {
  role: UserRole;
  schoolName: string;
  logoUrl?: string | null;
  brandColor?: string | null;
  userName: string;
  userEmail: string;
  children: React.ReactNode;
}) {
  const [open, setOpen] = useState(false);

  return (
    <ToastProvider>
      <div className="flex h-screen overflow-hidden bg-gradient-to-br from-slate-50 via-slate-50 to-slate-100/70" style={brandColor && /^#[0-9a-fA-F]{6}$/.test(brandColor) ? ({ ["--brand-color" as string]: brandColor } as React.CSSProperties) : undefined}>
        <div className="hidden md:block">
          <Sidebar role={role} logoUrl={logoUrl} schoolName={schoolName} userName={userName} userEmail={userEmail} />
        </div>
        {open && (
          <div className="fixed inset-0 z-40 md:hidden">
            <button type="button" aria-label="Close menu" className="absolute inset-0 h-full w-full bg-slate-950/35 backdrop-blur-[2px]" onClick={() => setOpen(false)} />
            <div className="absolute inset-y-0 left-0 shadow-2xl">
              <Sidebar role={role} logoUrl={logoUrl} schoolName={schoolName} userName={userName} userEmail={userEmail} onNavigate={() => setOpen(false)} />
            </div>
          </div>
        )}
        <div className="flex min-w-0 flex-1 flex-col">
          <MobileTopbar schoolName={schoolName} onMenuClick={() => setOpen(true)} />
          <main className="flex-1 overflow-y-auto px-4 py-5 sm:px-6 md:px-8 md:py-8">
            <div className="mx-auto flex min-h-full max-w-7xl flex-col">
              <div className="flex-1">{children}</div>
              <footer className="mt-10 flex flex-col gap-2 border-t border-slate-200/80 pt-5 text-xs text-slate-400 sm:flex-row sm:items-center sm:justify-between">
                <span>© {new Date().getFullYear()} {schoolName} · Student Voice Hub</span>
                <span className="font-medium text-slate-500">Made by Muhammad Arsh</span>
              </footer>
            </div>
          </main>
        </div>
      </div>
    </ToastProvider>
  );
}
