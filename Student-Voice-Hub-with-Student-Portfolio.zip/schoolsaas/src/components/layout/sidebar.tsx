"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import clsx from "clsx";
import type { UserRole } from "@/types/database";
import { signOutAction } from "@/app/actions/auth";

type NavItem = { href: string; label: string; icon: string };

const NAV: Record<UserRole, NavItem[]> = {
  super_admin: [
    { href: "/super-admin", label: "Overview", icon: "grid" },
    { href: "/super-admin/schools", label: "Schools", icon: "building" },
    { href: "/super-admin/admins", label: "Administrators", icon: "users" },
  ],
  school_admin: [
    { href: "/school-admin", label: "Overview", icon: "grid" },
    { href: "/school-admin/people", label: "People & Parents", icon: "users" },
    { href: "/school-admin/attendance", label: "Attendance", icon: "calendar" },
    { href: "/school-admin/academics", label: "Academics & Grades", icon: "book" },
    { href: "/school-admin/portfolio", label: "Student Portfolio", icon: "award" },
    { href: "/school-admin/polls", label: "Polls", icon: "bar-chart" },
    { href: "/school-admin/ideas", label: "Ideas", icon: "bulb" },
    { href: "/school-admin/announcements", label: "Announcements", icon: "megaphone" },
    { href: "/school-admin/issues", label: "Reported Issues", icon: "flag" },
    { href: "/school-admin/settings", label: "School Settings", icon: "settings" },
  ],
  teacher: [
    { href: "/teacher", label: "Overview", icon: "grid" },
    { href: "/teacher/attendance", label: "Attendance register", icon: "calendar" },
    { href: "/teacher/academics", label: "Gradebook", icon: "book" },
    { href: "/teacher/portfolio", label: "Student Portfolio", icon: "award" },
    { href: "/teacher/polls", label: "Polls", icon: "bar-chart" },
    { href: "/teacher/ideas", label: "Student Ideas", icon: "bulb" },
    { href: "/teacher/announcements", label: "Announcements", icon: "megaphone" },
    { href: "/teacher/issues", label: "Reported Issues", icon: "flag" },
  ],
  parent: [
    { href: "/parent", label: "Family overview", icon: "grid" },
    { href: "/parent/attendance", label: "Attendance", icon: "calendar" },
    { href: "/parent/academics", label: "Academic progress", icon: "book" },
    { href: "/parent/announcements", label: "School updates", icon: "megaphone" },
    { href: "/parent/polls", label: "Student voice", icon: "bar-chart" },
  ],
  student: [
    { href: "/student", label: "Overview", icon: "grid" },
    { href: "/student/attendance", label: "My attendance", icon: "calendar" },
    { href: "/student/academics", label: "My grades", icon: "book" },
    { href: "/student/portfolio", label: "My Portfolio", icon: "award" },
    { href: "/student/announcements", label: "Announcements", icon: "megaphone" },
    { href: "/student/polls", label: "Polls", icon: "bar-chart" },
    { href: "/student/ideas", label: "My Ideas", icon: "bulb" },
    { href: "/student/issues", label: "Report an Issue", icon: "flag" },
  ],
};

const ICONS: Record<string, JSX.Element> = {
  grid: (
    <path strokeLinecap="round" strokeLinejoin="round" d="M4 4h6v6H4V4zm10 0h6v6h-6V4zM4 14h6v6H4v-6zm10 0h6v6h-6v-6z" />
  ),
  calendar: <path strokeLinecap="round" strokeLinejoin="round" d="M8 3v3m8-3v3M4 9h16M5 5h14a1 1 0 011 1v13a1 1 0 01-1 1H5a1 1 0 01-1-1V6a1 1 0 011-1zm3 8h3m-3 4h5" />,
  book: <path strokeLinecap="round" strokeLinejoin="round" d="M4 5.5A2.5 2.5 0 016.5 3H20v16H6.5A2.5 2.5 0 014 16.5v-11zM4 16.5A2.5 2.5 0 016.5 14H20M8 7h8m-8 3h6" />,
  building: <path strokeLinecap="round" strokeLinejoin="round" d="M4 21V5a1 1 0 011-1h6a1 1 0 011 1v16M4 21h16M12 21V9a1 1 0 011-1h6a1 1 0 011 1v12M8 8h.01M8 12h.01M8 16h.01" />,
  users: <path strokeLinecap="round" strokeLinejoin="round" d="M17 20h5v-2a4 4 0 00-3-3.87M9 20H4v-2a4 4 0 013-3.87m5-3a4 4 0 100-8 4 4 0 000 8zm7 1a4 4 0 10-3.87-5" />,
  "bar-chart": <path strokeLinecap="round" strokeLinejoin="round" d="M12 20V10M18 20V4M6 20v-4" />,
  award: <path strokeLinecap="round" strokeLinejoin="round" d="M12 15a6 6 0 100-12 6 6 0 000 12zm-3.5-1.2L7 22l5-2 5 2-1.5-8.2" />,
  bulb: <path strokeLinecap="round" strokeLinejoin="round" d="M9 18h6M10 22h4M12 2a7 7 0 00-4 12.7c.5.4.8 1 .8 1.7v.6h6.4v-.6c0-.7.3-1.3.8-1.7A7 7 0 0012 2z" />,
  megaphone: <path strokeLinecap="round" strokeLinejoin="round" d="M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.15M18 13.5v-3M18 13.5A2.5 2.5 0 0018 8.5v0M3 8.667C3 7.194 4.194 6 5.667 6h1.905c1.96 0 3.874-.6 5.483-1.717l1.658-1.153A1 1 0 0116.333 4v12.5a1 1 0 01-1.58.815L13.055 16a9.483 9.483 0 00-5.483-1.716H5.667A2.667 2.667 0 013 11.667V8.667z" />,
  flag: <path strokeLinecap="round" strokeLinejoin="round" d="M3 21V4a1 1 0 011.4-.92l1.2.5a5 5 0 003.8 0 5 5 0 013.8 0l1.2.5A1 1 0 0116 5v9.5a1 1 0 01-1.4.92l-.6-.25a5 5 0 00-3.8 0 5 5 0 01-3.8 0L6 14.8a1 1 0 00-.4-.08H4" />,
  settings: <path strokeLinecap="round" strokeLinejoin="round" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />,
};

function Icon({ name }: { name: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" className="h-5 w-5 shrink-0">
      {ICONS[name]}
    </svg>
  );
}

export function Sidebar({
  role,
  schoolName,
  logoUrl,
  userName,
  userEmail,
  onNavigate,
}: {
  role: UserRole;
  schoolName: string;
  logoUrl?: string | null;
  userName: string;
  userEmail: string;
  onNavigate?: () => void;
}) {
  const pathname = usePathname();
  const items = NAV[role];

  return (
    <aside className="flex h-full w-64 shrink-0 flex-col border-r border-slate-200/80 bg-white shadow-[8px_0_30px_-28px_rgba(15,23,42,0.3)]">
      <div className="border-b border-slate-100 px-5 py-5">
        <div className="flex items-center gap-3">
          {/* The tenant's configured logo takes priority; use the official IIS shield as the default. */}
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={logoUrl || "/iis-shield.png"} alt={`${schoolName} logo`} className="h-11 w-11 shrink-0 rounded-xl border border-slate-100 bg-white object-contain p-0.5 shadow-sm" />
          <div className="min-w-0">
            <p className="truncate text-sm font-semibold text-slate-900">{schoolName}</p>
            <p className="truncate text-xs capitalize text-slate-400">{role.replace("_", " ")}</p>
          </div>
        </div>
        <div className="mt-4 rounded-xl bg-slate-50 px-3 py-2.5"><p className="text-[10px] font-bold uppercase tracking-[.15em] text-slate-400">Workspace</p><p className="mt-0.5 text-xs font-semibold text-slate-700">Student Voice Hub</p></div>
      </div>

      <nav className="flex-1 space-y-1 overflow-y-auto px-3 py-4">
        {items.map((item) => {
          const active = pathname === item.href || (item.href !== `/${role.replace("_", "-")}` && pathname.startsWith(`${item.href}/`));
          return (
            <Link
              key={item.href}
              href={item.href}
              onClick={onNavigate}
              className={clsx(
                "flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-all duration-150",
                active ? "bg-brand/10 text-brand shadow-sm ring-1 ring-brand/10" : "text-slate-600 hover:bg-slate-50 hover:text-slate-950"
              )}
            >
              <Icon name={item.icon} />
              {item.label}
            </Link>
          );
        })}
      </nav>

      <div className="border-t border-slate-200 p-4">
        <div className="mb-3 flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-200 text-xs font-semibold text-slate-600">
            {userName.slice(0, 1).toUpperCase() || "?"}
          </div>
          <div className="min-w-0">
            <p className="truncate text-xs font-medium text-slate-900">{userName}</p>
            <p className="truncate text-xs text-slate-400">{userEmail}</p>
          </div>
        </div>
        <form action={signOutAction}>
          <button
            type="submit"
            className="w-full rounded-lg border border-slate-200 px-3 py-2 text-xs font-medium text-slate-600 hover:bg-slate-50"
          >
            Sign out
          </button>
        </form>
      </div>
    </aside>
  );
}

export function MobileTopbar({ schoolName, onMenuClick }: { schoolName: string; onMenuClick: () => void }) {
  return (
    <div className="flex items-center gap-3 border-b border-slate-200/80 bg-white px-4 py-3 shadow-sm md:hidden">
      <button onClick={onMenuClick} className="rounded-lg p-2 hover:bg-slate-100" aria-label="Open menu">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" className="h-5 w-5">
          <path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 12h16M4 18h16" />
        </svg>
      </button>
      <p className="text-sm font-semibold text-slate-900">{schoolName}</p>
    </div>
  );
}
