"use client";

import { useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { useToast } from "./toast";
import { Button } from "./primitives";

type Result = { error?: string; success?: boolean; message?: string } | void;

/** Form that calls a server action, shows toast, resets on success. */
export function ActionForm({
  action, submitLabel, successMessage = "Saved", children, className, resetOnSuccess = true,
}: {
  action: (fd: FormData) => Promise<Result>;
  submitLabel: string;
  successMessage?: string;
  children: React.ReactNode;
  className?: string;
  resetOnSuccess?: boolean;
}) {
  const ref = useRef<HTMLFormElement>(null);
  const [loading, setLoading] = useState(false);
  const toast = useToast();
  const router = useRouter();

  return (
    <form
      ref={ref}
      className={className ?? "space-y-4"}
      onSubmit={async (e) => {
        e.preventDefault();
        setLoading(true);
        try {
          const res = await action(new FormData(e.currentTarget));
          if (res && res.error) toast.push(res.error, "error");
          else { toast.push((res && "message" in res && typeof res.message === "string") ? res.message : successMessage, "success"); if (resetOnSuccess) ref.current?.reset(); router.refresh(); }
        } catch (err) {
          toast.push("Something went wrong. Please try again.", "error");
        } finally { setLoading(false); }
      }}
    >
      {children}
      <Button type="submit" loading={loading}>{submitLabel}</Button>
    </form>
  );
}

/** Small button that runs an async action with toast feedback. */
export function ActionButton({
  run, children, variant = "secondary", successMessage = "Done", confirmText,
}: {
  run: () => Promise<Result>;
  children: React.ReactNode;
  variant?: "primary" | "secondary" | "danger" | "ghost";
  successMessage?: string;
  confirmText?: string;
}) {
  const [loading, setLoading] = useState(false);
  const toast = useToast();
  const router = useRouter();
  return (
    <Button size="sm" variant={variant} loading={loading} onClick={async () => {
      if (confirmText && !confirm(confirmText)) return;
      setLoading(true);
      const res = await run();
      setLoading(false);
      if (res && res.error) toast.push(res.error, "error");
      else { toast.push(successMessage, "success"); router.refresh(); }
    }}>{children}</Button>
  );
}

/** Select that immediately runs an action on change (status dropdowns). */
export function StatusSelect({
  value, options, onChange,
}: {
  value: string;
  options: { value: string; label: string }[];
  onChange: (v: string) => Promise<Result>;
}) {
  const toast = useToast();
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  return (
    <select
      value={value}
      disabled={busy}
      className="rounded-lg border border-slate-300 bg-white px-2 py-1 text-xs"
      onChange={async (e) => {
        setBusy(true);
        const res = await onChange(e.target.value);
        setBusy(false);
        if (res && res.error) toast.push(res.error, "error");
        else { toast.push("Status updated", "success"); router.refresh(); }
      }}
    >
      {options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
    </select>
  );
}
