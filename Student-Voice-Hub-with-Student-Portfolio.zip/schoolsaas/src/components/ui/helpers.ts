export function fmtDate(d: string) {
  return new Date(d).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}
export const IDEA_STATUSES = ["submitted","under_review","approved","in_progress","completed","rejected"].map(v => ({ value: v, label: v.replace("_"," ") }));
export const ISSUE_STATUSES = ["open","acknowledged","in_progress","resolved","closed"].map(v => ({ value: v, label: v.replace("_"," ") }));
export function toneFor(status: string): "slate"|"green"|"yellow"|"red"|"blue"|"purple" {
  if (["approved","completed","resolved","active","closed"].includes(status)) return "green";
  if (["rejected","urgent","suspended","cancelled","high"].includes(status)) return "red";
  if (["under_review","acknowledged","in_progress","medium","trial"].includes(status)) return "yellow";
  if (["open","submitted","low"].includes(status)) return "blue";
  return "slate";
}
