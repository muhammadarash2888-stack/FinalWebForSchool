import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import type { Profile } from "@/types/database";

/**
 * Fetches the signed-in user's profile (role + school_id + ...). Redirects
 * to /login if there is no session. This is the ONLY source of truth this
 * app's UI uses to decide what to render — but note that UI gating here is
 * a convenience, not the security boundary. The real boundary is Postgres
 * Row Level Security (see supabase/migrations). Even if a page rendered the
 * wrong thing, the database would still refuse cross-school reads/writes.
 */
export async function requireProfile(): Promise<Profile> {
  const supabase = createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) redirect("/login");

  const { data: profile, error } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", user.id)
    .single();

  if (error || !profile) {
    // User exists in auth but has no profile row yet (e.g. trigger lag) or
    // was deactivated by an admin.
    redirect("/login?error=no_profile");
  }

  if (!profile.is_active) {
    redirect("/login?error=inactive");
  }

  return profile as Profile;
}

/** Redirects a signed-in user to the dashboard that matches their role. */
export function dashboardPathForRole(role: Profile["role"]): string {
  switch (role) {
    case "super_admin":
      return "/super-admin";
    case "school_admin":
      return "/school-admin";
    case "teacher":
      return "/teacher";
    case "parent":
      return "/parent";
    case "student":
    default:
      return "/student";
  }
}

/** Throws-and-redirects if the current profile's role isn't in `roles`. */
export function assertRole(profile: Profile, roles: Profile["role"][]) {
  if (!roles.includes(profile.role)) {
    redirect(dashboardPathForRole(profile.role));
  }
}
