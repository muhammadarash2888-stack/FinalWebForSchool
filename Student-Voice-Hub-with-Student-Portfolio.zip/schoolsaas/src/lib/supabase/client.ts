import { createBrowserClient } from "@supabase/ssr";

/**
 * Browser-side Supabase client.
 *
 * SECURITY: only ever uses NEXT_PUBLIC_* env vars (the URL + the
 * publishable/anon key). This key is safe to ship to the browser because
 * every table is protected by Row Level Security — see
 * supabase/migrations/0001_init_school_saas.sql. Never import the service
 * role key here or in any file under src/components or src/app/**\/page.tsx.
 */
export function createClient() {
  return createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );
}
