import { createServerClient, type CookieOptions } from "@supabase/ssr";
import { cookies } from "next/headers";

/**
 * Server-side Supabase client for use inside Server Components, Server
 * Actions and Route Handlers. Still uses only the public anon key — RLS on
 * the database is what actually enforces per-school data isolation, not
 * this client. This client is what carries the signed-in user's session
 * (via cookies) so that `auth.uid()` is populated for RLS policies.
 */
export function createClient() {
  const cookieStore = cookies();

  return createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        get(name: string) {
          return cookieStore.get(name)?.value;
        },
        set(name: string, value: string, options: CookieOptions) {
          try {
            cookieStore.set({ name, value, ...options });
          } catch {
            // Called from a Server Component — middleware refreshes the
            // session instead, so this can be safely ignored.
          }
        },
        remove(name: string, options: CookieOptions) {
          try {
            cookieStore.set({ name, value: "", ...options });
          } catch {
            // Same as above.
          }
        },
      },
    }
  );
}

/**
 * Admin client — SERVICE ROLE KEY. Server-only. Never import this from any
 * file that can end up in a client bundle. Used exclusively for privileged
 * operations that must bypass RLS by design and are already gated by an
 * explicit `is_super_admin()` / `is_school_admin()` check in the calling
 * Server Action (e.g. provisioning a brand-new school + its first admin
 * user, which happens before that admin has a session at all).
 */
export function createAdminClient() {
  if (typeof window !== "undefined") {
    throw new Error("createAdminClient() must never be called from the browser.");
  }
  const { createClient: createRawClient } = require("@supabase/supabase-js");
  return createRawClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.SUPABASE_SERVICE_ROLE_KEY!,
    { auth: { autoRefreshToken: false, persistSession: false } }
  );
}
