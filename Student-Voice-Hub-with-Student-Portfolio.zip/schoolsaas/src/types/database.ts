export type UserRole = "super_admin" | "school_admin" | "teacher" | "student" | "parent";
export type SchoolStatus = "active" | "suspended" | "trial" | "cancelled";
export type IdeaStatus =
  | "submitted"
  | "under_review"
  | "approved"
  | "in_progress"
  | "completed"
  | "rejected";
export type IssueStatus = "open" | "acknowledged" | "in_progress" | "resolved" | "closed";
export type IssueSeverity = "low" | "medium" | "high" | "urgent";

export interface School {
  id: string;
  name: string;
  slug: string;
  logo_url: string | null;
  primary_color: string | null;
  status: SchoolStatus;
  contact_email: string | null;
  subscription_plan: string | null;
  subscription_ends_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface Profile {
  id: string;
  school_id: string | null;
  role: UserRole;
  full_name: string;
  email: string | null;
  avatar_url: string | null;
  class_name: string | null;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface Poll {
  id: string;
  school_id: string;
  created_by: string;
  title: string;
  description: string | null;
  is_active: boolean;
  allow_multiple_votes: boolean;
  opens_at: string;
  closes_at: string | null;
  created_at: string;
}

export interface PollOption {
  id: string;
  poll_id: string;
  school_id: string;
  label: string;
  display_order: number;
  created_at: string;
}

export interface Vote {
  id: string;
  poll_id: string;
  poll_option_id: string;
  school_id: string;
  voter_id: string;
  created_at: string;
}

export interface Idea {
  id: string;
  school_id: string;
  created_by: string;
  title: string;
  description: string;
  category: string | null;
  status: IdeaStatus;
  admin_notes: string | null;
  upvotes: number;
  created_at: string;
  updated_at: string;
}

export interface Announcement {
  id: string;
  school_id: string;
  created_by: string;
  title: string;
  body: string;
  audience: "all" | "students" | "teachers" | "parents";
  is_pinned: boolean;
  published_at: string;
  created_at: string;
}

export interface Issue {
  id: string;
  school_id: string;
  created_by: string;
  title: string;
  description: string;
  location: string | null;
  severity: IssueSeverity;
  status: IssueStatus;
  assigned_to: string | null;
  resolution_notes: string | null;
  created_at: string;
  updated_at: string;
}

export interface PollResult {
  poll_id: string;
  poll_option_id: string;
  label: string;
  school_id: string;
  vote_count: number;
}


export type AttendanceStatus = "present" | "absent" | "late" | "excused";

export interface ParentStudentLink {
  id: string;
  school_id: string;
  parent_id: string;
  student_id: string;
  relationship: string;
  is_verified: boolean;
  created_by: string | null;
  created_at: string;
}

export interface AttendanceRecord {
  id: string;
  school_id: string;
  student_id: string;
  attendance_date: string;
  status: AttendanceStatus;
  note: string | null;
  marked_by: string | null;
  created_at: string;
  updated_at: string;
}

export interface AcademicAssessment {
  id: string;
  school_id: string;
  class_name: string;
  subject: string;
  title: string;
  term: string;
  assessment_date: string;
  max_score: number;
  created_by: string;
  created_at: string;
  updated_at: string;
}

export interface AcademicResult {
  id: string;
  school_id: string;
  assessment_id: string;
  student_id: string;
  score: number;
  feedback: string | null;
  graded_by: string | null;
  graded_at: string;
  created_at: string;
  updated_at: string;
}

export interface AttendanceDailySummary {
  school_id: string;
  attendance_date: string;
  recorded_count: number;
  present_count: number;
  absent_count: number;
  late_count: number;
  excused_count: number;
}

export interface AcademicSubjectSummary {
  school_id: string;
  subject: string;
  term: string;
  graded_count: number;
  average_percentage: number | null;
}

export interface SchoolClassSummary {
  school_id: string;
  class_name: string;
  student_count: number;
}

export interface Database {
  public: {
    Tables: {
      schools: { Row: School; Insert: Partial<School>; Update: Partial<School> };
      profiles: { Row: Profile; Insert: Partial<Profile>; Update: Partial<Profile> };
      polls: { Row: Poll; Insert: Partial<Poll>; Update: Partial<Poll> };
      poll_options: { Row: PollOption; Insert: Partial<PollOption>; Update: Partial<PollOption> };
      votes: { Row: Vote; Insert: Partial<Vote>; Update: Partial<Vote> };
      ideas: { Row: Idea; Insert: Partial<Idea>; Update: Partial<Idea> };
      announcements: { Row: Announcement; Insert: Partial<Announcement>; Update: Partial<Announcement> };
      issues: { Row: Issue; Insert: Partial<Issue>; Update: Partial<Issue> };
      parent_student_links: { Row: ParentStudentLink; Insert: Partial<ParentStudentLink>; Update: Partial<ParentStudentLink> };
      attendance_records: { Row: AttendanceRecord; Insert: Partial<AttendanceRecord>; Update: Partial<AttendanceRecord> };
      academic_assessments: { Row: AcademicAssessment; Insert: Partial<AcademicAssessment>; Update: Partial<AcademicAssessment> };
      academic_results: { Row: AcademicResult; Insert: Partial<AcademicResult>; Update: Partial<AcademicResult> };
    };
    Views: {
      poll_results: { Row: PollResult };
      attendance_daily_summaries: { Row: AttendanceDailySummary };
      academic_subject_summaries: { Row: AcademicSubjectSummary };
      school_class_summaries: { Row: SchoolClassSummary };
    };
  };
}
