-- ============================================================================
-- School SaaS Platform — Initial / Safe Migration
-- ============================================================================
-- This migration is written to be SAFE to run against a database that
-- already contains the tables listed in the brief (schools, profiles, polls,
-- poll_options, votes, ideas, announcements, issues) and existing data.
--
-- It uses:
--   - CREATE TABLE IF NOT EXISTS  -> never drops/recreates existing tables
--   - CREATE TYPE ... (guarded)   -> never fails if enum already exists
--   - ALTER TABLE ... ADD COLUMN IF NOT EXISTS -> additive only
--   - CREATE OR REPLACE for functions/views
--   - DROP POLICY IF EXISTS + CREATE POLICY -> safe to re-run, replaces logic
--     without touching table data
--
-- BEFORE RUNNING IN PRODUCTION:
--   1. Run `supabase db diff` / inspect your live schema first.
--   2. Run this against a staging branch/project first.
--   3. This file assumes `profiles.id` = `auth.users.id` (1:1), which is the
--      standard Supabase pattern. If your existing `profiles` table differs,
--      adjust the column names in section 1 before running.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 0. EXTENSIONS
-- ----------------------------------------------------------------------------
create extension if not exists "pgcrypto";      -- gen_random_uuid()
create extension if not exists "citext";         -- case-insensitive emails/slugs

-- ----------------------------------------------------------------------------
-- 1. ENUM TYPES (guarded — safe if they already exist)
-- ----------------------------------------------------------------------------
do $$
begin
  if not exists (select 1 from pg_type where typname = 'user_role') then
    create type user_role as enum ('super_admin', 'school_admin', 'teacher', 'student');
  end if;

  if not exists (select 1 from pg_type where typname = 'school_status') then
    create type school_status as enum ('active', 'suspended', 'trial', 'cancelled');
  end if;

  if not exists (select 1 from pg_type where typname = 'idea_status') then
    create type idea_status as enum ('submitted', 'under_review', 'approved', 'in_progress', 'completed', 'rejected');
  end if;

  if not exists (select 1 from pg_type where typname = 'issue_status') then
    create type issue_status as enum ('open', 'acknowledged', 'in_progress', 'resolved', 'closed');
  end if;

  if not exists (select 1 from pg_type where typname = 'issue_severity') then
    create type issue_severity as enum ('low', 'medium', 'high', 'urgent');
  end if;
end $$;

-- ----------------------------------------------------------------------------
-- 2. SCHOOLS  (the tenant table — everything else hangs off school_id)
-- ----------------------------------------------------------------------------
create table if not exists public.schools (
  id                uuid primary key default gen_random_uuid(),
  name              text not null,
  slug              citext not null unique,
  logo_url          text,
  primary_color     text default '#4f46e5',
  status            school_status not null default 'trial',
  contact_email     citext,
  subscription_plan text default 'trial',
  subscription_ends_at timestamptz,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now()
);

comment on table public.schools is 'Tenant table. One row per customer school.';

-- ----------------------------------------------------------------------------
-- 3. PROFILES  (1:1 with auth.users; carries role + school_id)
-- ----------------------------------------------------------------------------
create table if not exists public.profiles (
  id            uuid primary key references auth.users(id) on delete cascade,
  school_id     uuid references public.schools(id) on delete cascade,
  role          user_role not null default 'student',
  full_name     text not null default '',
  email         citext,
  avatar_url    text,
  class_name    text,               -- e.g. "Grade 9-B" (students/teachers)
  is_active     boolean not null default true,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  -- A super_admin has no school. Every other role MUST belong to a school.
  constraint profiles_school_required_unless_super_admin
    check (role = 'super_admin' or school_id is not null)
);

create index if not exists idx_profiles_school_id on public.profiles(school_id);
create index if not exists idx_profiles_role on public.profiles(role);

-- ----------------------------------------------------------------------------
-- 4. POLLS
-- ----------------------------------------------------------------------------
create table if not exists public.polls (
  id            uuid primary key default gen_random_uuid(),
  school_id     uuid not null references public.schools(id) on delete cascade,
  created_by    uuid not null references public.profiles(id) on delete cascade,
  title         text not null,
  description   text,
  is_active     boolean not null default true,
  allow_multiple_votes boolean not null default false,
  opens_at      timestamptz not null default now(),
  closes_at     timestamptz,
  created_at    timestamptz not null default now()
);

create index if not exists idx_polls_school_id on public.polls(school_id);

create table if not exists public.poll_options (
  id            uuid primary key default gen_random_uuid(),
  poll_id       uuid not null references public.polls(id) on delete cascade,
  school_id     uuid not null references public.schools(id) on delete cascade,
  label         text not null,
  display_order int not null default 0,
  created_at    timestamptz not null default now()
);

create index if not exists idx_poll_options_poll_id on public.poll_options(poll_id);

-- ----------------------------------------------------------------------------
-- 5. VOTES  (one vote per student per poll — enforced at DB level)
-- ----------------------------------------------------------------------------
create table if not exists public.votes (
  id            uuid primary key default gen_random_uuid(),
  poll_id       uuid not null references public.polls(id) on delete cascade,
  poll_option_id uuid not null references public.poll_options(id) on delete cascade,
  school_id     uuid not null references public.schools(id) on delete cascade,
  voter_id      uuid not null references public.profiles(id) on delete cascade,
  created_at    timestamptz not null default now(),
  -- THE critical constraint: a voter can only have ONE row per poll.
  constraint votes_one_per_student_per_poll unique (poll_id, voter_id)
);

create index if not exists idx_votes_poll_id on public.votes(poll_id);
create index if not exists idx_votes_school_id on public.votes(school_id);

-- ----------------------------------------------------------------------------
-- 6. IDEAS
-- ----------------------------------------------------------------------------
create table if not exists public.ideas (
  id            uuid primary key default gen_random_uuid(),
  school_id     uuid not null references public.schools(id) on delete cascade,
  created_by    uuid not null references public.profiles(id) on delete cascade,
  title         text not null,
  description   text not null,
  category      text,
  status        idea_status not null default 'submitted',
  admin_notes   text,
  upvotes       int not null default 0,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

create index if not exists idx_ideas_school_id on public.ideas(school_id);
create index if not exists idx_ideas_created_by on public.ideas(created_by);

-- ----------------------------------------------------------------------------
-- 7. ANNOUNCEMENTS
-- ----------------------------------------------------------------------------
create table if not exists public.announcements (
  id            uuid primary key default gen_random_uuid(),
  school_id     uuid not null references public.schools(id) on delete cascade,
  created_by    uuid not null references public.profiles(id) on delete cascade,
  title         text not null,
  body          text not null,
  audience      text not null default 'all', -- 'all' | 'students' | 'teachers'
  is_pinned     boolean not null default false,
  published_at  timestamptz not null default now(),
  created_at    timestamptz not null default now()
);

create index if not exists idx_announcements_school_id on public.announcements(school_id);

-- ----------------------------------------------------------------------------
-- 8. ISSUES (reported problems)
-- ----------------------------------------------------------------------------
create table if not exists public.issues (
  id            uuid primary key default gen_random_uuid(),
  school_id     uuid not null references public.schools(id) on delete cascade,
  created_by    uuid not null references public.profiles(id) on delete cascade,
  title         text not null,
  description   text not null,
  location      text,
  severity      issue_severity not null default 'medium',
  status        issue_status not null default 'open',
  assigned_to   uuid references public.profiles(id) on delete set null,
  resolution_notes text,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

create index if not exists idx_issues_school_id on public.issues(school_id);

-- ----------------------------------------------------------------------------
-- 9. updated_at trigger helper
-- ----------------------------------------------------------------------------
create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

do $$
declare
  t text;
begin
  foreach t in array array['schools','profiles','ideas','issues'] loop
    if not exists (
      select 1 from pg_trigger where tgname = t || '_set_updated_at'
    ) then
      execute format(
        'create trigger %I before update on public.%I for each row execute function public.set_updated_at()',
        t || '_set_updated_at', t
      );
    end if;
  end loop;
end $$;

-- ============================================================================
-- 10. HELPER FUNCTIONS FOR RLS
-- ----------------------------------------------------------------------------
-- SECURITY DEFINER functions that read the CALLING user's own profile.
-- These are the backbone of every RLS policy below: they let a policy check
-- "what school/role is the current auth.uid()" WITHOUT recursively
-- re-triggering RLS on `profiles` (which would deadlock/loop).
-- ============================================================================

create or replace function public.current_school_id()
returns uuid
language sql
stable
security definer
set search_path = public
as $$
  select school_id from public.profiles where id = auth.uid();
$$;

create or replace function public.current_role()
returns user_role
language sql
stable
security definer
set search_path = public
as $$
  select role from public.profiles where id = auth.uid();
$$;

create or replace function public.is_super_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select coalesce((select role = 'super_admin' from public.profiles where id = auth.uid()), false);
$$;

create or replace function public.is_school_staff()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select coalesce((select role in ('school_admin','teacher') from public.profiles where id = auth.uid()), false);
$$;

create or replace function public.is_school_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select coalesce((select role = 'school_admin' from public.profiles where id = auth.uid()), false);
$$;

-- ============================================================================
-- 11. ENABLE ROW LEVEL SECURITY ON EVERY TABLE
-- ============================================================================
alter table public.schools        enable row level security;
alter table public.profiles       enable row level security;
alter table public.polls          enable row level security;
alter table public.poll_options   enable row level security;
alter table public.votes          enable row level security;
alter table public.ideas          enable row level security;
alter table public.announcements  enable row level security;
alter table public.issues         enable row level security;

-- ============================================================================
-- 12. POLICIES — SCHOOLS
-- ============================================================================
drop policy if exists "schools_select" on public.schools;
create policy "schools_select" on public.schools
  for select using (
    public.is_super_admin() or id = public.current_school_id()
  );

drop policy if exists "schools_insert_super_admin" on public.schools;
create policy "schools_insert_super_admin" on public.schools
  for insert with check ( public.is_super_admin() );

drop policy if exists "schools_update_super_admin" on public.schools;
create policy "schools_update_super_admin" on public.schools
  for update using ( public.is_super_admin() )
  with check ( public.is_super_admin() );

drop policy if exists "schools_delete_super_admin" on public.schools;
create policy "schools_delete_super_admin" on public.schools
  for delete using ( public.is_super_admin() );

-- ============================================================================
-- 13. POLICIES — PROFILES
-- ============================================================================
drop policy if exists "profiles_select" on public.profiles;
create policy "profiles_select" on public.profiles
  for select using (
    public.is_super_admin()
    or id = auth.uid()
    or school_id = public.current_school_id()
  );

drop policy if exists "profiles_insert" on public.profiles;
create policy "profiles_insert" on public.profiles
  for insert with check (
    public.is_super_admin()
    or id = auth.uid()  -- self sign-up row creation
    or (public.is_school_admin() and school_id = public.current_school_id())
  );

drop policy if exists "profiles_update" on public.profiles;
create policy "profiles_update" on public.profiles
  for update using (
    public.is_super_admin()
    or id = auth.uid()
    or (public.is_school_admin() and school_id = public.current_school_id())
  )
  with check (
    public.is_super_admin()
    or id = auth.uid()
    or (public.is_school_admin() and school_id = public.current_school_id())
  );

drop policy if exists "profiles_delete" on public.profiles;
create policy "profiles_delete" on public.profiles
  for delete using (
    public.is_super_admin()
    or (public.is_school_admin() and school_id = public.current_school_id() and role <> 'school_admin')
  );

-- ============================================================================
-- 14. POLICIES — POLLS
-- ============================================================================
drop policy if exists "polls_select" on public.polls;
create policy "polls_select" on public.polls
  for select using (
    public.is_super_admin() or school_id = public.current_school_id()
  );

drop policy if exists "polls_insert" on public.polls;
create policy "polls_insert" on public.polls
  for insert with check (
    school_id = public.current_school_id()
    and public.is_school_staff()
    and created_by = auth.uid()
  );

drop policy if exists "polls_update" on public.polls;
create policy "polls_update" on public.polls
  for update using (
    school_id = public.current_school_id()
    and (public.is_school_admin() or created_by = auth.uid())
  )
  with check ( school_id = public.current_school_id() );

drop policy if exists "polls_delete" on public.polls;
create policy "polls_delete" on public.polls
  for delete using (
    school_id = public.current_school_id()
    and (public.is_school_admin() or created_by = auth.uid())
  );

-- ============================================================================
-- 15. POLICIES — POLL_OPTIONS
-- ============================================================================
drop policy if exists "poll_options_select" on public.poll_options;
create policy "poll_options_select" on public.poll_options
  for select using (
    public.is_super_admin() or school_id = public.current_school_id()
  );

drop policy if exists "poll_options_write" on public.poll_options;
create policy "poll_options_write" on public.poll_options
  for all using (
    school_id = public.current_school_id() and public.is_school_staff()
  )
  with check (
    school_id = public.current_school_id() and public.is_school_staff()
  );

-- ============================================================================
-- 16. POLICIES — VOTES
-- ============================================================================
-- Students see only their own vote rows; staff can see aggregate via views
-- (counts are computed from votes but individual identity stays private to
-- the voter + school staff who need it for moderation).
drop policy if exists "votes_select" on public.votes;
create policy "votes_select" on public.votes
  for select using (
    public.is_super_admin()
    or voter_id = auth.uid()
    or (school_id = public.current_school_id() and public.is_school_staff())
  );

drop policy if exists "votes_insert" on public.votes;
create policy "votes_insert" on public.votes
  for insert with check (
    voter_id = auth.uid()
    and school_id = public.current_school_id()
  );

-- Votes are immutable once cast (no update policy = updates blocked).
drop policy if exists "votes_delete" on public.votes;
create policy "votes_delete" on public.votes
  for delete using (
    voter_id = auth.uid() or (school_id = public.current_school_id() and public.is_school_admin())
  );

-- ============================================================================
-- 17. POLICIES — IDEAS
-- ============================================================================
drop policy if exists "ideas_select" on public.ideas;
create policy "ideas_select" on public.ideas
  for select using (
    public.is_super_admin() or school_id = public.current_school_id()
  );

drop policy if exists "ideas_insert" on public.ideas;
create policy "ideas_insert" on public.ideas
  for insert with check (
    school_id = public.current_school_id() and created_by = auth.uid()
  );

drop policy if exists "ideas_update" on public.ideas;
create policy "ideas_update" on public.ideas
  for update using (
    school_id = public.current_school_id()
    and (public.is_school_staff() or created_by = auth.uid())
  )
  with check ( school_id = public.current_school_id() );

drop policy if exists "ideas_delete" on public.ideas;
create policy "ideas_delete" on public.ideas
  for delete using (
    school_id = public.current_school_id()
    and (public.is_school_admin() or created_by = auth.uid())
  );

-- ============================================================================
-- 18. POLICIES — ANNOUNCEMENTS
-- ============================================================================
drop policy if exists "announcements_select" on public.announcements;
create policy "announcements_select" on public.announcements
  for select using (
    public.is_super_admin() or school_id = public.current_school_id()
  );

drop policy if exists "announcements_write" on public.announcements;
create policy "announcements_write" on public.announcements
  for all using (
    school_id = public.current_school_id() and public.is_school_staff()
  )
  with check (
    school_id = public.current_school_id()
    and public.is_school_staff()
    and created_by = auth.uid()
  );

drop policy if exists "announcements_delete" on public.announcements;
create policy "announcements_delete" on public.announcements
  for delete using (
    school_id = public.current_school_id()
    and (public.is_school_admin() or created_by = auth.uid())
  );

-- ============================================================================
-- 19. POLICIES — ISSUES
-- ============================================================================
drop policy if exists "issues_select" on public.issues;
create policy "issues_select" on public.issues
  for select using (
    public.is_super_admin()
    or (school_id = public.current_school_id() and (public.is_school_staff() or created_by = auth.uid()))
  );

drop policy if exists "issues_insert" on public.issues;
create policy "issues_insert" on public.issues
  for insert with check (
    school_id = public.current_school_id() and created_by = auth.uid()
  );

drop policy if exists "issues_update" on public.issues;
create policy "issues_update" on public.issues
  for update using (
    school_id = public.current_school_id()
    and (public.is_school_staff() or created_by = auth.uid())
  )
  with check ( school_id = public.current_school_id() );

drop policy if exists "issues_delete" on public.issues;
create policy "issues_delete" on public.issues
  for delete using (
    school_id = public.current_school_id() and public.is_school_admin()
  );

-- ============================================================================
-- 20. VIEW — poll results (safe aggregate, respects RLS of underlying votes)
-- ============================================================================
create or replace view public.poll_results as
select
  po.poll_id,
  po.id as poll_option_id,
  po.label,
  po.school_id,
  count(v.id)::int as vote_count
from public.poll_options po
left join public.votes v on v.poll_option_id = po.id
group by po.poll_id, po.id, po.label, po.school_id;

alter view public.poll_results set (security_invoker = on);

-- ============================================================================
-- 21. NEW-USER TRIGGER (optional convenience)
-- ----------------------------------------------------------------------------
-- If a school_id and role are supplied in auth signup metadata, auto-create
-- the matching profiles row. Safe no-op if a profile already exists.
-- ============================================================================
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, email, full_name, role, school_id)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data ->> 'full_name', ''),
    coalesce((new.raw_user_meta_data ->> 'role')::user_role, 'student'),
    nullif(new.raw_user_meta_data ->> 'school_id', '')::uuid
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ============================================================================
-- END OF MIGRATION
-- ============================================================================
