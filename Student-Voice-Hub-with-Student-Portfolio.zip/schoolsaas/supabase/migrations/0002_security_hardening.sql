-- 0002: Close privilege-escalation and integrity gaps found in review of 0001.

-- 1. Profiles: nobody except super_admin may change role or school_id; no self-insert.
drop policy if exists "profiles_insert" on public.profiles;
create policy "profiles_insert" on public.profiles
  for insert with check (
    public.is_super_admin()
    or (public.is_school_admin() and school_id = public.current_school_id() and role in ('student','teacher'))
  );

create or replace function public.guard_profile_update()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null or public.is_super_admin() then
    return new;  -- service role / super admin
  end if;
  if new.role is distinct from old.role or new.school_id is distinct from old.school_id then
    raise exception 'role and school_id cannot be changed';
  end if;
  -- only school admins may (de)activate accounts
  if new.is_active is distinct from old.is_active and not public.is_school_admin() then
    raise exception 'only administrators can change account status';
  end if;
  return new;
end $$;
drop trigger if exists profiles_guard on public.profiles;
create trigger profiles_guard before update on public.profiles
  for each row execute function public.guard_profile_update();

-- 2. Ideas: students may edit only their own title/description, never status/notes.
create or replace function public.guard_idea_update()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null or public.is_super_admin() or public.is_school_staff() then return new; end if;
  if new.status is distinct from old.status or new.admin_notes is distinct from old.admin_notes
     or new.upvotes is distinct from old.upvotes or new.school_id is distinct from old.school_id
     or new.created_by is distinct from old.created_by then
    raise exception 'students cannot change idea status or review fields';
  end if;
  return new;
end $$;
drop trigger if exists ideas_guard on public.ideas;
create trigger ideas_guard before update on public.ideas
  for each row execute function public.guard_idea_update();

-- 3. Issues: same protection for status/assignment.
create or replace function public.guard_issue_update()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null or public.is_super_admin() or public.is_school_staff() then return new; end if;
  if new.status is distinct from old.status or new.assigned_to is distinct from old.assigned_to
     or new.resolution_notes is distinct from old.resolution_notes
     or new.school_id is distinct from old.school_id or new.created_by is distinct from old.created_by then
    raise exception 'students cannot change issue status or review fields';
  end if;
  return new;
end $$;
drop trigger if exists issues_guard on public.issues;
create trigger issues_guard before update on public.issues
  for each row execute function public.guard_issue_update();

-- 4. Ideas/issues inserts: force safe defaults for non-staff.
create or replace function public.force_idea_defaults()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is not null and not public.is_super_admin() then
    new.status := 'submitted'; new.admin_notes := null; new.upvotes := 0;
  end if;
  return new;
end $$;
drop trigger if exists ideas_defaults on public.ideas;
create trigger ideas_defaults before insert on public.ideas
  for each row execute function public.force_idea_defaults();

create or replace function public.force_issue_defaults()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is not null and not public.is_super_admin() then
    new.status := 'open'; new.assigned_to := null; new.resolution_notes := null;
  end if;
  return new;
end $$;
drop trigger if exists issues_defaults on public.issues;
create trigger issues_defaults before insert on public.issues
  for each row execute function public.force_issue_defaults();

-- 5. Votes: students only, poll must be open, option must belong to that poll and school.
create or replace function public.validate_vote()
returns trigger language plpgsql security definer set search_path = public as $$
declare p record;
begin
  if public.current_role() <> 'student' then
    raise exception 'only students can vote';
  end if;
  select * into p from public.polls where id = new.poll_id;
  if p.id is null or p.school_id <> new.school_id then raise exception 'invalid poll'; end if;
  if not p.is_active or p.opens_at > now() or (p.closes_at is not null and p.closes_at < now()) then
    raise exception 'poll is closed';
  end if;
  if not exists (select 1 from public.poll_options o
                 where o.id = new.poll_option_id and o.poll_id = new.poll_id and o.school_id = new.school_id) then
    raise exception 'option does not belong to poll';
  end if;
  return new;
end $$;
drop trigger if exists votes_validate on public.votes;
create trigger votes_validate before insert on public.votes
  for each row execute function public.validate_vote();

-- Students may not delete their vote (would allow re-voting).
drop policy if exists "votes_delete" on public.votes;
create policy "votes_delete" on public.votes
  for delete using (public.is_super_admin() or (school_id = public.current_school_id() and public.is_school_admin()));

-- 6. Suspended schools lose access: data policies require an active school.
create or replace function public.school_is_usable()
returns boolean language sql stable security definer set search_path = public as $$
  select coalesce((select s.status in ('active','trial') from public.schools s
                   where s.id = public.current_school_id()), false);
$$;
-- Restrictive policies are ANDed with existing permissive ones.
do $$ declare t text; begin
  foreach t in array array['polls','poll_options','votes','ideas','announcements','issues'] loop
    execute format('drop policy if exists %I on public.%I', t||'_school_active', t);
    execute format($f$create policy %I on public.%I as restrictive for all
      using (public.is_super_admin() or public.school_is_usable())
      with check (public.is_super_admin() or public.school_is_usable())$f$, t||'_school_active', t);
  end loop;
end $$;

-- 7. Announcement audience filtering for students/teachers.
drop policy if exists "announcements_select" on public.announcements;
create policy "announcements_select" on public.announcements
  for select using (
    public.is_super_admin()
    or (school_id = public.current_school_id() and (
         public.is_school_admin()
         or audience = 'all'
         or (audience = 'students' and public.current_role() = 'student')
         or (audience = 'teachers' and public.current_role() = 'teacher')))
  );
