-- Add the parent role in its own migration so PostgreSQL commits the enum value
-- before later migrations reference it.
alter type public.user_role add value if not exists 'parent';
