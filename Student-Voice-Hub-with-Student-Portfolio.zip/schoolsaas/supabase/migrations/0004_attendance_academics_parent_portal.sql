-- Attendance, academic records and linked-parent portal. Additive migration: no existing data is dropped.
create extension if not exists pgcrypto;

create table if not exists public.parent_student_links (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references public.schools(id) on delete cascade,
  parent_id uuid not null references public.profiles(id) on delete cascade,
  student_id uuid not null references public.profiles(id) on delete cascade,
  relationship text not null default 'Parent/Guardian',
  is_verified boolean not null default true,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  constraint parent_student_link_unique unique (parent_id, student_id),
  constraint parent_student_not_self check (parent_id <> student_id)
);
create index if not exists idx_parent_student_parent on public.parent_student_links(parent_id, is_verified);
create index if not exists idx_parent_student_student on public.parent_student_links(student_id);

create table if not exists public.attendance_records (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references public.schools(id) on delete cascade,
  student_id uuid not null references public.profiles(id) on delete cascade,
  attendance_date date not null,
  status text not null check (status in ('present','absent','late','excused')),
  note text,
  marked_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint attendance_one_record_per_day unique (school_id, student_id, attendance_date)
);
create index if not exists idx_attendance_school_date on public.attendance_records(school_id, attendance_date desc);
create index if not exists idx_attendance_student_date on public.attendance_records(student_id, attendance_date desc);

create table if not exists public.academic_assessments (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references public.schools(id) on delete cascade,
  class_name text not null,
  subject text not null,
  title text not null,
  term text not null default 'Term 1',
  assessment_date date not null default current_date,
  max_score numeric(8,2) not null check (max_score > 0),
  created_by uuid not null references public.profiles(id) on delete restrict,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists idx_assessments_school_class_date on public.academic_assessments(school_id, class_name, assessment_date desc);

create table if not exists public.academic_results (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references public.schools(id) on delete cascade,
  assessment_id uuid not null references public.academic_assessments(id) on delete cascade,
  student_id uuid not null references public.profiles(id) on delete cascade,
  score numeric(8,2) not null check (score >= 0),
  feedback text,
  graded_by uuid references public.profiles(id) on delete set null,
  graded_at timestamptz not null default now(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint academic_result_unique unique (assessment_id, student_id)
);
create index if not exists idx_results_school_student on public.academic_results(school_id, student_id, graded_at desc);
create index if not exists idx_results_assessment on public.academic_results(assessment_id);

-- Security-definer relationship checks avoid broad parent access and prevent policy recursion.
create or replace function public.parent_has_student(p_student_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.parent_student_links l
    where l.parent_id = auth.uid() and l.student_id = p_student_id and l.is_verified = true
  );
$$;

create or replace function public.parent_has_class(p_class_name text, p_school_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1
    from public.parent_student_links l
    join public.profiles s on s.id = l.student_id
    where l.parent_id = auth.uid() and l.is_verified = true
      and l.school_id = p_school_id and s.class_name = p_class_name
  );
$$;

create or replace function public.validate_parent_student_link()
returns trigger language plpgsql security definer set search_path = public as $$
declare p public.profiles; s public.profiles;
begin
  select * into p from public.profiles where id = new.parent_id;
  select * into s from public.profiles where id = new.student_id;
  if p.id is null or s.id is null or p.role::text <> 'parent' or s.role::text <> 'student'
     or p.school_id is distinct from s.school_id or p.school_id is distinct from new.school_id then
    raise exception 'Parent and student must be valid accounts in the same school';
  end if;
  if new.created_by is not null and not exists (
    select 1 from public.profiles creator where creator.id = new.created_by
      and (creator.role::text = 'super_admin' or (creator.role::text = 'school_admin' and creator.school_id = new.school_id))
  ) then raise exception 'Parent links must be created by an authorised school administrator'; end if;
  return new;
end $$;
drop trigger if exists parent_student_link_validate on public.parent_student_links;
create trigger parent_student_link_validate before insert or update on public.parent_student_links
for each row execute function public.validate_parent_student_link();

create or replace function public.validate_attendance_record()
returns trigger language plpgsql security definer set search_path = public as $$
declare s public.profiles;
begin
  select * into s from public.profiles where id = new.student_id;
  if s.id is null or s.role::text <> 'student' or s.school_id is distinct from new.school_id then
    raise exception 'Attendance must belong to a student in this school';
  end if;
  if new.marked_by is not null and not exists (
    select 1 from public.profiles p where p.id = new.marked_by
      and p.school_id = new.school_id and p.role::text in ('teacher','school_admin')
  ) then raise exception 'Attendance must be marked by school staff'; end if;
  return new;
end $$;
drop trigger if exists attendance_record_validate on public.attendance_records;
create trigger attendance_record_validate before insert or update on public.attendance_records
for each row execute function public.validate_attendance_record();

create or replace function public.validate_academic_assessment()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if not exists (
    select 1 from public.profiles s where s.school_id = new.school_id
      and s.role::text = 'student' and s.class_name = new.class_name
  ) then raise exception 'Assessment class must match a student class in this school'; end if;
  if not exists (
    select 1 from public.profiles p where p.id = new.created_by
      and p.school_id = new.school_id and p.role::text in ('teacher','school_admin')
  ) then raise exception 'Assessments must be created by school staff'; end if;
  return new;
end $$;
drop trigger if exists academic_assessment_validate on public.academic_assessments;
create trigger academic_assessment_validate before insert or update on public.academic_assessments
for each row execute function public.validate_academic_assessment();

create or replace function public.validate_academic_result()
returns trigger language plpgsql security definer set search_path = public as $$
declare a public.academic_assessments; s public.profiles;
begin
  select * into a from public.academic_assessments where id = new.assessment_id;
  select * into s from public.profiles where id = new.student_id;
  if a.id is null or s.id is null or a.school_id is distinct from new.school_id
     or s.school_id is distinct from new.school_id or s.role::text <> 'student'
     or s.class_name is distinct from a.class_name then
    raise exception 'Result must match an assessment and student in the same class and school';
  end if;
  if new.score > a.max_score then raise exception 'Score cannot exceed the maximum score'; end if;
  if new.graded_by is not null and not exists (
    select 1 from public.profiles p where p.id = new.graded_by
      and p.school_id = new.school_id and p.role::text in ('teacher','school_admin')
  ) then raise exception 'Grades must be entered by school staff'; end if;
  new.updated_at := now();
  new.graded_at := now();
  return new;
end $$;
drop trigger if exists academic_result_validate on public.academic_results;
create trigger academic_result_validate before insert or update on public.academic_results
for each row execute function public.validate_academic_result();

-- updated_at consistency for new tables.
drop trigger if exists attendance_records_set_updated_at on public.attendance_records;
create trigger attendance_records_set_updated_at before update on public.attendance_records
for each row execute function public.set_updated_at();
drop trigger if exists academic_assessments_set_updated_at on public.academic_assessments;
create trigger academic_assessments_set_updated_at before update on public.academic_assessments
for each row execute function public.set_updated_at();
drop trigger if exists academic_results_set_updated_at on public.academic_results;
create trigger academic_results_set_updated_at before update on public.academic_results
for each row execute function public.set_updated_at();

alter table public.parent_student_links enable row level security;
alter table public.attendance_records enable row level security;
alter table public.academic_assessments enable row level security;
alter table public.academic_results enable row level security;

drop policy if exists parent_links_select on public.parent_student_links;
create policy parent_links_select on public.parent_student_links for select using (
  parent_id = auth.uid() or (school_id = public.current_school_id() and public.is_school_staff()) or public.is_super_admin()
);
drop policy if exists parent_links_insert on public.parent_student_links;
create policy parent_links_insert on public.parent_student_links for insert with check (
  public.is_super_admin() or (public.is_school_admin() and school_id = public.current_school_id())
);
drop policy if exists parent_links_update on public.parent_student_links;
create policy parent_links_update on public.parent_student_links for update using (
  public.is_super_admin() or (public.is_school_admin() and school_id = public.current_school_id())
) with check (public.is_super_admin() or (public.is_school_admin() and school_id = public.current_school_id()));
drop policy if exists parent_links_delete on public.parent_student_links;
create policy parent_links_delete on public.parent_student_links for delete using (
  public.is_super_admin() or (public.is_school_admin() and school_id = public.current_school_id())
);

drop policy if exists attendance_records_select on public.attendance_records;
create policy attendance_records_select on public.attendance_records for select using (
  public.is_super_admin() or (school_id = public.current_school_id() and (
    public.is_school_staff() or student_id = auth.uid() or public.parent_has_student(student_id)
  ))
);
drop policy if exists attendance_records_insert on public.attendance_records;
create policy attendance_records_insert on public.attendance_records for insert with check (
  school_id = public.current_school_id() and public.is_school_staff()
);
drop policy if exists attendance_records_update on public.attendance_records;
create policy attendance_records_update on public.attendance_records for update using (
  school_id = public.current_school_id() and public.is_school_staff()
) with check (school_id = public.current_school_id() and public.is_school_staff());
drop policy if exists attendance_records_delete on public.attendance_records;
create policy attendance_records_delete on public.attendance_records for delete using (
  public.is_super_admin() or (school_id = public.current_school_id() and public.is_school_admin())
);

drop policy if exists academic_assessments_select on public.academic_assessments;
create policy academic_assessments_select on public.academic_assessments for select using (
  public.is_super_admin() or (school_id = public.current_school_id() and (
    public.is_school_staff()
    or (public.current_role()::text = 'student' and class_name = (select p.class_name from public.profiles p where p.id = auth.uid()))
    or (public.current_role()::text = 'parent' and public.parent_has_class(class_name, school_id))
  ))
);
drop policy if exists academic_assessments_insert on public.academic_assessments;
create policy academic_assessments_insert on public.academic_assessments for insert with check (
  school_id = public.current_school_id() and public.is_school_staff() and created_by = auth.uid()
);
drop policy if exists academic_assessments_update on public.academic_assessments;
create policy academic_assessments_update on public.academic_assessments for update using (
  school_id = public.current_school_id() and public.is_school_staff()
) with check (school_id = public.current_school_id() and public.is_school_staff());
drop policy if exists academic_assessments_delete on public.academic_assessments;
create policy academic_assessments_delete on public.academic_assessments for delete using (
  public.is_super_admin() or (school_id = public.current_school_id() and public.is_school_admin())
);

drop policy if exists academic_results_select on public.academic_results;
create policy academic_results_select on public.academic_results for select using (
  public.is_super_admin() or (school_id = public.current_school_id() and (
    public.is_school_staff() or student_id = auth.uid() or public.parent_has_student(student_id)
  ))
);
drop policy if exists academic_results_insert on public.academic_results;
create policy academic_results_insert on public.academic_results for insert with check (
  school_id = public.current_school_id() and public.is_school_staff() and graded_by = auth.uid()
);
drop policy if exists academic_results_update on public.academic_results;
create policy academic_results_update on public.academic_results for update using (
  school_id = public.current_school_id() and public.is_school_staff()
) with check (school_id = public.current_school_id() and public.is_school_staff());
drop policy if exists academic_results_delete on public.academic_results;
create policy academic_results_delete on public.academic_results for delete using (
  public.is_super_admin() or (school_id = public.current_school_id() and public.is_school_admin())
);

-- Parents see only linked children (not the full school directory).
drop policy if exists profiles_select on public.profiles;
create policy profiles_select on public.profiles for select using (
  public.is_super_admin() or id = auth.uid()
  or (school_id = public.current_school_id() and public.is_school_staff())
  or (school_id = public.current_school_id() and public.current_role()::text in ('student','teacher'))
  or (public.current_role()::text = 'parent' and public.parent_has_student(id))
);

-- Parents may see general school messages and parent-specific messages.
drop policy if exists announcements_select on public.announcements;
create policy announcements_select on public.announcements for select using (
  public.is_super_admin() or (school_id = public.current_school_id() and (
    public.is_school_admin() or audience = 'all'
    or (audience = 'students' and public.current_role()::text = 'student')
    or (audience = 'teachers' and public.current_role()::text = 'teacher')
    or (audience = 'parents' and public.current_role()::text = 'parent')
  ))
);

-- Analytics views are security-invoker so underlying RLS still applies.
create or replace view public.attendance_daily_summaries
with (security_invoker = true) as
select school_id, attendance_date,
       count(*)::integer as recorded_count,
       count(*) filter (where status = 'present')::integer as present_count,
       count(*) filter (where status = 'absent')::integer as absent_count,
       count(*) filter (where status = 'late')::integer as late_count,
       count(*) filter (where status = 'excused')::integer as excused_count
from public.attendance_records
group by school_id, attendance_date;

create or replace view public.academic_subject_summaries
with (security_invoker = true) as
select r.school_id, a.subject, a.term,
       count(*)::integer as graded_count,
       round(avg((r.score / nullif(a.max_score, 0)) * 100), 1) as average_percentage
from public.academic_results r
join public.academic_assessments a on a.id = r.assessment_id
group by r.school_id, a.subject, a.term;

grant select on public.attendance_daily_summaries to authenticated;
grant select on public.academic_subject_summaries to authenticated;
grant execute on function public.parent_has_student(uuid) to authenticated;
grant execute on function public.parent_has_class(text, uuid) to authenticated;

create or replace view public.school_class_summaries
with (security_invoker = true) as
select school_id, class_name, count(*)::integer as student_count
from public.profiles
where role::text = 'student' and class_name is not null
 group by school_id, class_name;
grant select on public.school_class_summaries to authenticated;

-- Explicit table grants; row-level security above remains the enforcement boundary.
grant select, insert, update, delete on public.parent_student_links to authenticated;
grant select, insert, update, delete on public.attendance_records to authenticated;
grant select, insert, update, delete on public.academic_assessments to authenticated;
grant select, insert, update, delete on public.academic_results to authenticated;

-- A paused/suspended tenant must not be able to use these new school modules.
do $$ declare t text; begin
  foreach t in array array['parent_student_links','attendance_records','academic_assessments','academic_results'] loop
    execute format('drop policy if exists %I on public.%I', t || '_school_active', t);
    execute format($f$create policy %I on public.%I as restrictive for all
      using (public.is_super_admin() or public.school_is_usable())
      with check (public.is_super_admin() or public.school_is_usable())$f$, t || '_school_active', t);
  end loop;
end $$;
