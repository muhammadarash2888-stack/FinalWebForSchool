-- Student portfolio: private evidence storage, school-scoped review and verification.
create extension if not exists pgcrypto;

create table if not exists public.student_portfolio_items (
  id uuid primary key default gen_random_uuid(),
  school_id uuid not null references public.schools(id) on delete cascade,
  student_id uuid not null references public.profiles(id) on delete cascade,
  title text not null check (char_length(title) between 2 and 140),
  category text not null check (category in ('Certificate','Award','Competition','Project','Volunteering','Leadership','Other')),
  issuer text,
  achievement_date date,
  description text,
  file_path text,
  review_status text not null default 'pending' check (review_status in ('pending','verified','needs_changes')),
  reviewer_notes text,
  reviewed_by uuid references public.profiles(id) on delete set null,
  reviewed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists idx_portfolio_school_student on public.student_portfolio_items(school_id, student_id, created_at desc);
create index if not exists idx_portfolio_school_status on public.student_portfolio_items(school_id, review_status, created_at desc);

create or replace function public.validate_student_portfolio_item()
returns trigger language plpgsql security definer set search_path = public as $$
declare s public.profiles;
begin
  select * into s from public.profiles where id = new.student_id;
  if s.id is null or s.role::text <> 'student' or s.school_id is distinct from new.school_id then
    raise exception 'Portfolio items must belong to a student in the same school';
  end if;
  if new.file_path is not null and (split_part(new.file_path, '/', 1) <> new.school_id::text or split_part(new.file_path, '/', 2) <> new.student_id::text) then
    raise exception 'Portfolio file must be stored in the matching school and student folder';
  end if;
  if tg_op = 'INSERT' then
    new.review_status := 'pending';
    new.reviewer_notes := null;
    new.reviewed_by := null;
    new.reviewed_at := null;
  end if;
  if tg_op = 'UPDATE' then
    if old.student_id <> new.student_id or old.school_id <> new.school_id or old.file_path is distinct from new.file_path then
      raise exception 'Student, school and evidence file cannot be changed after submission';
    end if;
    if new.review_status is distinct from old.review_status or new.reviewer_notes is distinct from old.reviewer_notes then
      if not public.is_school_staff() or new.school_id <> public.current_school_id() then
        raise exception 'Only school staff can review portfolio items';
      end if;
      new.reviewed_at := now();
      new.reviewed_by := auth.uid();
    end if;
  end if;
  new.updated_at := now();
  return new;
end $$;
drop trigger if exists student_portfolio_validate on public.student_portfolio_items;
create trigger student_portfolio_validate before insert or update on public.student_portfolio_items
for each row execute function public.validate_student_portfolio_item();

alter table public.student_portfolio_items enable row level security;
drop policy if exists portfolio_select on public.student_portfolio_items;
create policy portfolio_select on public.student_portfolio_items for select to authenticated
using (school_id = public.current_school_id() and (student_id = auth.uid() or public.is_school_staff()));
drop policy if exists portfolio_insert on public.student_portfolio_items;
create policy portfolio_insert on public.student_portfolio_items for insert to authenticated
with check (school_id = public.current_school_id() and student_id = auth.uid() and public.current_role()::text = 'student');
drop policy if exists portfolio_student_delete on public.student_portfolio_items;
create policy portfolio_student_delete on public.student_portfolio_items for delete to authenticated
using (school_id = public.current_school_id() and student_id = auth.uid() and review_status = 'pending');
drop policy if exists portfolio_staff_update on public.student_portfolio_items;
create policy portfolio_staff_update on public.student_portfolio_items for update to authenticated
using (school_id = public.current_school_id() and public.is_school_staff())
with check (school_id = public.current_school_id() and public.is_school_staff());

-- A private bucket: all reads use short-lived signed URLs created after RLS checks.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('student-portfolio', 'student-portfolio', false, 10485760, array['application/pdf','image/jpeg','image/png','image/webp'])
on conflict (id) do update set public = false, file_size_limit = 10485760,
  allowed_mime_types = array['application/pdf','image/jpeg','image/png','image/webp'];

drop policy if exists portfolio_storage_upload on storage.objects;
create policy portfolio_storage_upload on storage.objects for insert to authenticated
with check (
  bucket_id = 'student-portfolio'
  and (storage.foldername(name))[1] = public.current_school_id()::text
  and (storage.foldername(name))[2] = auth.uid()::text
  and public.current_role()::text = 'student'
);
drop policy if exists portfolio_storage_read on storage.objects;
create policy portfolio_storage_read on storage.objects for select to authenticated
using (
  bucket_id = 'student-portfolio'
  and (storage.foldername(name))[1] = public.current_school_id()::text
  and (
    (storage.foldername(name))[2] = auth.uid()::text
    or public.is_school_staff()
  )
);
drop policy if exists portfolio_storage_delete on storage.objects;
create policy portfolio_storage_delete on storage.objects for delete to authenticated
using (
  bucket_id = 'student-portfolio'
  and (storage.foldername(name))[1] = public.current_school_id()::text
  and (storage.foldername(name))[2] = auth.uid()::text
  and public.current_role()::text = 'student'
);
