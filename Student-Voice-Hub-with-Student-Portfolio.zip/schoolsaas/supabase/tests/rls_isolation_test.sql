-- Run in the Supabase SQL editor on a STAGING project. Everything runs in a
-- transaction and is rolled back, so no data is kept.
-- It creates two schools, users in each, then impersonates them via
-- request.jwt.claims to prove RLS behaves as required.
begin;

insert into auth.users (id, email, instance_id, aud, role) values
 ('00000000-0000-0000-0000-0000000000a1','sa@test.dev','00000000-0000-0000-0000-000000000000','authenticated','authenticated'),
 ('00000000-0000-0000-0000-0000000000b1','stu-a@test.dev','00000000-0000-0000-0000-000000000000','authenticated','authenticated'),
 ('00000000-0000-0000-0000-0000000000b2','stu-b@test.dev','00000000-0000-0000-0000-000000000000','authenticated','authenticated'),
 ('00000000-0000-0000-0000-0000000000c1','adm-a@test.dev','00000000-0000-0000-0000-000000000000','authenticated','authenticated');
insert into public.schools (id,name,slug,status) values
 ('11111111-1111-1111-1111-111111111111','School A','test-a','active'),
 ('22222222-2222-2222-2222-222222222222','School B','test-b','active');
insert into public.profiles (id,school_id,role,full_name) values
 ('00000000-0000-0000-0000-0000000000a1',null,'super_admin','Super'),
 ('00000000-0000-0000-0000-0000000000b1','11111111-1111-1111-1111-111111111111','student','Stu A'),
 ('00000000-0000-0000-0000-0000000000b2','22222222-2222-2222-2222-222222222222','student','Stu B'),
 ('00000000-0000-0000-0000-0000000000c1','11111111-1111-1111-1111-111111111111','school_admin','Adm A')
 on conflict (id) do update set school_id=excluded.school_id, role=excluded.role;

-- School A admin creates a poll + options
set local role authenticated;
select set_config('request.jwt.claims','{"sub":"00000000-0000-0000-0000-0000000000c1","role":"authenticated"}',true);
insert into public.polls (id,school_id,created_by,title) values
 ('aaaaaaaa-0000-0000-0000-000000000001','11111111-1111-1111-1111-111111111111','00000000-0000-0000-0000-0000000000c1','Test poll');
insert into public.poll_options (id,poll_id,school_id,label) values
 ('bbbbbbbb-0000-0000-0000-000000000001','aaaaaaaa-0000-0000-0000-000000000001','11111111-1111-1111-1111-111111111111','Yes');

-- TEST 1: School B student cannot see School A polls
select set_config('request.jwt.claims','{"sub":"00000000-0000-0000-0000-0000000000b2","role":"authenticated"}',true);
do $$ begin
  if (select count(*) from public.polls) <> 0 then raise exception 'FAIL: cross-school poll leak'; end if;
  if (select count(*) from public.schools) <> 1 then raise exception 'FAIL: student sees other schools'; end if;
  raise notice 'PASS: school B student sees no school A data';
end $$;

-- TEST 2: School A student votes once; second vote is rejected
select set_config('request.jwt.claims','{"sub":"00000000-0000-0000-0000-0000000000b1","role":"authenticated"}',true);
insert into public.votes (poll_id,poll_option_id,school_id,voter_id) values
 ('aaaaaaaa-0000-0000-0000-000000000001','bbbbbbbb-0000-0000-0000-000000000001','11111111-1111-1111-1111-111111111111','00000000-0000-0000-0000-0000000000b1');
do $$ begin
  begin
    insert into public.votes (poll_id,poll_option_id,school_id,voter_id) values
     ('aaaaaaaa-0000-0000-0000-000000000001','bbbbbbbb-0000-0000-0000-000000000001','11111111-1111-1111-1111-111111111111','00000000-0000-0000-0000-0000000000b1');
    raise exception 'FAIL: double vote allowed';
  exception when unique_violation then raise notice 'PASS: duplicate vote blocked';
  end;
end $$;

-- TEST 3: School B student cannot vote in School A's poll
select set_config('request.jwt.claims','{"sub":"00000000-0000-0000-0000-0000000000b2","role":"authenticated"}',true);
do $$ begin
  begin
    insert into public.votes (poll_id,poll_option_id,school_id,voter_id) values
     ('aaaaaaaa-0000-0000-0000-000000000001','bbbbbbbb-0000-0000-0000-000000000001','11111111-1111-1111-1111-111111111111','00000000-0000-0000-0000-0000000000b2');
    raise exception 'FAIL: cross-school vote allowed';
  exception when others then
    if sqlerrm like 'FAIL%' then raise; end if;
    raise notice 'PASS: cross-school vote blocked (%)', sqlerrm;
  end;
end $$;

-- TEST 4: Student cannot promote themselves
select set_config('request.jwt.claims','{"sub":"00000000-0000-0000-0000-0000000000b1","role":"authenticated"}',true);
do $$ begin
  begin
    update public.profiles set role='super_admin' where id='00000000-0000-0000-0000-0000000000b1';
    raise exception 'FAIL: privilege escalation';
  exception when others then
    if sqlerrm like 'FAIL%' then raise; end if;
    raise notice 'PASS: role change blocked';
  end;
end $$;

-- TEST 5: Student cannot create polls
do $$ begin
  begin
    insert into public.polls (school_id,created_by,title) values
     ('11111111-1111-1111-1111-111111111111','00000000-0000-0000-0000-0000000000b1','x');
    raise exception 'FAIL: student created poll';
  exception when others then
    if sqlerrm like 'FAIL%' then raise; end if;
    raise notice 'PASS: student poll creation blocked';
  end;
end $$;

-- TEST 6: Student cannot change an idea's status
insert into public.ideas (id,school_id,created_by,title,description) values
 ('cccccccc-0000-0000-0000-000000000001','11111111-1111-1111-1111-111111111111','00000000-0000-0000-0000-0000000000b1','i','d');
do $$ begin
  begin
    update public.ideas set status='approved' where id='cccccccc-0000-0000-0000-000000000001';
    raise exception 'FAIL: student approved own idea';
  exception when others then
    if sqlerrm like 'FAIL%' then raise; end if;
    raise notice 'PASS: idea status change blocked';
  end;
end $$;

rollback;
